from __future__ import annotations

from collections import defaultdict
from typing import Literal

from typing_extensions import TypedDict

from langchain.chat_models import init_chat_model
from langchain_core.prompts import ChatPromptTemplate
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import START, END, StateGraph
from langgraph.types import Command, interrupt
from .config import OPENAI_API_KEY

VALIDATED_LESSONS = [
    {
        "run_id": "run-001",
        "topic": "gift_returns",
        "label": "incorrect_policy",
        "lesson": "Do not promise cash refunds for gift returns without explicit policy support.",
    },
    {
        "run_id": "run-004",
        "topic": "gift_returns",
        "label": "missing_condition",
        "lesson": "Gift return answers must mention the store-credit condition when applicable.",
    },
    {
        "run_id": "run-007",
        "topic": "gift_returns",
        "label": "incorrect_policy",
        "lesson": "Gift-return refund paths are easy to misstate and need extra care.",
    },
    {
        "run_id": "run-010",
        "topic": "return_shipping",
        "label": "unclear",
        "lesson": "Return-shipping answers are sometimes vague but rarely dangerous.",
    },
    # Uncomment this extra validated lesson if you want the sample
    # to exercise the cautious_answer branch too.
    {
        "run_id": "run-011",
        "topic": "return_shipping",
        "label": "incorrect_policy",
        "lesson": "Return-shipping answers sometimes miss merchant-paid exceptions.",
    },
]


LABEL_WEIGHTS = {
    "unsafe_action": 5,
    "incorrect_policy": 4,
    "missing_condition": 2,
    "unclear": 1,
    "good": 0,
}


TOPIC_EVIDENCE = {
    "gift_returns": [
        "Most physical items can be returned within 30 days of delivery.",
        "Gift returns are eligible for store credit only unless a specific refund rule is stated.",
    ],
    "return_shipping": [
        "Standard returns may require the customer to pay return shipping unless the item is defective.",
    ],
    "store_hours": [
        "The Rome store opens at 09:00 on Saturday.",
    ],
}


class SupportState(TypedDict):
    question: str
    topic: str

    topic_risk_index: dict[str, int]
    topic_risk_score: int
    matched_lessons: list[str]
    evidence: list[str]

    route: Literal["", "human_review", "cautious_answer", "normal_answer"]
    route_reason: str

    draft_answer: str
    final_answer: str
    review_decision: dict


def build_topic_risk_index(validated_lessons: list[dict]) -> dict[str, int]:
    scores = defaultdict(int)
    for item in validated_lessons:
        scores[item["topic"]] += LABEL_WEIGHTS.get(item["label"], 0)
    return dict(scores)


def lessons_for_topic(topic: str) -> list[str]:
    return [item["lesson"] for item in VALIDATED_LESSONS if item["topic"] == topic]


def format_block(lines: list[str]) -> str:
    if not lines:
        return "NONE"
    return "\n".join(f"- {line}" for line in lines)


model = init_chat_model("openai:gpt-4.1-mini", temperature=0)

normal_prompt = ChatPromptTemplate.from_template(
    """You are a customer support assistant.

Answer the question using only the evidence below.
Be concise and direct.

Question:
{question}

Evidence:
{evidence}
"""
)

cautious_prompt = ChatPromptTemplate.from_template(
    """You are a customer support assistant.

This topic has a history of validated failures in prior reviewed cases.
Answer carefully using only the evidence below, and explicitly respect the validated lessons.

Question:
{question}

Evidence:
{evidence}

Validated lessons:
{lessons}

Requirements:
- do not invent policy
- mention important conditions
- avoid overconfident wording when the evidence is narrow
- keep the answer concise
"""
)

normal_chain = normal_prompt | model
cautious_chain = cautious_prompt | model


def prepare_context(state: SupportState) -> dict:
    topic_risk_index = build_topic_risk_index(VALIDATED_LESSONS)
    topic_risk_score = topic_risk_index.get(state["topic"], 0)
    matched_lessons = lessons_for_topic(state["topic"])
    evidence = TOPIC_EVIDENCE.get(state["topic"], ["No evidence available."])

    return {
        "topic_risk_index": topic_risk_index,
        "topic_risk_score": topic_risk_score,
        "matched_lessons": matched_lessons,
        "evidence": evidence,
    }


def choose_route(
    state: SupportState,
) -> Command[Literal["draft_for_review", "cautious_answer", "normal_answer"]]:
    score = state["topic_risk_score"]
    topic = state["topic"]

    if score >= 8:
        return Command(
            update={
                "route": "human_review",
                "route_reason": (
                    f"Topic '{topic}' has risk score {score}. "
                    "Repeated validated failures make pre-answer human review appropriate."
                ),
            },
            goto="draft_for_review",
        )

    if score >= 3:
        return Command(
            update={
                "route": "cautious_answer",
                "route_reason": (
                    f"Topic '{topic}' has risk score {score}. "
                    "Past reviewed failures justify a stricter evidence-based path."
                ),
            },
            goto="cautious_answer",
        )

    return Command(
        update={
            "route": "normal_answer",
            "route_reason": (
                f"Topic '{topic}' has risk score {score}. "
                "Validated history does not show serious recurring failures."
            ),
        },
        goto="normal_answer",
    )


def normal_answer(state: SupportState) -> dict:
    response = normal_chain.invoke(
        {
            "question": state["question"],
            "evidence": format_block(state["evidence"]),
        }
    )
    return {"final_answer": response.text}


def cautious_answer(state: SupportState) -> dict:
    response = cautious_chain.invoke(
        {
            "question": state["question"],
            "evidence": format_block(state["evidence"]),
            "lessons": format_block(state["matched_lessons"]),
        }
    )
    return {"final_answer": response.text}


def draft_for_review(state: SupportState) -> dict:
    response = cautious_chain.invoke(
        {
            "question": state["question"],
            "evidence": format_block(state["evidence"]),
            "lessons": format_block(state["matched_lessons"]),
        }
    )
    return {"draft_answer": response.text}


def human_review(state: SupportState) -> dict:
    decision = interrupt(
        {
            "question": state["question"],
            "topic": state["topic"],
            "route": state["route"],
            "route_reason": state["route_reason"],
            "draft_answer": state["draft_answer"],
            "matched_lessons": state["matched_lessons"],
            "instruction": (
                "Review the draft. Resume with "
                "{'action': 'approve'} or "
                "{'action': 'edit', 'edited_answer': '...'}."
            ),
        }
    )

    action = decision["action"]

    if action == "approve":
        return {
            "review_decision": decision,
            "final_answer": state["draft_answer"],
        }

    if action == "edit":
        return {
            "review_decision": decision,
            "final_answer": decision["edited_answer"],
        }

    return {
        "review_decision": decision,
        "final_answer": "This case has been escalated for manual handling.",
    }


builder = StateGraph(SupportState)

builder.add_node("prepare_context", prepare_context)
builder.add_node("choose_route", choose_route)
builder.add_node("normal_answer", normal_answer)
builder.add_node("cautious_answer", cautious_answer)
builder.add_node("draft_for_review", draft_for_review)
builder.add_node("human_review", human_review)

builder.add_edge(START, "prepare_context")
builder.add_edge("prepare_context", "choose_route")
builder.add_edge("normal_answer", END)
builder.add_edge("cautious_answer", END)
builder.add_edge("draft_for_review", "human_review")
builder.add_edge("human_review", END)

graph = builder.compile(checkpointer=InMemorySaver())


if __name__ == "__main__":
    questions = [
        {
            "topic": "gift_returns",
            "question": "Can a gift return be refunded to my card?",
        },
        {
            "topic": "return_shipping",
            "question": "Who pays return shipping for a standard item?",
        },
        {
            "topic": "store_hours",
            "question": "What time does the Rome store open on Saturday?",
        },
    ]

    print("TOPIC RISK INDEX")
    print(build_topic_risk_index(VALIDATED_LESSONS))

    print("\nRUNS")

    for i, item in enumerate(questions, start=1):
        print("\n" + "=" * 80)
        print(f"QUESTION: {item['question']}")
        config = {"configurable": {"thread_id": f"question-{i}"}}

        result = graph.invoke(
            {
                "question": item["question"],
                "topic": item["topic"],
                "topic_risk_index": {},
                "topic_risk_score": 0,
                "matched_lessons": [],
                "evidence": [],
                "route": "",
                "route_reason": "",
                "draft_answer": "",
                "final_answer": "",
                "review_decision": {},
            },
            config=config,
        )

        print(f"TOPIC: {item['topic']}")
        print(f"ROUTE: {result['route']}")
        print(f"REASON: {result['route_reason']}")

        if "__interrupt__" in result:
            payload = result["__interrupt__"][0].value
            print("\nHUMAN REVIEW PAYLOAD")
            print(payload)

            reviewed = graph.invoke(
                Command(
                    resume={
                        "action": "edit",
                        "edited_answer": (
                            "Gift returns should not be promised as cash refunds "
                            "unless a specific refund rule exists. Based on the policy "
                            "shown here, the safer answer is that gift returns are handled "
                            "as store credit."
                        ),
                    }
                ),
                config=config,
            )

            print("\nFINAL ANSWER (AFTER HUMAN REVIEW)")
            print(reviewed["final_answer"])
        else:
            print("\nFINAL ANSWER")
            print(result["final_answer"])


