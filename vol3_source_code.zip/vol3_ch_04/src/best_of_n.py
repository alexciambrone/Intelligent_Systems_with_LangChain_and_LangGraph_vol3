from __future__ import annotations

import operator
from typing import Annotated
from typing_extensions import TypedDict

from pydantic import BaseModel, Field
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, START, END
from langgraph.types import Send

from .config import OPENAI_API_KEY


POLICY = """
Support policy summary:
- Most physical items can be returned within 30 days of delivery.
- Gift purchases are usually refunded as store credit unless the original purchaser
  requests a refund to the original payment method.
- Defective items may be replaced if the issue is confirmed and the item is within policy.
- Never promise a refund that is not explicitly supported by the policy and facts.
- If facts are missing or policy is ambiguous, ask a clarifying question or escalate.
""".strip()


class CandidateReply(BaseModel):
    id: str = Field(description="Short id such as reply_1")
    reply: str = Field(description="Customer-facing reply")
    strategy_note: str = Field(description="One-line description of the strategy")


class CandidateReplySet(BaseModel):
    candidates: list[CandidateReply]


class ReplyJudgment(BaseModel):
    policy_fit: int = Field(ge=1, le=10)
    clarity: int = Field(ge=1, le=10)
    risk: int = Field(ge=1, le=10)
    rationale: str


class GraphState(TypedDict):
    customer_case: str
    candidates: list[dict]
    scored_candidates: Annotated[list[dict], operator.add]
    ranked_candidates: list[dict]
    selection_trace: str
    final_answer: str


class JudgeWorkerState(TypedDict):
    customer_case: str
    candidate: dict
    scored_candidates: Annotated[list[dict], operator.add]


def build_model(temperature: float = 0.2) -> ChatOpenAI:
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY is not set.")
    return ChatOpenAI(model="gpt-4.1-mini", temperature=temperature)


def total_score(policy_fit: int, clarity: int, risk: int) -> int:
    return (2 * policy_fit) + clarity - risk


def generate_candidates(state: GraphState) -> dict:
    planner = build_model(0.7).with_structured_output(
        CandidateReplySet,
        method="json_schema",
    )

    prompt = f"""
You are drafting support replies.

{POLICY}

Customer case:
{state["customer_case"]}

Generate exactly 3 materially different candidate replies.
Each reply must:
- stay inside the policy,
- avoid unsupported promises,
- reflect a distinct response strategy.

Return only structured output.
""".strip()

    result = planner.invoke(prompt)

    return {
        "candidates": [candidate.model_dump() for candidate in result.candidates],
        "scored_candidates": [],
    }


def assign_judges(state: GraphState):
    return [
        Send(
            "judge_candidate",
            {
                "customer_case": state["customer_case"],
                "candidate": candidate,
            },
        )
        for candidate in state["candidates"]
    ]


def judge_candidate(state: JudgeWorkerState) -> dict:
    candidate = CandidateReply.model_validate(state["candidate"])

    judge = build_model(0.0).with_structured_output(
        ReplyJudgment,
        method="json_schema",
    )

    prompt = f"""
You are judging one support reply.

{POLICY}

Customer case:
{state["customer_case"]}

Candidate reply:
id: {candidate.id}
strategy_note: {candidate.strategy_note}
reply: {candidate.reply}

Score the reply on:
- policy_fit: how strongly it is supported by policy and facts,
- clarity: how clear and useful it is to the customer,
- risk: unsupported promises or operational ambiguity.

Be strict.
""".strip()

    judgment = judge.invoke(prompt)
    scored = {
        "candidate": candidate.model_dump(),
        **judgment.model_dump(),
        "total_score": total_score(
            judgment.policy_fit,
            judgment.clarity,
            judgment.risk,
        ),
    }

    return {"scored_candidates": [scored]}


def select_best(state: GraphState) -> dict:
    ranked = sorted(
        state["scored_candidates"],
        key=lambda item: (item["total_score"], item["policy_fit"], item["clarity"]),
        reverse=True,
    )
    best = ranked[0]
    runner_up = ranked[1] if len(ranked) > 1 else None

    candidate = best["candidate"]

    trace_lines = [
        "Selection process:",
        "The graph generated 3 candidates, judged each one independently, then ranked them by total_score = (2 * policy_fit) + clarity - risk.",
        "",
        "Ranked candidates:",
    ]

    for index, item in enumerate(ranked, start=1):
        current = item["candidate"]
        trace_lines.extend(
            [
                f"{index}. {current['id']} | strategy={current['strategy_note']}",
                (
                    f"   scores: policy_fit={item['policy_fit']}, "
                    f"clarity={item['clarity']}, risk={item['risk']}, "
                    f"total={item['total_score']}"
                ),
                f"   judge rationale: {item['rationale']}",
                f"   reply: {current['reply']}",
                "",
            ]
        )

    if runner_up is None:
        selection_reason = (
            f"{candidate['id']} was selected because it is the only scored candidate."
        )
    else:
        score_gap = best["total_score"] - runner_up["total_score"]
        selection_reason = (
            f"{candidate['id']} was selected because it ranked first with total={best['total_score']}. "
            f"The next best option was {runner_up['candidate']['id']} with total={runner_up['total_score']}. "
            f"Score gap: {score_gap}."
        )

    trace_lines.extend([
        "Winning selection:",
        selection_reason,
    ])

    answer = "\n".join(
        [
            f"Selected reply: {candidate['id']}",
            f"Strategy: {candidate['strategy_note']}",
            "",
            candidate["reply"],
            "",
            (
                f"Winning scores: policy_fit={best['policy_fit']}, "
                f"clarity={best['clarity']}, "
                f"risk={best['risk']}, "
                f"total={best['total_score']}"
            ),
        ]
    )

    return {
        "ranked_candidates": ranked,
        "selection_trace": "\n".join(trace_lines),
        "final_answer": answer,
    }


builder = StateGraph(GraphState)
builder.add_node("generate_candidates", generate_candidates)
builder.add_node("judge_candidate", judge_candidate)
builder.add_node("select_best", select_best)

builder.add_edge(START, "generate_candidates")
builder.add_conditional_edges("generate_candidates", assign_judges)
builder.add_edge("judge_candidate", "select_best")
builder.add_edge("select_best", END)

graph = builder.compile()


if __name__ == "__main__":
    customer_case = """
The earbuds were bought 10 days ago as a gift.
The recipient says the right earbud is defective.
They want an immediate cash refund to their own card.
""".strip()

    result = graph.invoke(
        {
            "customer_case": customer_case,
            "candidates": [],
            "scored_candidates": [],
            "ranked_candidates": [],
            "selection_trace": "",
            "final_answer": "",
        },
        config={"recursion_limit": 10},
    )

    print("CUSTOMER CASE:\n")
    print(customer_case)
    print("\n" + "=" * 80 + "\n")
    print(result["selection_trace"])
    print("\n" + "=" * 80 + "\n")
    print("FINAL SELECTED ANSWER:\n")
    print(result["final_answer"])
