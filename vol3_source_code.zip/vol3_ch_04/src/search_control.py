from __future__ import annotations

import operator
from typing import Annotated
from typing_extensions import TypedDict

from pydantic import BaseModel, Field
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, START, END
from langgraph.managed import RemainingSteps

from .config import OPENAI_API_KEY


POLICY = """
Support policy summary:
- Do not promise remedies not explicitly supported by policy and facts.
- If the item appears defective, verification may be required.
- If the purchase was a gift, do not assume refund-to-recipient is allowed.
- If uncertainty remains, ask a clarifying question or escalate.
""".strip()


class CandidateReply(BaseModel):
    id: str
    reply: str
    follow_up: str


class ReplyScore(BaseModel):
    policy_fit: int = Field(ge=1, le=10)
    clarity: int = Field(ge=1, le=10)
    risk: int = Field(ge=1, le=10)
    rationale: str


class LoopState(TypedDict):
    customer_case: str
    attempt: int
    latest_candidate: dict
    best_candidate: dict
    best_score: int
    log: Annotated[list[str], operator.add]
    remaining_steps: RemainingSteps
    final_answer: str


def build_model(temperature: float = 0.2) -> ChatOpenAI:
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY is not set.")
    return ChatOpenAI(model="gpt-4.1-mini", temperature=temperature)


def total_score(policy_fit: int, clarity: int, risk: int) -> int:
    return (2 * policy_fit) + clarity - risk


def generate_candidate(state: LoopState) -> dict:
    next_attempt = state["attempt"] + 1

    generator = build_model(0.5).with_structured_output(
        CandidateReply,
        method="json_schema",
    )

    prompt = f"""
You are generating one support reply candidate.

{POLICY}

Customer case:
{state["customer_case"]}

This is attempt number {next_attempt}.
Generate one candidate reply that is materially different from earlier attempts.
If there is uncertainty, the reply may ask a clarifying question instead of promising a remedy.
""".strip()

    candidate = generator.invoke(prompt)

    return {
        "attempt": next_attempt,
        "latest_candidate": candidate.model_dump(),
        "log": [f"generated attempt {next_attempt}: {candidate.id}"],
    }


def score_candidate(state: LoopState) -> dict:
    candidate = CandidateReply.model_validate(state["latest_candidate"])

    judge = build_model(0.0).with_structured_output(
        ReplyScore,
        method="json_schema",
    )

    prompt = f"""
You are evaluating one support reply.

{POLICY}

Customer case:
{state["customer_case"]}

Candidate:
id: {candidate.id}
reply: {candidate.reply}
follow_up: {candidate.follow_up}

Score it on:
- policy_fit,
- clarity,
- risk.

Be strict.
""".strip()

    judgment = judge.invoke(prompt)
    score = total_score(judgment.policy_fit, judgment.clarity, judgment.risk)

    updates = {
        "log": [
            (
                f"scored attempt {state['attempt']}: "
                f"policy_fit={judgment.policy_fit}, clarity={judgment.clarity}, "
                f"risk={judgment.risk}, total={score}, remaining_steps={state['remaining_steps']}"
            )
        ]
    }

    if score > state["best_score"]:
        updates["best_score"] = score
        updates["best_candidate"] = {
            **candidate.model_dump(),
            **judgment.model_dump(),
            "total_score": score,
        }
        updates["log"].append(f"new best candidate selected at attempt {state['attempt']}")

    return updates


def route_after_scoring(state: LoopState):
    if state["remaining_steps"] <= 2:
        return "finish"
    if state["attempt"] >= 4:
        return "finish"
    return "generate_candidate"


def finish(state: LoopState) -> dict:
    best = state["best_candidate"]
    stop_reason = (
        "step budget nearly exhausted"
        if state["remaining_steps"] <= 2
        else "maximum planned attempts reached"
    )

    answer = "\n".join(
        [
            f"Stop reason: {stop_reason}",
            f"Best attempt total: {best['total_score']}",
            "",
            "Reply:",
            best["reply"],
            "",
            "Follow-up:",
            best["follow_up"],
        ]
    )
    return {"final_answer": answer}


builder = StateGraph(LoopState)
builder.add_node("generate_candidate", generate_candidate)
builder.add_node("score_candidate", score_candidate)
builder.add_node("finish", finish)

builder.add_edge(START, "generate_candidate")
builder.add_edge("generate_candidate", "score_candidate")
builder.add_conditional_edges("score_candidate", route_after_scoring)
builder.add_edge("finish", END)

graph = builder.compile()


if __name__ == "__main__":
    customer_case = """
The customer says the blender was purchased as a gift 28 days ago.
The motor now stops after a few seconds. They want a guaranteed cash refund today.
""".strip()

    result = graph.invoke(
        {
            "customer_case": customer_case,
            "attempt": 0,
            "latest_candidate": {},
            "best_candidate": {},
            "best_score": -999,
            "log": [],
        },
        config={"recursion_limit": 8},
    )

    print("Execution log:")
    for line in result["log"]:
        print("-", line)

    print("\nFinal answer:\n")
    print(result["final_answer"])