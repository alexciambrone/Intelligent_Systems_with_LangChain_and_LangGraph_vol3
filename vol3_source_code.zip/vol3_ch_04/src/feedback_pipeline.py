from dataclasses import dataclass, asdict
from typing import Optional

RAW_FEEDBACK = []
REVIEW_QUEUE = []
VALIDATED_LESSONS = []
ACCEPTED_CASES = []


@dataclass
class AnswerRun:
    run_id: str
    question: str
    answer: str
    prompt_version: str


@dataclass
class Feedback:
    run_id: str
    rating: int
    label: str
    comment: str


@dataclass
class ReviewDecision:
    run_id: str
    decision: str          # "confirm" or "dismiss"
    corrected_label: Optional[str]
    reviewer_note: str
    lesson: str = ""


def submit_feedback(run: AnswerRun, rating: int, label: str, comment: str) -> Feedback:
    feedback = Feedback(
        run_id=run.run_id,
        rating=rating,
        label=label,
        comment=comment,
    )
    RAW_FEEDBACK.append(asdict(feedback))

    severe_labels = {"incorrect_policy", "unsafe_action"}

    if rating <= 2 or label in severe_labels:
        REVIEW_QUEUE.append(
            {
                "run_id": run.run_id,
                "question": run.question,
                "answer": run.answer,
                "prompt_version": run.prompt_version,
                "rating": rating,
                "label": label,
                "comment": comment,
                "status": "queued",
            }
        )
    else:
        ACCEPTED_CASES.append(
            {
                "run_id": run.run_id,
                "rating": rating,
                "label": label,
            }
        )

    return feedback


def review_case(decision: ReviewDecision) -> None:
    for item in REVIEW_QUEUE:
        if item["run_id"] == decision.run_id:
            if decision.decision == "confirm":
                item["status"] = "confirmed"
                item["validated_label"] = decision.corrected_label or item["label"]
                item["reviewer_note"] = decision.reviewer_note

                if decision.lesson.strip():
                    VALIDATED_LESSONS.append(
                        {
                            "run_id": decision.run_id,
                            "label": item["validated_label"],
                            "lesson": decision.lesson.strip(),
                        }
                    )
            else:
                item["status"] = "dismissed"
                item["reviewer_note"] = decision.reviewer_note
            return

    raise ValueError(f"Run {decision.run_id} was not found in the review queue.")


if __name__ == "__main__":
    bad_run = AnswerRun(
        run_id="run-001",
        question="Can a gift return be refunded to the recipient's card?",
        answer=(
            "Yes. Gift returns can be refunded directly to the recipient's card "
            "within 30 days."
        ),
        prompt_version="support-prompt-v3",
    )

    good_run = AnswerRun(
        run_id="run-002",
        question="What usually happens with a normal gift return?",
        answer=(
            "Gift returns are usually handled as store credit when the policy "
            "allows returns."
        ),
        prompt_version="support-prompt-v3",
    )

    submit_feedback(
        bad_run,
        rating=1,
        label="incorrect_policy",
        comment=(
            "The answer promised a cash refund, but gift returns should be "
            "store credit."
        ),
    )

    submit_feedback(
        good_run,
        rating=5,
        label="good",
        comment="Clear and helpful.",
    )

    review_case(
        ReviewDecision(
            run_id="run-001",
            decision="confirm",
            corrected_label="incorrect_policy",
            reviewer_note="Confirmed. The refund path is wrong.",
            lesson=(
                "Do not promise cash refunds for gift returns unless the policy "
                "text states that explicitly."
            ),
        )
    )

    print("RAW FEEDBACK")
    for item in RAW_FEEDBACK:
        print(item)

    print("\nREVIEW QUEUE")
    for item in REVIEW_QUEUE:
        print(item)

    print("\nACCEPTED CASES")
    for item in ACCEPTED_CASES:
        print(item)

    print("\nVALIDATED LESSONS")
    for item in VALIDATED_LESSONS:
        print(item)



