from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Literal, TypedDict

from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langgraph.graph import END, START, StateGraph
from langgraph.runtime import Runtime
from langgraph.types import Command

from .config import OPENAI_API_KEY


# ----------------------------
# Small support-policy corpus
# ----------------------------

def build_policy_docs() -> list[dict]:
    return [
        {
            "doc_id": "eu_refunds",
            "region": "EU",
            "text": (
                "EU refunds: Standard items may be refunded within 30 days of delivery "
                "if unopened. Refunds go to the original payment method."
            ),
        },
        {
            "doc_id": "eu_gifts",
            "region": "EU",
            "text": (
                "EU gift purchases: Gift returns are normally issued as store credit "
                "unless the policy explicitly states that a refund to the original "
                "payment method is allowed."
            ),
        },
        {
            "doc_id": "us_refunds",
            "region": "US",
            "text": (
                "US refunds: Standard items may be refunded within 30 days if unopened. "
                "Gift purchases follow the store-specific return policy."
            ),
        },
    ]


def open_policy_store(chroma_dir: str, embedder: OpenAIEmbeddings) -> Chroma:
    return Chroma(
        collection_name="support_policy",
        persist_directory=chroma_dir,
        embedding_function=embedder,
    )


def seed_policy(store: Chroma) -> None:
    splitter = RecursiveCharacterTextSplitter(chunk_size=220, chunk_overlap=40)

    docs: list[Document] = []
    ids: list[str] = []

    for raw in build_policy_docs():
        parts = splitter.split_text(raw["text"])
        for i, part in enumerate(parts):
            docs.append(
                Document(
                    page_content=part,
                    metadata={
                        "doc_id": raw["doc_id"],
                        "region": raw["region"],
                        "chunk_no": i,
                    },
                )
            )
            ids.append(f"{raw['doc_id']}#{i}")

    try:
        store.add_documents(docs, ids=ids)
    except Exception:
        # Ignore duplicate-id errors on repeated runs.
        pass


def format_sources(docs: list[Document]) -> str:
    rows = []
    for idx, doc in enumerate(docs, start=1):
        rows.append(
            f"[{idx}] {doc.metadata['doc_id']} ({doc.metadata['region']})\n"
            f"{doc.page_content}"
        )
    return "\n\n".join(rows)


def doc_refs(docs: list[Document]) -> list[str]:
    refs: list[str] = []
    for doc in docs:
        refs.append(f"{doc.metadata['doc_id']}#{doc.metadata['chunk_no']}")
    return refs


# ----------------------------
# Graph state and context
# ----------------------------
class RetrievalState(TypedDict, total=False):
    question: str
    history: list[dict[str, str]]
    retrieval_query: str
    retrieval_mode: Literal["", "fast", "high_recall"]
    retrieval_reason: str
    sources: str
    answer: str

@dataclass
class RetrievalContext:
    region: str


llm = ChatOpenAI(
    model="gpt-4.1-mini",
    temperature=0,
    api_key=OPENAI_API_KEY,
)

embedder = OpenAIEmbeddings(
    model="text-embedding-3-large",
    api_key=OPENAI_API_KEY,
)

VECTOR_STORE = open_policy_store("./chroma_support_policy", embedder)
seed_policy(VECTOR_STORE)


# ----------------------------
# Streaming helpers
# ----------------------------

def emit(runtime: Runtime[RetrievalContext], event: str, **payload) -> None:
    writer = runtime.stream_writer
    if writer is None:
        return
    writer({"event": event, **payload})


# ----------------------------
# Nodes
# ----------------------------

def rewrite_followup(
    state: RetrievalState,
    runtime: Runtime[RetrievalContext],
) -> dict:
    history_text = "\n".join(
        f"{m['role']}: {m['content']}" for m in state.get("history", [])[-4:]
    )

    emit(
        runtime,
        "rewrite_started",
        original_question=state["question"],
        history_turns=len(state.get("history", [])),
    )

    prompt = f"""
Rewrite the user's latest message as a standalone search query for a support-policy knowledge base.
Use the chat history only to resolve references such as "that", "it", or "those".
Do not answer the question.

CHAT HISTORY:
{history_text}

LATEST USER MESSAGE:
{state['question']}
"""
    msg = llm.invoke(prompt)
    retrieval_query = msg.content.strip()

    emit(
        runtime,
        "rewrite_completed",
        retrieval_query=retrieval_query,
    )

    return {"retrieval_query": retrieval_query}


def choose_retrieval_policy(
    state: RetrievalState,
) -> Command[Literal["retrieve_fast", "retrieve_high_recall"]]:
    q = state["question"].lower()

    signals: list[str] = []

    if len(q.split()) < 6:
        signals.append("short question")
    if "that" in q:
        signals.append("contains 'that'")
    if "it" in q:
        signals.append("contains 'it'")
    if "those" in q:
        signals.append("contains 'those'")
    if "what about" in q:
        signals.append("contains 'what about'")

    if signals:
        return Command(
            update={
                "retrieval_mode": "high_recall",
                "retrieval_reason": ", ".join(signals),
            },
            goto="retrieve_high_recall",
        )

    return Command(
        update={
            "retrieval_mode": "fast",
            "retrieval_reason": "question is already explicit",
        },
        goto="retrieve_fast",
    )
def retrieve_fast(
    state: RetrievalState,
    runtime: Runtime[RetrievalContext],
) -> Command[Literal["draft_answer", "ask_clarification"]]:
    emit(
        runtime,
        "retrieval_started",
        retrieval_mode="fast",
        retrieval_query=state["retrieval_query"],
        region_filter=runtime.context.region,
        search_type="similarity",
        k=2,
    )

    retriever = VECTOR_STORE.as_retriever(search_kwargs={"k": 2})
    docs = retriever.invoke(
        state["retrieval_query"],
        filter={"region": runtime.context.region},
    )

    if not docs:
        emit(runtime, "retrieval_completed", doc_count=0, doc_refs=[])
        return Command(
            update={"source_count": 0, "sources": ""},
            goto="ask_clarification",
        )

    emit(
        runtime,
        "retrieval_completed",
        doc_count=len(docs),
        doc_refs=doc_refs(docs),
    )

    return Command(
        update={
            "source_count": len(docs),
            "sources": format_sources(docs),
        },
        goto="draft_answer",
    )


def retrieve_high_recall(
    state: RetrievalState,
    runtime: Runtime[RetrievalContext],
) -> Command[Literal["draft_answer", "ask_clarification"]]:
    emit(
        runtime,
        "retrieval_started",
        retrieval_mode="high_recall",
        retrieval_query=state["retrieval_query"],
        region_filter=runtime.context.region,
        search_type="mmr",
        k=4,
        fetch_k=8,
    )

    retriever = VECTOR_STORE.as_retriever(
        search_type="mmr",
        search_kwargs={"k": 4, "fetch_k": 8},
    )
    docs = retriever.invoke(
        state["retrieval_query"],
        filter={"region": runtime.context.region},
    )

    if not docs:
        emit(runtime, "retrieval_completed", doc_count=0, doc_refs=[])
        return Command(
            update={"source_count": 0, "sources": ""},
            goto="ask_clarification",
        )

    emit(
        runtime,
        "retrieval_completed",
        doc_count=len(docs),
        doc_refs=doc_refs(docs),
    )

    return Command(
        update={
            "source_count": len(docs),
            "sources": format_sources(docs),
        },
        goto="draft_answer",
    )


def ask_clarification(
    state: RetrievalState,
    runtime: Runtime[RetrievalContext],
) -> dict:
    emit(
        runtime,
        "clarification_requested",
        reason="no matching sources after applying retrieval policy",
    )
    return {
        "answer": (
            "I need one more detail before I can answer reliably. "
            "Please tell me which return scenario or order you mean."
        )
    }


def draft_answer(
    state: RetrievalState,
    runtime: Runtime[RetrievalContext],
) -> dict:
    emit(
        runtime,
        "answer_started",
        retrieval_mode=state.get("retrieval_mode", ""),
        source_count=state.get("source_count", 0),
    )

    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                "You are a support assistant. Answer using only the sources. "
                "If the sources do not establish the answer, say that you do not know.",
            ),
            (
                "human",
                "Question:\n{question}\n\nSources:\n{sources}\n\n"
                "Answer in plain language and mention source indexes such as [1] or [2].",
            ),
        ]
    )

    messages = prompt.format_messages(
        question=state["question"],
        sources=state["sources"],
    )
    msg = llm.invoke(messages)
    answer = msg.content.strip()

    emit(
        runtime,
        "answer_completed",
        answer_preview=answer[:180],
    )

    return {"answer": answer}


# ----------------------------
# Build the graph
# ----------------------------

builder = StateGraph(RetrievalState, context_schema=RetrievalContext)

builder.add_node("rewrite_followup", rewrite_followup)
builder.add_node("choose_retrieval_policy", choose_retrieval_policy)
builder.add_node("retrieve_fast", retrieve_fast)
builder.add_node("retrieve_high_recall", retrieve_high_recall)
builder.add_node("ask_clarification", ask_clarification)
builder.add_node("draft_answer", draft_answer)

builder.add_edge(START, "rewrite_followup")
builder.add_edge("rewrite_followup", "choose_retrieval_policy")
builder.add_edge("ask_clarification", END)
builder.add_edge("draft_answer", END)

graph = builder.compile()


# ----------------------------
# Console demo
# ----------------------------

def print_banner(title: str) -> None:
    print()
    print("=" * 100)
    print(title)
    print("=" * 100)


def print_update(node_name: str, update: dict) -> None:
    print(f"[STATE UPDATE] {node_name}")
    for key, value in update.items():
        if key == "sources" and isinstance(value, str):
            compact = value.replace("\n", " | ")
            print(f"  {key}: {compact}")
        else:
            print(f"  {key}: {value}")
    print()


def print_custom_event(event: dict) -> None:
    name = event.get("event", "unknown_event")
    payload = {k: v for k, v in event.items() if k != "event"}
    print(f"[TRACE] {name}")
    print(json.dumps(payload, indent=2, ensure_ascii=False))
    print()


def run_demo(
    *,
    title: str,
    question: str,
    history: list[dict[str, str]],
    region: str,
) -> None:
    print_banner(title)

    result = graph.invoke(
        {
            "question": question,
            "history": history,
        },
        context=RetrievalContext(region=region),
    )

    print("QUESTION")
    print(f"  {question}")
    print()

    print("ADAPTATION")
    print(f"  rewritten query : {result['retrieval_query']}")
    print(f"  retrieval mode  : {result['retrieval_mode']}")
    print(f"  reason          : {result['retrieval_reason']}")
    print()

    print("EVIDENCE")
    if result.get("sources"):
        for block in result["sources"].split("\n\n"):
            first_line = block.splitlines()[0]
            print(f"  {first_line}")
    else:
        print("  no sources found")
    print()

    print("ANSWER")
    print(f"  {result['answer']}")
    print()


if __name__ == "__main__":
    run_demo(
        title="CASE 1 - Follow-up question, should switch to high_recall",
        question="Does that include gifts?",
        history=[
            {
                "role": "user",
                "content": "Can I get a refund on a standard unopened item?",
            },
            {
                "role": "assistant",
                "content": (
                    "In the EU policy, unopened standard items may be refunded "
                    "within 30 days."
                ),
            },
        ],
        region="EU",
    )

    run_demo(
        title="CASE 2 - Direct question, should swith to fast retrieval",
        question="What does the EU policy say about gift returns?",
        history=[],
        region="EU",
    )