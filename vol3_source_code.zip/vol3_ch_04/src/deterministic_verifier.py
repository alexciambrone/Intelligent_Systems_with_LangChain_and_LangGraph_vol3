from __future__ import annotations
import re
from typing import Literal
from typing_extensions import TypedDict
from pydantic import BaseModel, Field
from langchain.chat_models import init_chat_model
from langgraph.graph import StateGraph, START, END
from .config import OPENAI_API_KEY

SOURCE_TEXT_VALID = """
Order ID: ORD-1042
Requested refund window: 14 days
"""

SOURCE_TEXT_INVALID = """
Order ID: ORDER-77
Requested refund window: 45 days
"""

class Extraction(BaseModel):
    order_id: str
    refund_days: int = Field(ge=0)

class State(TypedDict):
    source_text: str
    extracted_order_id: str
    extracted_refund_days: int
    validation_error: str
    final_status: Literal["", "accepted", "rejected"]

model = init_chat_model("openai:gpt-4.1-mini", temperature=0).with_structured_output(
    Extraction
)

def extract_fields(state: State) -> dict:
    result = model.invoke(f"""
Extract the order ID and refund_days from this text:

{state["source_text"]}
""")
    return {
        "extracted_order_id": result.order_id,
        "extracted_refund_days": result.refund_days,
    }

def validate_fields(state: State) -> dict:
    errors = []

    if not re.fullmatch(r"ORD-\d{4}", state["extracted_order_id"]):
        errors.append("order_id must match ORD-####")

    if not (0 <= state["extracted_refund_days"] <= 30):
        errors.append("refund_days must be between 0 and 30")

    if errors:
        return {
            "validation_error": "; ".join(errors),
            "final_status": "rejected",
        }

    return {
        "validation_error": "",
        "final_status": "accepted",
    }

builder = StateGraph(State)
builder.add_node("extract_fields", extract_fields)
builder.add_node("validate_fields", validate_fields)

builder.add_edge(START, "extract_fields")
builder.add_edge("extract_fields", "validate_fields")
builder.add_edge("validate_fields", END)

graph = builder.compile()

def run_case(source_text: str) -> dict:
    return graph.invoke({
        "source_text": source_text,
        "extracted_order_id": "",
        "extracted_refund_days": 0,
        "validation_error": "",
        "final_status": "",
    })

if __name__ == "__main__":
    valid_result = run_case(SOURCE_TEXT_VALID)
    print("VALID EXAMPLE")
    print("ORDER ID:", valid_result["extracted_order_id"])
    print("REFUND DAYS:", valid_result["extracted_refund_days"])
    print("STATUS:", valid_result["final_status"])
    print("VALIDATION ERROR:", valid_result["validation_error"])

    print()

    invalid_result = run_case(SOURCE_TEXT_INVALID)
    print("INVALID EXAMPLE")
    print("ORDER ID:", invalid_result["extracted_order_id"])
    print("REFUND DAYS:", invalid_result["extracted_refund_days"])
    print("STATUS:", invalid_result["final_status"])
    print("VALIDATION ERROR:", invalid_result["validation_error"])
