from dataclasses import dataclass

PAIRWISE_REVIEWS = []


@dataclass
class CandidateAnswer:
    candidate_id: str
    run_id: str
    answer: str
    variant: str


def record_pairwise_review(
    question: str,
    left: CandidateAnswer,
    right: CandidateAnswer,
    winner: str,          # "left", "right", or "tie"
    criterion: str,
    reviewer_note: str,
) -> None:
    if winner not in {"left", "right", "tie"}:
        raise ValueError("winner must be 'left', 'right', or 'tie'")

    PAIRWISE_REVIEWS.append(
        {
            "question": question,
            "left_variant": left.variant,
            "right_variant": right.variant,
            "winner": winner,
            "criterion": criterion,
            "reviewer_note": reviewer_note,
        }
    )


if __name__ == "__main__":
    left = CandidateAnswer(
        candidate_id="cand-a",
        run_id="run-a1",
        answer="Gift returns are always refunded to the original payment card.",
        variant="prompt-v4",
    )

    right = CandidateAnswer(
        candidate_id="cand-b",
        run_id="run-b1",
        answer=(
            "Gift returns are usually handled as store credit unless the policy "
            "text states otherwise."
        ),
        variant="prompt-v5",
    )

    record_pairwise_review(
        question="Can a gift return be refunded to the recipient's card?",
        left=left,
        right=right,
        winner="right",
        criterion="policy_correctness",
        reviewer_note=(
            "The right answer is more careful and does not promise a refund "
            "path without policy support."
        ),
    )

    print(PAIRWISE_REVIEWS[0])



