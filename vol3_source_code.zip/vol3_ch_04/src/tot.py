from __future__ import annotations

import operator
from typing import Annotated
from typing_extensions import TypedDict

from pydantic import BaseModel, Field
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, START, END
from langgraph.types import Send

from .config import OPENAI_API_KEY


BUSINESS_CONTEXT = """
Business context:
- The product is high-margin and trending.
- Available stock is low.
- Overselling would hurt customer trust.
- Substitute products exist with slightly lower margin.
- Avoid recommendations that ignore stock constraints.
""".strip()

TOP_K = 2


class Strategy(BaseModel):
    id: str
    title: str
    summary: str


class StrategySet(BaseModel):
    strategies: list[Strategy]


class StrategyScore(BaseModel):
    stock_safety: int = Field(ge=1, le=10)
    margin_protection: int = Field(ge=1, le=10)
    customer_fit: int = Field(ge=1, le=10)
    risk: int = Field(ge=1, le=10)
    rationale: str


class ExpandedStep(BaseModel):
    id: str
    title: str
    concrete_action: str
    customer_impact: str
    risk_note: str


class ExpandedStepScore(BaseModel):
    stock_safety: int = Field(ge=1, le=10)
    margin_protection: int = Field(ge=1, le=10)
    execution_clarity: int = Field(ge=1, le=10)
    risk: int = Field(ge=1, le=10)
    rationale: str


class SearchState(TypedDict):
    scenario: str
    frontier: list[dict]
    scored_strategies: Annotated[list[dict], operator.add]
    expanded_steps: Annotated[list[dict], operator.add]
    final_answer: str


class ScoreWorkerState(TypedDict):
    scenario: str
    strategy: dict
    scored_strategies: Annotated[list[dict], operator.add]


class ExpandWorkerState(TypedDict):
    scenario: str
    strategy: dict
    expanded_steps: Annotated[list[dict], operator.add]


def build_model(temperature: float = 0.2) -> ChatOpenAI:
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY is not set.")
    return ChatOpenAI(model="gpt-4.1-mini", temperature=temperature)


def initial_total(stock_safety: int, margin_protection: int, customer_fit: int, risk: int) -> int:
    return stock_safety + margin_protection + customer_fit - risk


def expanded_total(stock_safety: int, margin_protection: int, execution_clarity: int, risk: int) -> int:
    return stock_safety + margin_protection + execution_clarity - risk


def generate_strategies(state: SearchState) -> dict:
    planner = build_model(0.6).with_structured_output(StrategySet, method="json_schema")

    prompt = f"""
You are planning an e-commerce response to a low-stock demand spike.

{BUSINESS_CONTEXT}

Scenario:
{state["scenario"]}

Generate exactly 3 materially different partial strategies.
These must be strategy directions, not final polished answers.
""".strip()

    result = planner.invoke(prompt)

    return {
        "frontier": [strategy.model_dump() for strategy in result.strategies],
        "scored_strategies": [],
        "expanded_steps": [],
    }


def assign_strategy_scorers(state: SearchState):
    return [
        Send(
            "score_strategy",
            {
                "scenario": state["scenario"],
                "strategy": strategy,
            },
        )
        for strategy in state["frontier"]
    ]


def score_strategy(state: ScoreWorkerState) -> dict:
    strategy = Strategy.model_validate(state["strategy"])

    judge = build_model(0.0).with_structured_output(StrategyScore, method="json_schema")

    prompt = f"""
You are evaluating one partial strategy.

{BUSINESS_CONTEXT}

Scenario:
{state["scenario"]}

Strategy:
id: {strategy.id}
title: {strategy.title}
summary: {strategy.summary}

Score it on:
- stock_safety,
- margin_protection,
- customer_fit,
- risk.

Be strict.
""".strip()

    judgment = judge.invoke(prompt)

    return {
        "scored_strategies": [
            {
                "strategy": strategy.model_dump(),
                **judgment.model_dump(),
                "total_score": initial_total(
                    judgment.stock_safety,
                    judgment.margin_protection,
                    judgment.customer_fit,
                    judgment.risk,
                ),
            }
        ]
    }


def select_frontier(state: SearchState) -> dict:
    ranked = sorted(
        state["scored_strategies"],
        key=lambda item: item["total_score"],
        reverse=True,
    )
    top = ranked[:TOP_K]
    return {"frontier": [item["strategy"] for item in top]}


def assign_expanders(state: SearchState):
    return [
        Send(
            "expand_step",
            {
                "scenario": state["scenario"],
                "strategy": strategy,
            },
        )
        for strategy in state["frontier"]
    ]


def expand_step(state: ExpandWorkerState) -> dict:
    strategy = Strategy.model_validate(state["strategy"])

    expander = build_model(0.2).with_structured_output(ExpandedStep, method="json_schema")
    judge = build_model(0.0).with_structured_output(ExpandedStepScore, method="json_schema")

    expand_prompt = f"""
You are deepening one e-commerce strategy by one step.

{BUSINESS_CONTEXT}

Scenario:
{state["scenario"]}

Selected strategy:
id: {strategy.id}
title: {strategy.title}
summary: {strategy.summary}

Produce one concrete next step.
""".strip()

    step = expander.invoke(expand_prompt)

    judge_prompt = f"""
You are evaluating one expanded next step.

{BUSINESS_CONTEXT}

Scenario:
{state["scenario"]}

Expanded step:
id: {step.id}
title: {step.title}
concrete_action: {step.concrete_action}
customer_impact: {step.customer_impact}
risk_note: {step.risk_note}

Score it on:
- stock_safety,
- margin_protection,
- execution_clarity,
- risk.
""".strip()

    judgment = judge.invoke(judge_prompt)

    return {
        "expanded_steps": [
            {
                "parent_strategy": strategy.model_dump(),
                "step": step.model_dump(),
                **judgment.model_dump(),
                "total_score": expanded_total(
                    judgment.stock_safety,
                    judgment.margin_protection,
                    judgment.execution_clarity,
                    judgment.risk,
                ),
            }
        ]
    }


def format_strategy_rankings(items: list[dict]) -> list[str]:
    lines: list[str] = []
    for index, item in enumerate(items, start=1):
        strategy = item["strategy"]
        lines.extend(
            [
                f"{index}. {strategy['id']} - {strategy['title']}",
                f"   Summary: {strategy['summary']}",
                (
                    "   Scores: "
                    f"stock_safety={item['stock_safety']}, "
                    f"margin_protection={item['margin_protection']}, "
                    f"customer_fit={item['customer_fit']}, "
                    f"risk={item['risk']}, "
                    f"total={item['total_score']}"
                ),
                f"   Judge rationale: {item['rationale']}",
            ]
        )
    return lines


def format_expanded_rankings(items: list[dict]) -> list[str]:
    lines: list[str] = []
    for index, item in enumerate(items, start=1):
        parent = item["parent_strategy"]
        step = item["step"]
        lines.extend(
            [
                f"{index}. From {parent['id']} - {parent['title']}",
                f"   Expanded branch: {step['title']}",
                f"   Concrete action: {step['concrete_action']}",
                f"   Customer impact: {step['customer_impact']}",
                f"   Risk note: {step['risk_note']}",
                (
                    "   Scores: "
                    f"stock_safety={item['stock_safety']}, "
                    f"margin_protection={item['margin_protection']}, "
                    f"execution_clarity={item['execution_clarity']}, "
                    f"risk={item['risk']}, "
                    f"total={item['total_score']}"
                ),
                f"   Judge rationale: {item['rationale']}",
            ]
        )
    return lines


def final_select(state: SearchState) -> dict:
    ranked_strategies = sorted(
        state["scored_strategies"],
        key=lambda item: item["total_score"],
        reverse=True,
    )
    ranked_steps = sorted(
        state["expanded_steps"],
        key=lambda item: item["total_score"],
        reverse=True,
    )

    best_step = ranked_steps[0]
    winning_parent = best_step["parent_strategy"]
    winning_step = best_step["step"]
    selected_frontier_ids = {strategy["id"] for strategy in state["frontier"]}
    selected_frontier = [
        item for item in ranked_strategies if item["strategy"]["id"] in selected_frontier_ids
    ]

    lines = [
        "TREE-OF-THOUGHT SELECTION PROCESS",
        "",
        "Scenario:",
        state["scenario"],
        "",
        "Stage 1 - Initial strategy generation and scoring:",
        *format_strategy_rankings(ranked_strategies),
        "",
        f"Stage 1 decision - Keep the top {TOP_K} strategies in the frontier:",
        *[
            f"- {item['strategy']['id']} - {item['strategy']['title']} (total={item['total_score']})"
            for item in selected_frontier
        ],
        "",
        "Stage 2 - Expand each frontier strategy by one concrete next step and score again:",
        *format_expanded_rankings(ranked_steps),
        "",
        "Final selection:",
        f"Selected strategy family: {winning_parent['id']} - {winning_parent['title']}",
        f"Selected branch: {winning_step['title']}",
        f"Why it won: {best_step['rationale']}",
        "",
        "Final recommended action:",
        winning_step["concrete_action"],
        "",
        "Expected customer impact:",
        winning_step["customer_impact"],
        "",
        "Risk note:",
        winning_step["risk_note"],
        "",
        (
            "Winning scores: "
            f"stock_safety={best_step['stock_safety']}, "
            f"margin_protection={best_step['margin_protection']}, "
            f"execution_clarity={best_step['execution_clarity']}, "
            f"risk={best_step['risk']}, "
            f"total={best_step['total_score']}"
        ),
    ]

    return {"final_answer": "\n".join(lines)}


builder = StateGraph(SearchState)

builder.add_node("generate_strategies", generate_strategies)
builder.add_node("score_strategy", score_strategy)
builder.add_node("select_frontier", select_frontier)
builder.add_node("expand_step", expand_step)
builder.add_node("final_select", final_select)

builder.add_edge(START, "generate_strategies")
builder.add_conditional_edges("generate_strategies", assign_strategy_scorers)
builder.add_edge("score_strategy", "select_frontier")
builder.add_conditional_edges("select_frontier", assign_expanders)
builder.add_edge("expand_step", "final_select")
builder.add_edge("final_select", END)

graph = builder.compile()


if __name__ == "__main__":
    scenario = """
Demand for a trending accessory just spiked after a social-media mention.
Only 120 units remain. The product has excellent margin, but a stock-out would
damage customer trust. Marketing wants guidance on what to do today.
""".strip()

    result = graph.invoke(
        {"scenario": scenario},
        config={"recursion_limit": 20},
    )

    print(result["final_answer"])
