from __future__ import annotations
from typing import Literal
from typing_extensions import TypedDict
from pydantic import BaseModel, Field
from langchain.chat_models import init_chat_model
from langgraph.graph import StateGraph, START, END
from .config import OPENAI_API_KEY

DOCS = [
    "Orders over 50 euros ship free.",
    "Digital gift cards are delivered by email.",
    "Digital gift cards are non-refundable.",
    "Physical gift items may be returned within 30 days for store credit."
]

class ClaimList(BaseModel):
    claims: list[str] = Field(default_factory=list)

class ClaimCheck(BaseModel):
    claim: str
    verdict: Literal["supported", "unsupported"]
    evidence: str

class State(TypedDict):
    question: str
    draft: str
    claims: list[str]
    checks: list[dict]
    final_answer: str

writer = init_chat_model("openai:gpt-4.1-mini", temperature=0)
claim_extractor = init_chat_model("openai:gpt-4.1-mini", temperature=0).with_structured_output(
    ClaimList
)
verifier = init_chat_model("openai:gpt-4.1-mini", temperature=0).with_structured_output(
    ClaimCheck
)

def write_draft(state: State) -> dict:
    msg = writer.invoke(f"""
Answer this customer question using the policy notes below.

Policy notes:
{chr(10).join("- " + d for d in DOCS)}

Question:
{state["question"]}
""")
    return {"draft": msg.content}

def extract_claims(state: State) -> dict:
    result = claim_extractor.invoke(f"""
Extract the material factual claims from this answer.

Answer:
{state["draft"]}
""")
    return {"claims": result.claims}

def verify_claims(state: State) -> dict:
    checks = []
    docs_block = "\n".join(DOCS)
    for claim in state["claims"]:
        result = verifier.invoke(f"""
Check whether this claim is supported by the documents.

Claim:
{claim}

Documents:
{docs_block}
""")
        checks.append(result.model_dump())
    return {"checks": checks}

def synthesize_verified_answer(state: State) -> dict:
    supported = [c for c in state["checks"] if c["verdict"] == "supported"]
    unsupported = [c for c in state["checks"] if c["verdict"] == "unsupported"]

    parts = []
    if supported:
        parts.append("Supported points:")
        for item in supported:
            parts.append(f"- {item['claim']}")

    if unsupported:
        parts.append("\nUnsupported or not established:")
        for item in unsupported:
            parts.append(f"- {item['claim']}")

    return {"final_answer": "\n".join(parts)}

builder = StateGraph(State)
builder.add_node("write_draft", write_draft)
builder.add_node("extract_claims", extract_claims)
builder.add_node("verify_claims", verify_claims)
builder.add_node("synthesize_verified_answer", synthesize_verified_answer)

builder.add_edge(START, "write_draft")
builder.add_edge("write_draft", "extract_claims")
builder.add_edge("extract_claims", "verify_claims")
builder.add_edge("verify_claims", "synthesize_verified_answer")
builder.add_edge("synthesize_verified_answer", END)

graph = builder.compile()

if __name__ == "__main__":
    result = graph.invoke({
        "question": "Do gift cards ship free and can they be refunded?",
        "draft": "",
        "claims": [],
        "checks": [],
        "final_answer": "",
    })

    print("DRAFT:\n")
    print(result["draft"])
    print("\nCLAIMS:\n")
    for claim in result["claims"]:
        print("-", claim)
    print("\nVERIFIED ANSWER:\n")
    print(result["final_answer"])
