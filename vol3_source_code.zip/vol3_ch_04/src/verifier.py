from __future__ import annotations

from typing import Literal
from typing_extensions import TypedDict
from pydantic import BaseModel, Field

from langchain.chat_models import init_chat_model
from langgraph.graph import StateGraph, START, END
from .config import OPENAI_API_KEY

POLICIES = [
    {
        "id": "returns_standard",
        "text": "Most physical items can be returned within 30 days of delivery for a refund to the original payment method.",
    },
    {
        "id": "returns_damaged",
        "text": "Damaged or defective items may be refunded or replaced when reported within 14 days of delivery.",
    },
    {
        "id": "returns_gifts",
        "text": "Gift returns are eligible for store credit only and must still be requested within the standard 30-day return window.",
    },
]

MAX_ATTEMPTS = 2


class VerificationResult(BaseModel):
    verdict: Literal["supported", "needs_revision", "insufficient_evidence"] = Field(
        description="Whether the draft is supported by the evidence."
    )
    critique: str = Field(
        description="Concrete feedback describing what is wrong or missing."
    )
    grounded_facts: list[str] = Field(
        default_factory=list,
        description="Short statements directly supported by the evidence.",
    )


class SupportState(TypedDict):
    question: str
    evidence: list[str]
    draft: str
    critique: str
    grounded_facts: list[str]
    verdict: Literal["", "supported", "needs_revision", "insufficient_evidence", "abstained"]
    attempts: int
    final_answer: str


generator = init_chat_model("openai:gpt-4.1-mini", temperature=0)
verifier = init_chat_model("openai:gpt-4.1", temperature=0).with_structured_output(
    VerificationResult
)


def retrieve_policy_evidence(state: SupportState) -> dict:
    question_terms = {
        token.strip(".,?!:;").lower()
        for token in state["question"].split()
        if len(token.strip(".,?!:;")) > 2
    }

    scored: list[tuple[int, str]] = []
    for item in POLICIES:
        policy_terms = {
            token.strip(".,?!:;").lower()
            for token in item["text"].split()
            if len(token.strip(".,?!:;")) > 2
        }
        overlap = len(question_terms & policy_terms)
        if overlap > 0:
            scored.append((overlap, f"[{item['id']}] {item['text']}"))

    scored.sort(key=lambda x: x[0], reverse=True)
    evidence = [text for _, text in scored[:3]]
    return {"evidence": evidence}



def write_draft(state: SupportState) -> dict:
    evidence_block = "\n".join(state["evidence"]) if state["evidence"] else "NO_EVIDENCE"

    if state["critique"]:
        instruction = f"""
Revise the answer using the critique below.

Critique:
{state["critique"]}
"""
    else:
        instruction = "Write the first draft."

    prompt = f"""
You are a customer support assistant.
Answer the user's question using only the policy evidence below.
Do not invent rules, exceptions, or timelines.
If the evidence is insufficient, say so plainly.

User question:
{state["question"]}

Policy evidence:
{evidence_block}

{instruction}
"""

    msg = generator.invoke(prompt)
    return {"draft": msg.content, "attempts": state["attempts"] + 1}



def verify_draft(state: SupportState) -> dict:
    evidence_block = "\n".join(state["evidence"]) if state["evidence"] else "NO_EVIDENCE"

    result = verifier.invoke(f"""
You are verifying a support answer against policy evidence.

User question:
{state["question"]}

Draft answer:
{state["draft"]}

Policy evidence:
{evidence_block}

Rules:
1. Mark "supported" only if the draft's material claims are justified by the evidence.
2. Mark "needs_revision" if the answer is close but overstates, omits a key condition, or mixes supported and unsupported claims.
3. Mark "insufficient_evidence" if the evidence does not justify answering the question safely.
4. grounded_facts must contain only short statements directly supported by the evidence.
""")

    return {
        "verdict": result.verdict,
        "critique": result.critique,
        "grounded_facts": result.grounded_facts,
    }



def route_after_verification(state: SupportState) -> str:
    if state["verdict"] == "supported":
        return "accept"
    if state["verdict"] == "insufficient_evidence" or state["attempts"] >= MAX_ATTEMPTS:
        return "abstain"
    return "revise"



def accept_answer(state: SupportState) -> dict:
    return {
        "final_answer": state["draft"],
        "verdict": "supported",
    }



def abstain(state: SupportState) -> dict:
    if state["verdict"] == "insufficient_evidence":
        final_critique = state["critique"] or (
            "The retrieved policy evidence does not safely answer the user's question."
        )
    else:
        base = state["critique"].strip()
        suffix = (
            "Maximum revision attempts reached before producing a supported answer. "
            "The workflow is failing closed and escalating to a human."
        )
        final_critique = f"{base}\n\n{suffix}" if base else suffix

    return {
        "final_answer": (
            "I cannot answer this safely from the retrieved policy evidence. "
            "Please ask a human support agent to review the case."
        ),
        "verdict": "abstained",
        "critique": final_critique,
    }


builder = StateGraph(SupportState)
builder.add_node("retrieve_policy_evidence", retrieve_policy_evidence)
builder.add_node("write_draft", write_draft)
builder.add_node("verify_draft", verify_draft)
builder.add_node("accept_answer", accept_answer)
builder.add_node("abstain", abstain)

builder.add_edge(START, "retrieve_policy_evidence")
builder.add_edge("retrieve_policy_evidence", "write_draft")
builder.add_edge("write_draft", "verify_draft")
builder.add_conditional_edges(
    "verify_draft",
    route_after_verification,
    {
        "accept": "accept_answer",
        "revise": "write_draft",
        "abstain": "abstain",
    },
)
builder.add_edge("accept_answer", END)
builder.add_edge("abstain", END)

graph = builder.compile()

if __name__ == "__main__":
    result = graph.invoke(
        {
            "question": "Can I get a refund for a gift card purchase?",
            "evidence": [],
            "draft": "",
            "critique": "",
            "grounded_facts": [],
            "verdict": "",
            "attempts": 0,
            "final_answer": "",
        }
    )

    print("QUESTION:\n")
    print(result["question"])
    print("\nFINAL ANSWER:\n")
    print(result["final_answer"])
    print("\nVERDICT:", result["verdict"])
    print("\nCRITIQUE:\n")
    print(result["critique"])
    print("\nEVIDENCE:")
    for item in result["evidence"]:
        print("-", item)
