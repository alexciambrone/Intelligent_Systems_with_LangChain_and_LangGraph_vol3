from __future__ import annotations

from operator import add
from typing import Annotated, Literal

from typing_extensions import TypedDict
from pydantic import BaseModel, Field
from langchain.chat_models import init_chat_model
from langgraph.graph import StateGraph, START, END
from .config import OPENAI_API_KEY


SAFE_ABSTENTION = "I do not have enough evidence to answer safely."


class Verification(BaseModel):
    verdict: Literal["accept", "revise", "abstain"] = Field(
        description=(
            "accept if the draft answers the question as far as the evidence allows "
            "and every non-trivial claim is supported; "
            "revise if the answer can be improved from the same evidence, including "
            "when the draft abstains but a partial or conditional answer is possible; "
            "abstain only if the evidence truly does not support even a partial or conditional answer"
        )
    )
    answers_question: bool = Field(
        description="Whether the draft answers the user's question as far as the evidence allows."
    )
    abstention_justified: bool = Field(
        description=(
            "True only if the evidence is genuinely insufficient to support even a partial "
            "or conditional answer."
        )
    )
    feedback: str = Field(
        description="Concrete instruction for improving the answer."
    )
    unsupported_claims: list[str] = Field(
        default_factory=list,
        description="Claims in the draft that are not supported by the evidence."
    )
    missed_supported_points: list[str] = Field(
        default_factory=list,
        description="Important supported points from the evidence that the draft omitted."
    )


class State(TypedDict):
    question: str
    evidence: str
    draft: str
    final_answer: str
    verdict: Literal["", "accept", "revise", "abstain"]
    answers_question: bool
    abstention_justified: bool
    feedback: str
    unsupported_claims: list[str]
    missed_supported_points: list[str]
    attempts: int
    max_attempts: int
    trace: Annotated[list[str], add]


writer = init_chat_model("openai:gpt-4.1-mini", temperature=0)
verifier = init_chat_model(
    "openai:gpt-4.1-mini",
    temperature=0
).with_structured_output(Verification)


def draft_answer(state: State) -> dict:
    msg = writer.invoke(
        f"""You are a customer support assistant.

Answer the question using the evidence only.
Do not invent policy details.
Prefer a direct answer when the evidence supports one.
If the evidence supports only a partial, limited, or conditional answer, give that answer clearly.
Use "{SAFE_ABSTENTION}" only when the evidence does not support even a partial or conditional answer.

Question:
{state["question"]}

Evidence:
{state["evidence"]}

Previous verifier feedback:
{state["feedback"] if state["feedback"] else "None"}
"""
    )
    return {
        "draft": msg.content,
        "trace": [f'draft_answer: produced draft={msg.content!r}'],
    }


def verify_answer(state: State) -> dict:
    result = verifier.invoke(
        f"""Evaluate the draft answer against the question and the evidence.

Decision rules:
- accept:
  * every non-trivial claim in the draft is supported by the evidence, and
  * the draft answers the question as far as the evidence allows.
- revise:
  * the draft can be improved using the same evidence, including cases where:
    - the draft abstains but the evidence supports a partial or conditional answer,
    - the draft omits important supported conditions or exceptions,
    - the draft contains unsupported claims that can be removed.
- abstain:
  * only if the evidence truly does not support even a partial or conditional answer.

Question:
{state["question"]}

Evidence:
{state["evidence"]}

Draft:
{state["draft"]}
"""
    )

    return {
        "verdict": result.verdict,
        "answers_question": result.answers_question,
        "abstention_justified": result.abstention_justified,
        "feedback": result.feedback,
        "unsupported_claims": result.unsupported_claims,
        "missed_supported_points": result.missed_supported_points,
        "trace": [
            "verify_answer: "
            f"verdict={result.verdict}, "
            f"answers_question={result.answers_question}, "
            f"abstention_justified={result.abstention_justified}, "
            f"unsupported_claims={result.unsupported_claims}, "
            f"missed_supported_points={result.missed_supported_points}"
        ],
    }


def revise_answer(state: State) -> dict:
    msg = writer.invoke(
        f"""Revise the answer strictly from the evidence.

Rules:
- Remove unsupported claims.
- Add any missing supported points that are necessary to answer the question.
- If the evidence supports only a conditional or limited answer, say that explicitly.
- Use "{SAFE_ABSTENTION}" only if the evidence truly does not support even a partial or conditional answer.

Unsupported claims to remove:
{state["unsupported_claims"] if state["unsupported_claims"] else "None"}

Supported points you missed:
{state["missed_supported_points"] if state["missed_supported_points"] else "None"}

Verifier feedback:
{state["feedback"]}

Question:
{state["question"]}

Evidence:
{state["evidence"]}

Current draft:
{state["draft"]}
"""
    )

    next_attempts = state["attempts"] + 1
    return {
        "draft": msg.content,
        "attempts": next_attempts,
        "trace": [
            f"revise_answer: attempts={next_attempts}, revised_draft={msg.content!r}"
        ],
    }


def accept_answer(state: State) -> dict:
    return {
        "final_answer": state["draft"],
        "trace": ["accept_answer: final draft accepted"],
    }


def abstain(state: State) -> dict:
    return {
        "final_answer": SAFE_ABSTENTION,
        "trace": ["abstain: evidence truly insufficient or revision budget exhausted"],
    }


def route_after_verification(state: State) -> str:
    # Accept only when the verifier explicitly says the draft both:
    # 1) is supported by evidence, and
    # 2) answers the question as far as the evidence allows.
    if state["verdict"] == "accept" and state["answers_question"]:
        return "accept"

    # Only abstain when the verifier says abstention is actually justified.
    if state["verdict"] == "abstain" and state["abstention_justified"]:
        return "abstain"

    # If we have already used the allowed revision budget, fail closed.
    if state["attempts"] >= state["max_attempts"]:
        return "abstain"

    return "revise"


builder = StateGraph(State)
builder.add_node("draft_answer", draft_answer)
builder.add_node("verify_answer", verify_answer)
builder.add_node("revise_answer", revise_answer)
builder.add_node("accept_answer", accept_answer)
builder.add_node("abstain", abstain)

builder.add_edge(START, "draft_answer")
builder.add_edge("draft_answer", "verify_answer")
builder.add_conditional_edges(
    "verify_answer",
    route_after_verification,
    {
        "accept": "accept_answer",
        "revise": "revise_answer",
        "abstain": "abstain",
    },
)
builder.add_edge("revise_answer", "verify_answer")
builder.add_edge("accept_answer", END)
builder.add_edge("abstain", END)

graph = builder.compile()


if __name__ == "__main__":
    result = graph.invoke(
        {
            "question": "Can this gift order be refunded to the original payment method?",
            "evidence": """
Gift purchases: eligible refunds are issued as store credit unless the original purchaser requests the refund.
Standard items: refundable within 30 days if unopened.
""",
            "draft": "",
            "final_answer": "",
            "verdict": "",
            "answers_question": False,
            "abstention_justified": False,
            "feedback": "",
            "unsupported_claims": [],
            "missed_supported_points": [],
            "attempts": 0,
            "max_attempts": 1,
            "trace": [],
        }
    )

    print("VERDICT:", result["verdict"])
    print("FINAL ANSWER:")
    print(result["final_answer"])

    print("\nTRACE:")
    for step in result["trace"]:
        print("-", step)