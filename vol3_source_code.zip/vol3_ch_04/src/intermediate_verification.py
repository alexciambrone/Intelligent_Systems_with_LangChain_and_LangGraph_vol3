from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field
from typing_extensions import TypedDict
from langchain.chat_models import init_chat_model
from langgraph.graph import END, START, StateGraph

from .config import OPENAI_API_KEY

DOCS = [
    "Battery replacement is available as a paid repair.",
    "Standard laptop warranty lasts 2 years.",
    "Battery defects are covered for 1 year under the limited warranty.",
    "Screen defects are covered for 2 years under the limited warranty.",
]

QUESTION = "What is the battery warranty?"


class QuestionAnalysis(BaseModel):
    required_terms: list[str] = Field(
        description=(
            "Short list of lower-case terms that must appear in supporting evidence "
            "for the question to be answerable."
        )
    )
    answer_focus: str = Field(
        description="Very short description of the exact relation the evidence must support."
    )


class RetrievalAssessment(BaseModel):
    status: Literal["good", "bad"]
    reason: str
    supporting_doc_numbers: list[int] = Field(
        default_factory=list,
        description=(
            "1-based document numbers that directly support the answer. Return an empty "
            "list when the evidence is not good enough."
        ),
    )


class State(TypedDict):
    question: str
    required_terms: list[str]
    answer_focus: str
    loose_docs: list[str]
    repaired_docs: list[str]
    retrieved_docs: list[str]
    first_validation_status: Literal["", "good", "bad"]
    first_validation_reason: str
    second_validation_status: Literal["", "good", "bad"]
    second_validation_reason: str
    retrieval_status: Literal["", "good", "bad"]
    validation_reason: str
    route_history: list[str]
    answer: str


base_model = init_chat_model(
    "openai:gpt-4.1-mini",
    temperature=0,
    api_key=OPENAI_API_KEY,
)
question_model = base_model.with_structured_output(QuestionAnalysis)
verification_model = base_model.with_structured_output(RetrievalAssessment)


def normalize(text: str) -> list[str]:
    return [token.strip(".,?!:;").lower() for token in text.split()]


def format_docs(docs: list[str]) -> str:
    if not docs:
        return "(no documents)"
    return "\n".join(f"{i}. {doc}" for i, doc in enumerate(docs, start=1))


def analyze_question(state: State) -> dict:
    result = question_model.invoke(
        [
            {
                "role": "system",
                "content": (
                    "Extract the minimum evidence requirements needed to answer a support "
                    "question. Return only a short list of lower-case required terms and a "
                    "brief answer_focus."
                ),
            },
            {
                "role": "user",
                "content": f"Question: {state['question']}",
            },
        ]
    )
    required_terms = [term.strip().lower() for term in result.required_terms if term.strip()]
    return {
        "required_terms": required_terms,
        "answer_focus": result.answer_focus.strip(),
        "route_history": ["analyze_question"],
    }


def retrieve_loose(state: State) -> dict:
    question_terms = set(normalize(state["question"])) | set(state["required_terms"])
    loose_docs: list[str] = []

    # Intentionally broad first pass: keep the first overlapping documents in corpus order.
    # This simulates a high-recall but low-precision retriever that may gather related text
    # without proving the exact relation the question asks about.
    for doc in DOCS:
        if question_terms & set(normalize(doc)):
            loose_docs.append(doc)
        if len(loose_docs) == 2:
            break

    return {
        "loose_docs": loose_docs,
        "retrieved_docs": loose_docs,
        "route_history": state["route_history"] + ["retrieve_loose"],
    }


def verify_retrieval(state: State) -> dict:
    docs_text = format_docs(state["retrieved_docs"])
    result = verification_model.invoke(
        [
            {
                "role": "system",
                "content": (
                    "You are validating an intermediate retrieval result before the workflow "
                    "is allowed to generate an answer. Mark the retrieval as good only when "
                    "at least one retrieved document directly supports the answer_focus for "
                    "the question. Do not accept evidence that only mentions related words "
                    "across separate documents."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"Question: {state['question']}\n"
                    f"Required terms: {', '.join(state['required_terms'])}\n"
                    f"Answer focus: {state['answer_focus']}\n\n"
                    f"Retrieved documents:\n{docs_text}"
                ),
            },
        ]
    )

    return {
        "first_validation_status": result.status,
        "first_validation_reason": result.reason.strip(),
        "retrieval_status": result.status,
        "validation_reason": result.reason.strip(),
        "route_history": state["route_history"] + [
            "validation_passed" if result.status == "good" else "validation_failed"
        ],
    }


def route_after_validation(state: State) -> Literal["repair", "synthesize"]:
    return "synthesize" if state["retrieval_status"] == "good" else "repair"


def retrieve_strict(state: State) -> dict:
    required = set(state["required_terms"])
    repaired_docs = [doc for doc in DOCS if required.issubset(set(normalize(doc)))]
    return {
        "repaired_docs": repaired_docs,
        "retrieved_docs": repaired_docs,
        "route_history": state["route_history"] + ["retrieve_strict"],
    }


def reverify_retrieval(state: State) -> dict:
    docs_text = format_docs(state["retrieved_docs"])
    result = verification_model.invoke(
        [
            {
                "role": "system",
                "content": (
                    "You are re-checking repaired evidence. Mark it good only if the current "
                    "documents now directly support the answer_focus."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"Question: {state['question']}\n"
                    f"Required terms: {', '.join(state['required_terms'])}\n"
                    f"Answer focus: {state['answer_focus']}\n\n"
                    f"Retrieved documents:\n{docs_text}"
                ),
            },
        ]
    )

    return {
        "second_validation_status": result.status,
        "second_validation_reason": result.reason.strip(),
        "retrieval_status": result.status,
        "validation_reason": result.reason.strip(),
        "route_history": state["route_history"]
        + ["repair_succeeded" if result.status == "good" else "repair_failed"],
    }


def synthesize_answer(state: State) -> dict:
    if state["retrieval_status"] != "good" or not state["retrieved_docs"]:
        return {
            "answer": "I do not have enough verified evidence to answer safely.",
            "route_history": state["route_history"] + ["abstain"],
        }

    docs_text = format_docs(state["retrieved_docs"])
    response = base_model.invoke(
        [
            {
                "role": "system",
                "content": (
                    "Answer the user using only the verified evidence. Keep the answer short. "
                    "Do not add facts that are not in the retrieved documents."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"Question: {state['question']}\n\n"
                    f"Verified evidence:\n{docs_text}"
                ),
            },
        ]
    )
    return {
        "answer": response.content.strip(),
        "route_history": state["route_history"] + ["synthesize_answer"],
    }


builder = StateGraph(State)
builder.add_node("analyze_question", analyze_question)
builder.add_node("retrieve_loose", retrieve_loose)
builder.add_node("verify_retrieval", verify_retrieval)
builder.add_node("retrieve_strict", retrieve_strict)
builder.add_node("reverify_retrieval", reverify_retrieval)
builder.add_node("synthesize_answer", synthesize_answer)

builder.add_edge(START, "analyze_question")
builder.add_edge("analyze_question", "retrieve_loose")
builder.add_edge("retrieve_loose", "verify_retrieval")
builder.add_conditional_edges(
    "verify_retrieval",
    route_after_validation,
    {
        "repair": "retrieve_strict",
        "synthesize": "synthesize_answer",
    },
)
builder.add_edge("retrieve_strict", "reverify_retrieval")
builder.add_edge("reverify_retrieval", "synthesize_answer")
builder.add_edge("synthesize_answer", END)

graph = builder.compile()


DEFAULT_STATE: State = {
    "question": QUESTION,
    "required_terms": [],
    "answer_focus": "",
    "loose_docs": [],
    "repaired_docs": [],
    "retrieved_docs": [],
    "first_validation_status": "",
    "first_validation_reason": "",
    "second_validation_status": "",
    "second_validation_reason": "",
    "retrieval_status": "",
    "validation_reason": "",
    "route_history": [],
    "answer": "",
}


def run_case(question: str) -> None:
    state = dict(DEFAULT_STATE)
    state["question"] = question
    result = graph.invoke(state)

    print("QUESTION:")
    print(result["question"])

    print("\nQUESTION ANALYSIS:")
    print("REQUIRED TERMS:", ", ".join(result["required_terms"]))
    print("ANSWER FOCUS:", result["answer_focus"])

    print("\nLOOSE RETRIEVAL:")
    for doc in result["loose_docs"]:
        print(f"- {doc}")

    print("\nFIRST INTERMEDIATE VALIDATION:")
    print("STATUS:", result["first_validation_status"])
    print("REASON:", result["first_validation_reason"])

    if result["repaired_docs"]:
        print("\nSTRICT RETRIEVAL:")
        for doc in result["repaired_docs"]:
            print(f"- {doc}")

        print("\nSECOND INTERMEDIATE VALIDATION:")
        print("STATUS:", result["second_validation_status"])
        print("REASON:", result["second_validation_reason"])

    print("\nROUTE HISTORY:")
    print(" -> ".join(result["route_history"]))

    print("\nFINAL VERIFIED EVIDENCE:")
    for doc in result["retrieved_docs"]:
        print(f"- {doc}")

    print("\nFINAL ANSWER:")
    print(result["answer"])


if __name__ == "__main__":
    run_case(QUESTION)
