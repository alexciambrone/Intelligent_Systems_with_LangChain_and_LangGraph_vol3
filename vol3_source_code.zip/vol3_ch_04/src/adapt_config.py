from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from langchain.agents import create_agent
from langchain.agents.middleware import AgentMiddleware, ModelRequest, dynamic_prompt
from langchain.agents.middleware.types import ModelResponse
from langchain.tools import ToolRuntime, tool
from langchain_openai import ChatOpenAI
from langgraph.store.memory import InMemoryStore

from .config import OPENAI_API_KEY


ORDERS = {
    "ORD-100": {
        "status": "delivered",
        "days_since_delivery": 12,
        "opened": False,
        "gift": True,
    },
    "ORD-101": {
        "status": "processing",
        "days_since_delivery": 0,
        "opened": False,
        "gift": False,
    },
}


@dataclass
class SupportContext:
    user_id: str
    user_role: str   # "beginner" | "expert"
    region: str      # "EU" | "US"


@tool
def lookup_order(order_id: str) -> dict:
    """Look up order status and return basic return facts."""
    order = ORDERS.get(order_id)
    if not order:
        return {
            "order_id": order_id,
            "error": f"Order {order_id} was not found.",
        }
    return {"order_id": order_id, **order}


@tool
def read_refund_policy(runtime: ToolRuntime[SupportContext]) -> str:
    """Return the refund-policy text for the user's region."""
    if runtime.context.region == "EU":
        return (
            "EU policy: standard items may be refunded within 30 days if unopened. "
            "Gift purchases are normally returned as store credit unless the policy "
            "explicitly states otherwise."
        )

    return (
        "US policy: standard items may be refunded within 30 days if unopened. "
        "Gift purchases follow the store-specific policy and may be handled as store credit."
    )


fast_model = ChatOpenAI(
    model="gpt-4.1-mini",
    temperature=0,
    api_key=OPENAI_API_KEY,
)

strong_model = ChatOpenAI(
    model="gpt-4.1",
    temperature=0,
    api_key=OPENAI_API_KEY,
)


def get_persistent_rule(store: InMemoryStore | None, user_id: str) -> str | None:
    if store is None:
        return None

    note = store.get(("adaptation_rules",), user_id)
    if not note:
        return None

    value = note.value or {}
    return value.get("instruction")


def build_support_prompt(ctx: SupportContext, store: InMemoryStore | None) -> str:
    base = (
        "You are a customer support assistant. "
        "Use tools for order facts and policy facts. "
        "Do not claim a policy outcome unless tool output supports it."
    )

    if ctx.user_role == "expert":
        base += " Keep the answer compact and operational."
    else:
        base += " Explain the answer in plain language."

    if ctx.region == "EU":
        base += " Prefer EU policy rules when they differ by region."
    else:
        base += " Prefer US policy rules when they differ by region."

    rule = get_persistent_rule(store, ctx.user_id)
    if rule:
        base += f" Persistent operating rule: {rule}"

    return base


def select_model(messages: list[dict]) -> tuple[str, ChatOpenAI, str]:
    last_user_text = ""
    if messages:
        last = messages[-1]
        last_user_text = str(last.get("content", "")).lower()

    reasons: list[str] = []

    if "policy" in last_user_text:
        reasons.append("message contains 'policy'")
    if "gift" in last_user_text:
        reasons.append("message contains 'gift'")
    if "exception" in last_user_text:
        reasons.append("message contains 'exception'")
    if len(messages) > 4:
        reasons.append("conversation has more than 4 messages")

    if reasons:
        return "gpt-4.1", strong_model, "; ".join(reasons)

    return "gpt-4.1-mini", fast_model, "default fast path"


@dynamic_prompt
def support_prompt(request: ModelRequest) -> str:
    return build_support_prompt(
        ctx=request.runtime.context,
        store=request.runtime.store,
    )


class DynamicModelMiddleware(AgentMiddleware):
    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelResponse:
        # Reuse the same logic used by the console demo so the
        # visible trace and the actual execution stay aligned.
        visible_messages: list[dict] = []
        for msg in request.messages:
            visible_messages.append(
                {
                    "role": getattr(msg, "type", "message"),
                    "content": str(getattr(msg, "content", "")),
                }
            )

        _, selected_model, _ = select_model(visible_messages)
        return handler(request.override(model=selected_model))


def build_store(include_rule: bool) -> InMemoryStore:
    store = InMemoryStore()

    if include_rule:
        store.put(
            ("adaptation_rules",),
            "user-123",
            {
                "instruction": (
                    "Do not promise a cash refund for gift purchases unless the policy text "
                    "states it explicitly."
                )
            },
        )

    return store


def build_agent(store: InMemoryStore):
    return create_agent(
        model=fast_model,
        tools=[lookup_order, read_refund_policy],
        middleware=[support_prompt, DynamicModelMiddleware()],
        context_schema=SupportContext,
        store=store,
    )


def print_separator() -> None:
    print("=" * 100)


def print_title(title: str) -> None:
    print_separator()
    print(title)
    print_separator()


def describe_adaptation(
    *,
    ctx: SupportContext,
    user_message: str,
    store: InMemoryStore,
) -> None:
    visible_messages = [{"role": "user", "content": user_message}]
    model_name, _, model_reason = select_model(visible_messages)
    persistent_rule = get_persistent_rule(store, ctx.user_id)
    effective_prompt = build_support_prompt(ctx, store)

    print("ADAPTATION TRACE")
    print(f"  user_id           : {ctx.user_id}")
    print(f"  user_role         : {ctx.user_role}")
    print(f"  region            : {ctx.region}")
    print(f"  selected_model    : {model_name}")
    print(f"  selection_reason  : {model_reason}")
    print(
        "  role_adaptation   : "
        + (
            "plain-language explanation"
            if ctx.user_role == "beginner"
            else "compact operational answer"
        )
    )
    print(
        "  region_adaptation : "
        + (
            "EU policy preference"
            if ctx.region == "EU"
            else "US policy preference"
        )
    )
    print(
        "  store_rule        : "
        + (persistent_rule if persistent_rule else "none")
    )
    print()
    print("EFFECTIVE SYSTEM PROMPT")
    print(f"  {effective_prompt}")
    print()


def run_case(
    *,
    title: str,
    user_message: str,
    ctx: SupportContext,
    include_rule: bool,
) -> None:
    print_title(title)

    store = build_store(include_rule=include_rule)
    agent = build_agent(store)

    print("USER MESSAGE")
    print(f"  {user_message}")
    print()

    describe_adaptation(
        ctx=ctx,
        user_message=user_message,
        store=store,
    )

    result = agent.invoke(
        {"messages": [{"role": "user", "content": user_message}]},
        context=ctx,
    )

    final_answer = result["messages"][-1].content

    print("FINAL ANSWER")
    print(final_answer)
    print()


def main() -> None:
    run_case(
        title="CASE 1 - Beginner user, EU region, gift refund question",
        user_message="Can I get a refund for order ORD-100 if it was a gift?",
        ctx=SupportContext(
            user_id="user-123",
            user_role="beginner",
            region="EU",
        ),
        include_rule=True,
    )

    run_case(
        title="CASE 2 - Expert user, EU region, same question",
        user_message="Can I get a refund for order ORD-100 if it was a gift?",
        ctx=SupportContext(
            user_id="user-123",
            user_role="expert",
            region="EU",
        ),
        include_rule=True,
    )

    run_case(
        title="CASE 3 - Beginner user, US region, same question",
        user_message="Can I get a refund for order ORD-100 if it was a gift?",
        ctx=SupportContext(
            user_id="user-123",
            user_role="beginner",
            region="US",
        ),
        include_rule=True,
    )

    run_case(
        title="CASE 4 - Beginner user, EU region, simple order-status question",
        user_message="What is the status of order ORD-101?",
        ctx=SupportContext(
            user_id="user-123",
            user_role="beginner",
            region="EU",
        ),
        include_rule=True,
    )

    run_case(
        title="CASE 5 - Beginner user, US region, same gift question, persistent rule disabled",
        user_message="Can I get a refund for order ORD-100 if it was a gift?",
        ctx=SupportContext(
            user_id="user-123",
            user_role="beginner",
            region="US",
        ),
        include_rule=False,
    )


if __name__ == "__main__":
    main()