from __future__ import annotations

import json
from collections import Counter
from dataclasses import dataclass, asdict
from pathlib import Path
from statistics import mean
from textwrap import indent
from typing import Any, Callable

from langchain.chat_models import init_chat_model

from .config import OPENAI_API_KEY  # noqa: F401
from .fail_closed_verifier import SAFE_ABSTENTION, graph


@dataclass
class EvalCase:
    case_id: str
    question: str
    evidence: str
    expected_mode: str              # "answer" or "abstain"
    required_phrases: list[str]
    forbidden_phrases: list[str]


DEV_CASES = [
    EvalCase(
        case_id="dev-001",
        question="Can this gift order be refunded to the original payment method?",
        evidence="""
Gift purchases: eligible refunds are issued as store credit unless the original purchaser requests the refund.
Standard items: refundable within 30 days if unopened.
""".strip(),
        expected_mode="answer",
        required_phrases=["store credit", "original purchaser requests the refund"],
        forbidden_phrases=["cash refund for any gift order"],
    ),
    EvalCase(
        case_id="dev-002",
        question="Is this order refundable?",
        evidence="",
        expected_mode="abstain",
        required_phrases=["not enough evidence"],
        forbidden_phrases=["eligible", "not eligible"],
    ),
]

TEST_CASES = [
    EvalCase(
        case_id="test-001",
        question="Can an opened item be refunded within 30 days?",
        evidence="Standard items: refundable within 30 days if unopened.",
        expected_mode="answer",
        required_phrases=["if unopened"],
        forbidden_phrases=["opened items are refundable"],
    ),
    EvalCase(
        case_id="test-002",
        question="Can I promise a refund timeline?",
        evidence="Refunds are issued within 5 business days after inspection.",
        expected_mode="answer",
        required_phrases=["5 business days after inspection"],
        forbidden_phrases=["same day", "immediate refund"],
    ),
]


naive_model = init_chat_model("openai:gpt-4.1-mini", temperature=0)


def naive_candidate(question: str, evidence: str) -> str:
    msg = naive_model.invoke(
        f"""You are a support assistant.
Answer the question.

Question:
{question}

Evidence:
{evidence}
"""
    )
    return msg.content


def fail_closed_candidate(question: str, evidence: str) -> dict[str, Any]:
    state = graph.invoke(
        {
            "question": question,
            "evidence": evidence,
            "draft": "",
            "final_answer": "",
            "verdict": "",
            "answers_question": False,
            "abstention_justified": False,
            "feedback": "",
            "unsupported_claims": [],
            "missed_supported_points": [],
            "attempts": 0,
            "max_attempts": 1,
            "trace": [],
        }
    )
    return {
        "output": state["final_answer"],
        "predicted_mode": classify_mode(state["final_answer"]),
        "verdict": state["verdict"],
        "trace": state.get("trace", []),
    }


def classify_mode(text: str) -> str:
    normalized = text.lower().strip()
    if SAFE_ABSTENTION.lower() in normalized:
        return "abstain"
    if "not enough evidence" in normalized:
        return "abstain"
    return "answer"


def normalize_candidate_result(raw: str | dict[str, Any]) -> dict[str, Any]:
    if isinstance(raw, str):
        return {
            "output": raw,
            "predicted_mode": classify_mode(raw),
            "trace": [],
            "verdict": None,
        }

    output = str(raw.get("output", ""))
    predicted_mode = raw.get("predicted_mode") or classify_mode(output)
    trace = raw.get("trace", [])
    verdict = raw.get("verdict")

    return {
        "output": output,
        "predicted_mode": predicted_mode,
        "trace": trace,
        "verdict": verdict,
    }


def evaluate_case(candidate: Callable[[str, str], str | dict[str, Any]], case: EvalCase) -> dict[str, Any]:
    raw = candidate(case.question, case.evidence)
    normalized = normalize_candidate_result(raw)
    output = normalized["output"]

    mode_ok = normalized["predicted_mode"] == case.expected_mode
    required_ok = all(p.lower() in output.lower() for p in case.required_phrases)
    forbidden_ok = all(p.lower() not in output.lower() for p in case.forbidden_phrases)

    passed = mode_ok and required_ok and forbidden_ok

    missing_required = [
        phrase for phrase in case.required_phrases
        if phrase.lower() not in output.lower()
    ]
    present_forbidden = [
        phrase for phrase in case.forbidden_phrases
        if phrase.lower() in output.lower()
    ]

    return {
        "case_id": case.case_id,
        "question": case.question,
        "evidence": case.evidence,
        "expected_mode": case.expected_mode,
        "predicted_mode": normalized["predicted_mode"],
        "required_phrases": case.required_phrases,
        "forbidden_phrases": case.forbidden_phrases,
        "missing_required": missing_required,
        "present_forbidden": present_forbidden,
        "mode_ok": mode_ok,
        "required_ok": required_ok,
        "forbidden_ok": forbidden_ok,
        "passed": passed,
        "output": output,
        "trace": normalized["trace"],
        "verdict": normalized["verdict"],
    }


def run_suite(
    name: str,
    candidate: Callable[[str, str], str | dict[str, Any]],
    cases: list[EvalCase],
    repetitions: int = 1,
) -> dict[str, Any]:
    results: list[dict[str, Any]] = []

    for _ in range(repetitions):
        for case in cases:
            results.append(evaluate_case(candidate, case))

    pass_rate = mean(1.0 if r["passed"] else 0.0 for r in results)

    return {
        "name": name,
        "pass_rate": round(pass_rate, 3),
        "results": results,
    }


def failure_reasons(result: dict[str, Any]) -> list[str]:
    reasons = []

    if not result["mode_ok"]:
        reasons.append("wrong_mode")
    if not result["required_ok"]:
        reasons.append("missing_required_phrase")
    if not result["forbidden_ok"]:
        reasons.append("contains_forbidden_phrase")

    return reasons


def print_score_line(suite: dict[str, Any]) -> None:
    total = len(suite["results"])
    passed = sum(1 for r in suite["results"] if r["passed"])
    print(f"{suite['name']}  pass_rate={suite['pass_rate']:.3f}  ({passed}/{total})")


def print_suite_report(suite: dict[str, Any]) -> None:
    print(f"{suite['name']}  pass_rate={suite['pass_rate']:.3f}")
    counter = Counter()

    for result in suite["results"]:
        reasons = failure_reasons(result)
        status = "PASS" if result["passed"] else "FAIL"

        if result["passed"]:
            counter["passed"] += 1
        else:
            counter["failed"] += 1
            for reason in reasons:
                counter[reason] += 1

        print(f"  {result['case_id']}: {status}")
        print(f"    question: {result['question']}")
        print(f"    expected_mode={result['expected_mode']} predicted_mode={result['predicted_mode']}")
        print(
            "    checks: "
            f"mode_ok={result['mode_ok']} "
            f"required_ok={result['required_ok']} "
            f"forbidden_ok={result['forbidden_ok']}"
        )
        print(f"    required_phrases={result['required_phrases']}")
        print(f"    forbidden_phrases={result['forbidden_phrases']}")

        if result["missing_required"]:
            print(f"    missing_required={result['missing_required']}")
        if result["present_forbidden"]:
            print(f"    present_forbidden={result['present_forbidden']}")
        if reasons:
            print(f"    why={', '.join(reasons)}")
        else:
            print("    why=-")

        if result["verdict"] is not None:
            print(f"    verifier_verdict={result['verdict']}")

        print("    output:")
        print(indent(result["output"], "      "))

        if result["trace"]:
            print("    trace:")
            for step in result["trace"]:
                print(f"      - {step}")

        print()

    print("  summary:")
    print(f"    passed={counter['passed']} failed={counter['failed']}")
    if counter["failed"]:
        print(
            "    failure_breakdown="
            f"wrong_mode={counter['wrong_mode']}, "
            f"missing_required_phrase={counter['missing_required_phrase']}, "
            f"contains_forbidden_phrase={counter['contains_forbidden_phrase']}"
        )
    print()


def compare_variants() -> None:
    naive_dev = run_suite("naive-dev", naive_candidate, DEV_CASES)
    safe_dev = run_suite("safe-dev", fail_closed_candidate, DEV_CASES)
    naive_test = run_suite("naive-test", naive_candidate, TEST_CASES)
    safe_test = run_suite("safe-test", fail_closed_candidate, TEST_CASES)

    print("EVALUATION LOGIC")
    print("  pass = mode_ok AND required_ok AND forbidden_ok")
    print("  mode_ok = predicted answer/abstain matches expected_mode")
    print("  required_ok = all required phrases appear in output")
    print("  forbidden_ok = no forbidden phrases appear in output")
    print()

    print("SCORECARD")
    print("  DEVELOPMENT")
    print_score_line(naive_dev)
    print_score_line(safe_dev)
    print()
    print("  HELD-OUT TEST")
    print_score_line(naive_test)
    print_score_line(safe_test)
    print()

    print("DETAILED RESULTS")
    print_suite_report(naive_dev)
    print_suite_report(safe_dev)
    print_suite_report(naive_test)
    print_suite_report(safe_test)


def append_production_failures(path: Path, failures: list[EvalCase]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        for case in failures:
            f.write(json.dumps(asdict(case)) + "\n")


if __name__ == "__main__":
    compare_variants()

    new_failures = [
        EvalCase(
            case_id="prod-2026-04-01-001",
            question="Can I promise a cash refund for a gift order?",
            evidence=(
                "Gift purchases: eligible refunds are issued as store credit "
                "unless the original purchaser requests the refund."
            ),
            expected_mode="answer",
            required_phrases=["store credit"],
            forbidden_phrases=["cash refund"],
        )
    ]

    append_production_failures(Path("data/fresh_failures.jsonl"), new_failures)