from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel
from typing_extensions import TypedDict

from langchain.chat_models import init_chat_model
from langgraph.graph import END, START, StateGraph

from .config import OPENAI_API_KEY


class ParsedRequest(BaseModel):
    wants_refund: bool
    order_id: Optional[str] = None
    reason: Optional[str] = None


class State(TypedDict):
    user_message: str
    wants_refund: bool
    order_id: str | None
    reason: str | None
    next_step: Literal["", "clarify", "proceed"]
    response: str


parser = init_chat_model("openai:gpt-4.1-mini", temperature=0).with_structured_output(
    ParsedRequest
)


def parse_request(state: State) -> dict:
    result = parser.invoke(
        f"""
Parse the user's request.

User message:
{state["user_message"]}
"""
    )
    return {
        "wants_refund": result.wants_refund,
        "order_id": result.order_id,
        "reason": result.reason,
    }


def verify_inputs(state: State) -> dict:
    if state["wants_refund"] and not state["order_id"]:
        return {"next_step": "clarify"}
    return {"next_step": "proceed"}


def ask_clarification(state: State) -> dict:
    return {
        "response": "I can help with that, but I need your order ID before I can continue."
    }


def proceed(state: State) -> dict:
    return {
        "response": f"Refund request can be reviewed for order {state['order_id']}."
    }


def route_after_verification(state: State) -> str:
    return state["next_step"]


builder = StateGraph(State)
builder.add_node("parse_request", parse_request)
builder.add_node("verify_inputs", verify_inputs)
builder.add_node("ask_clarification", ask_clarification)
builder.add_node("proceed", proceed)

builder.add_edge(START, "parse_request")
builder.add_edge("parse_request", "verify_inputs")
builder.add_conditional_edges(
    "verify_inputs",
    route_after_verification,
    {
        "clarify": "ask_clarification",
        "proceed": "proceed",
    },
)
builder.add_edge("ask_clarification", END)
builder.add_edge("proceed", END)

graph = builder.compile()


if __name__ == "__main__":
    result = graph.invoke(
        {
            "user_message": "I want a refund for the shoes I bought last week.",
            "wants_refund": False,
            "order_id": None,
            "reason": None,
            "next_step": "",
            "response": "",
        }
    )

    print(result["response"])
