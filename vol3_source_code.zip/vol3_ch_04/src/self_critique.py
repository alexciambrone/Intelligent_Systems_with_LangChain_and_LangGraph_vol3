from __future__ import annotations
from typing import Literal
from typing_extensions import TypedDict
from pydantic import BaseModel, Field
from langchain.chat_models import init_chat_model
from langgraph.graph import StateGraph, START, END
from .config import OPENAI_API_KEY

class Critique(BaseModel):
    verdict: Literal["pass", "revise"]
    failure_category: Literal["clarity", "completeness", "format", "tone"]
    revision_instruction: str = Field(
        description="Concrete instruction for improving the draft."
    )

class State(TypedDict):
    request: str
    draft: str
    critique: str
    revised: str
    verdict: Literal["", "pass", "revise"]

model = init_chat_model("openai:gpt-4.1-mini", temperature=0)
critic = init_chat_model("openai:gpt-4.1-mini", temperature=0).with_structured_output(
    Critique
)

def write_draft(state: State) -> dict:
    msg = model.invoke(f"""
Write a short release note in 3 bullet points.

Request:
{state["request"]}
""")
    return {"draft": msg.content}

def critique_draft(state: State) -> dict:
    result = critic.invoke(f"""
Review the release note below.

Requirements:
- exactly 3 bullet points
- each bullet must be concise
- mention the user-visible improvement
- avoid marketing language

Draft:
{state["draft"]}
""")
    return {
        "verdict": result.verdict,
        "critique": result.revision_instruction,
    }

def revise_draft(state: State) -> dict:
    if state["verdict"] == "pass":
        return {"revised": state["draft"]}
    msg = model.invoke(f"""
Revise the release note using this instruction:

{state["critique"]}

Current draft:
{state["draft"]}
""")
    return {"revised": msg.content}

builder = StateGraph(State)
builder.add_node("write_draft", write_draft)
builder.add_node("critique_draft", critique_draft)
builder.add_node("revise_draft", revise_draft)

builder.add_edge(START, "write_draft")
builder.add_edge("write_draft", "critique_draft")
builder.add_edge("critique_draft", "revise_draft")
builder.add_edge("revise_draft", END)

graph = builder.compile()

if __name__ == "__main__":
    result = graph.invoke({
        "request": "The dashboard now loads faster and users can filter incidents by severity.",
        "draft": "",
        "critique": "",
        "revised": "",
        "verdict": "",
    })
    print("FIRST DRAFT:\n")
    print(result["draft"])
    print("\nCRITIQUE:\n")
    print(result["critique"])
    print("\nFINAL VERSION:\n")
    print(result["revised"])
