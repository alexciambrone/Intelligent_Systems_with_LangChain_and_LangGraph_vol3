from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from collections import defaultdict


@dataclass
class Exposure:
    exposure_id: str
    run_id: str
    component: str           # "retrieval" or "recommendation"
    policy_version: str
    item_id: str
    rank: int
    shown_at: datetime


@dataclass
class ClickEvent:
    exposure_id: str
    clicked_at: datetime


@dataclass
class ConversionEvent:
    exposure_id: str
    converted_at: datetime
    order_value: float


@dataclass
class TradeDecision:
    trade_id: str
    run_id: str
    strategy_version: str
    symbol: str
    opened_at: datetime


@dataclass
class TradeOutcome:
    trade_id: str
    closed_at: datetime
    pnl: float
    max_drawdown: float


EXPOSURES: list[Exposure] = []
CLICKS: list[ClickEvent] = []
CONVERSIONS: list[ConversionEvent] = []
TRADES: list[TradeDecision] = []
OUTCOMES: list[TradeOutcome] = []


def add_exposure(
    exposure_id: str,
    run_id: str,
    component: str,
    policy_version: str,
    item_id: str,
    rank: int,
    ts: str,
) -> None:
    EXPOSURES.append(
        Exposure(
            exposure_id=exposure_id,
            run_id=run_id,
            component=component,
            policy_version=policy_version,
            item_id=item_id,
            rank=rank,
            shown_at=datetime.fromisoformat(ts),
        )
    )


def add_click(exposure_id: str, ts: str) -> None:
    CLICKS.append(ClickEvent(exposure_id=exposure_id, clicked_at=datetime.fromisoformat(ts)))


def add_conversion(exposure_id: str, ts: str, order_value: float) -> None:
    CONVERSIONS.append(
        ConversionEvent(
            exposure_id=exposure_id,
            converted_at=datetime.fromisoformat(ts),
            order_value=order_value,
        )
    )


def add_trade(trade_id: str, run_id: str, strategy_version: str, symbol: str, ts: str) -> None:
    TRADES.append(
        TradeDecision(
            trade_id=trade_id,
            run_id=run_id,
            strategy_version=strategy_version,
            symbol=symbol,
            opened_at=datetime.fromisoformat(ts),
        )
    )


def add_trade_outcome(trade_id: str, ts: str, pnl: float, max_drawdown: float) -> None:
    OUTCOMES.append(
        TradeOutcome(
            trade_id=trade_id,
            closed_at=datetime.fromisoformat(ts),
            pnl=pnl,
            max_drawdown=max_drawdown,
        )
    )


def summarize_clicks() -> list[dict]:
    click_map = {event.exposure_id for event in CLICKS}
    grouped = defaultdict(lambda: {"shown": 0, "clicked": 0})

    for exposure in EXPOSURES:
        if exposure.component != "retrieval":
            continue

        key = (exposure.policy_version, exposure.rank)
        grouped[key]["shown"] += 1
        if exposure.exposure_id in click_map:
            grouped[key]["clicked"] += 1

    rows = []
    for (policy_version, rank), stats in sorted(grouped.items()):
        ctr = stats["clicked"] / stats["shown"]
        rows.append(
            {
                "component": "retrieval",
                "policy_version": policy_version,
                "rank": rank,
                "shown": stats["shown"],
                "clicked": stats["clicked"],
                "ctr": round(ctr, 3),
            }
        )
    return rows


def summarize_conversions(window_days: int = 7) -> list[dict]:
    exposure_map = {exposure.exposure_id: exposure for exposure in EXPOSURES}
    click_map = {event.exposure_id: event for event in CLICKS}
    grouped = defaultdict(lambda: {"clicked": 0, "converted": 0, "revenue": 0.0})

    for exposure_id, click in click_map.items():
        exposure = exposure_map.get(exposure_id)
        if not exposure or exposure.component != "recommendation":
            continue

        grouped[exposure.policy_version]["clicked"] += 1

    for conversion in CONVERSIONS:
        click = click_map.get(conversion.exposure_id)
        exposure = exposure_map.get(conversion.exposure_id)
        if not click or not exposure or exposure.component != "recommendation":
            continue

        delay = conversion.converted_at - click.clicked_at
        if delay <= timedelta(days=window_days):
            grouped[exposure.policy_version]["converted"] += 1
            grouped[exposure.policy_version]["revenue"] += conversion.order_value

    rows = []
    for policy_version, stats in sorted(grouped.items()):
        clicked = stats["clicked"]
        conv_rate = (stats["converted"] / clicked) if clicked else 0.0
        rows.append(
            {
                "component": "recommendation",
                "policy_version": policy_version,
                "clicked": clicked,
                "converted_within_window": stats["converted"],
                "conversion_rate": round(conv_rate, 3),
                "attributed_revenue": round(stats["revenue"], 2),
            }
        )
    return rows


def summarize_trades(risk_penalty: float = 0.5) -> list[dict]:
    trade_map = {trade.trade_id: trade for trade in TRADES}
    grouped = defaultdict(lambda: {"count": 0, "pnl": 0.0, "drawdown": 0.0, "risk_adjusted": 0.0})

    for outcome in OUTCOMES:
        trade = trade_map.get(outcome.trade_id)
        if not trade:
            continue

        grouped[trade.strategy_version]["count"] += 1
        grouped[trade.strategy_version]["pnl"] += outcome.pnl
        grouped[trade.strategy_version]["drawdown"] += outcome.max_drawdown
        grouped[trade.strategy_version]["risk_adjusted"] += outcome.pnl - (risk_penalty * outcome.max_drawdown)

    rows = []
    for strategy_version, stats in sorted(grouped.items()):
        count = stats["count"]
        rows.append(
            {
                "component": "trading",
                "strategy_version": strategy_version,
                "trades": count,
                "avg_pnl": round(stats["pnl"] / count, 2),
                "avg_max_drawdown": round(stats["drawdown"] / count, 2),
                "avg_risk_adjusted_score": round(stats["risk_adjusted"] / count, 2),
            }
        )
    return rows


def build_review_candidates() -> list[dict]:
    candidates = []

    for row in summarize_clicks():
        if row["rank"] == 1 and row["ctr"] < 0.2:
            candidates.append(
                {
                    "type": "retrieval_policy_review",
                    "policy_version": row["policy_version"],
                    "reason": f"Low rank-1 CTR ({row['ctr']})",
                }
            )

    for row in summarize_conversions():
        if row["clicked"] >= 2 and row["conversion_rate"] < 0.25:
            candidates.append(
                {
                    "type": "recommendation_policy_review",
                    "policy_version": row["policy_version"],
                    "reason": f"Low click-to-conversion rate ({row['conversion_rate']})",
                }
            )

    for row in summarize_trades():
        if row["avg_risk_adjusted_score"] < 0:
            candidates.append(
                {
                    "type": "trading_strategy_review",
                    "strategy_version": row["strategy_version"],
                    "reason": f"Negative average risk-adjusted score ({row['avg_risk_adjusted_score']})",
                }
            )

    return candidates


if __name__ == "__main__":
    # Retrieval exposures for a support or catalog assistant.
    add_exposure("exp-001", "run-101", "retrieval", "retriever-v1", "doc-11", 1, "2026-03-01T10:00:00")
    add_exposure("exp-002", "run-102", "retrieval", "retriever-v1", "doc-22", 1, "2026-03-01T10:05:00")
    add_exposure("exp-003", "run-103", "retrieval", "retriever-v2", "doc-31", 1, "2026-03-01T10:10:00")
    add_exposure("exp-004", "run-104", "retrieval", "retriever-v2", "doc-44", 2, "2026-03-01T10:15:00")

    add_click("exp-003", "2026-03-01T10:11:00")
    add_click("exp-004", "2026-03-01T10:16:00")

    # Recommendation exposures for an e-commerce assistant.
    add_exposure("exp-101", "run-301", "recommendation", "reco-v1", "sku-11", 1, "2026-03-01T12:00:00")
    add_exposure("exp-102", "run-302", "recommendation", "reco-v1", "sku-22", 1, "2026-03-01T12:05:00")
    add_exposure("exp-103", "run-303", "recommendation", "reco-v2", "sku-31", 1, "2026-03-01T12:10:00")

    add_click("exp-101", "2026-03-01T12:01:00")
    add_click("exp-102", "2026-03-01T12:06:00")
    add_click("exp-103", "2026-03-01T12:11:00")

    add_conversion("exp-103", "2026-03-03T11:00:00", 120.0)
    add_conversion("exp-102", "2026-03-20T09:00:00", 80.0)  # Outside 7-day window

    # Trading assistant decisions and outcomes.
    add_trade("trade-001", "run-201", "strategy-v1", "NVDA", "2026-03-01T09:30:00")
    add_trade("trade-002", "run-202", "strategy-v1", "AAPL", "2026-03-01T11:00:00")
    add_trade("trade-003", "run-203", "strategy-v2", "MSFT", "2026-03-01T13:00:00")

    add_trade_outcome("trade-001", "2026-03-01T15:30:00", pnl=-40.0, max_drawdown=60.0)
    add_trade_outcome("trade-002", "2026-03-01T16:00:00", pnl=20.0, max_drawdown=35.0)
    add_trade_outcome("trade-003", "2026-03-01T16:00:00", pnl=35.0, max_drawdown=10.0)

    print("CLICK SUMMARY")
    for row in summarize_clicks():
        print(row)

    print("\nCONVERSION SUMMARY")
    for row in summarize_conversions(window_days=7):
        print(row)

    print("\TRADING SUMMARY")
    for row in summarize_trades(risk_penalty=0.5):
        print(row)

    print("\nREVIEW CANDIDATES")
    for row in build_review_candidates():
        print(row)


