from __future__ import annotations
from typing_extensions import TypedDict
from langchain.chat_models import init_chat_model
from langgraph.graph import StateGraph, START, END
from .config import OPENAI_API_KEY

MEMORY_STORE: dict[str, list[str]] = {}

class State(TypedDict):
    assistant_id: str
    question: str
    memory_notes: list[str]
    validated_reflection: str
    answer: str

model = init_chat_model("openai:gpt-4.1-mini", temperature=0)

def load_memory(state: State) -> dict:
    return {
        "memory_notes": MEMORY_STORE.get(state["assistant_id"], [])
    }

def write_answer(state: State) -> dict:
    memory_block = "\n".join(f"- {n}" for n in state["memory_notes"]) or "NO_MEMORY"
    msg = model.invoke(f"""
You are a support assistant.

Persistent operating notes:
{memory_block}

Question:
{state["question"]}

Answer carefully and do not overstate policy conclusions.
""")
    return {"answer": msg.content}

def store_reflection(state: State) -> dict:
    note = state["validated_reflection"].strip()
    if note:
        MEMORY_STORE.setdefault(state["assistant_id"], []).append(note)
    return {}

builder = StateGraph(State)
builder.add_node("load_memory", load_memory)
builder.add_node("write_answer", write_answer)
builder.add_node("store_reflection", store_reflection)

builder.add_edge(START, "load_memory")
builder.add_edge("load_memory", "write_answer")
builder.add_edge("write_answer", "store_reflection")
builder.add_edge("store_reflection", END)

graph = builder.compile()

if __name__ == "__main__":
    first = graph.invoke({
        "assistant_id": "support-v1",
        "question": "Can I definitely get a refund for a special-case return?",
        "memory_notes": [],
        "validated_reflection": (
            "Do not claim refund eligibility unless the policy text states it explicitly."
        ),
        "answer": "",
    })

    second = graph.invoke({
        "assistant_id": "support-v1",
        "question": "Can I get a refund for a gift return?",
        "memory_notes": [],
        "validated_reflection": "",
        "answer": "",
    })

    print("ANSWER 1:\n")
    print(first["answer"])
    print("\nSTORED MEMORY:\n")
    print(MEMORY_STORE["support-v1"])
    print("\nANSWER 2:\n")
    print(second["answer"])
