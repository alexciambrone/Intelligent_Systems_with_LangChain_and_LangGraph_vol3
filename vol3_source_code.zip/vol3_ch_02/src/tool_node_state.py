from __future__ import annotations

import json
from dataclasses import dataclass

from langchain.messages import AIMessage, HumanMessage, ToolMessage
from langchain.tools import ToolRuntime, tool
from langgraph.graph import END, START, MessagesState, StateGraph
from langgraph.prebuilt import ToolNode
from langgraph.store.memory import InMemoryStore

from .config import OPENAI_API_KEY


# ---- 1) Graph state: short-term state for the current run -------------------
# MessagesState already gives us the standard "messages" list.
# We extend it with one custom field to show runtime.state reading both.
class State(MessagesState):
    ticket_id: str


# ---- 2) Invocation-scoped context: stable for a single run ------------------
@dataclass
class Context:
    user_id: str
    plan: str


# ---- 3) Tool that uses all four runtime surfaces ----------------------------
@tool
def inspect_runtime(note: str, runtime: ToolRuntime[Context, State]) -> str:
    """Inspect runtime.state, runtime.context, runtime.store, and runtime.stream_writer."""

    # A) runtime.state -> current graph state for this run
    messages = runtime.state["messages"]
    ticket_id = runtime.state["ticket_id"]

    last_user_message = next(
        (m.content for m in reversed(messages) if isinstance(m, HumanMessage)),
        None,
    )

    # B) runtime.context -> stable invocation-scoped data
    user_id = runtime.context.user_id
    plan = runtime.context.plan

    # C) runtime.stream_writer -> emit progress while the tool is still running
    if runtime.stream_writer:
        runtime.stream_writer(
            {
                "phase": "start",
                "message_count": len(messages),
                "ticket_id": ticket_id,
            }
        )

    # D) runtime.store -> longer-lived storage, separate from per-run state
    previous_note = None

    if runtime.store:
        namespace = ("users", user_id)

        item = runtime.store.get(namespace, "last_note")
        previous_note = item.value if item else None

        if runtime.stream_writer:
            runtime.stream_writer(
                {
                    "phase": "loaded-store",
                    "previous_note": previous_note,
                }
            )

        runtime.store.put(
            namespace,
            "last_note",
            {
                "ticket_id": ticket_id,
                "note": note,
            },
        )

    if runtime.stream_writer:
        runtime.stream_writer(
            {
                "phase": "done",
                "saved_note": note,
            }
        )

    # Return a JSON string so the result is easy to inspect in the ToolMessage
    return json.dumps(
        {
            "from_state": {
                "ticket_id": ticket_id,
                "message_count": len(messages),
                "last_user_message": last_user_message,
            },
            "from_context": {
                "user_id": user_id,
                "plan": plan,
            },
            "from_store": {
                "previous_note": previous_note,
                "new_note": note,
            },
        }
    )


# ---- 4) Build the graph -----------------------------------------------------
# The graph has one node: ToolNode.
# We seed the graph with an AIMessage that already contains a tool call.
store = InMemoryStore()

builder = StateGraph(State, context_schema=Context)
builder.add_node("tools", ToolNode([inspect_runtime]))
builder.add_edge(START, "tools")
builder.add_edge("tools", END)

graph = builder.compile(store=store)


# ---- 5) Helper to create an input state ------------------------------------
def make_input(ticket_id: str, note: str) -> State:
    return {
        "ticket_id": ticket_id,
        "messages": [
            HumanMessage(content="Please inspect the runtime."),
            AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "inspect_runtime",
                        "args": {"note": note},
                        "id": "call_1",
                        "type": "tool_call",
                    }
                ],
            ),
        ],
    }


# ---- 6) Run twice to show the difference between state and store ------------
# State is per run. Store survives across runs because the same store instance
# is reused.
def run_once(ticket_id: str, note: str) -> None:
    print(f"\n=== RUN ticket_id={ticket_id!r}, note={note!r} ===")
    final_state = None

    for mode, data in graph.stream(
        make_input(ticket_id=ticket_id, note=note),
        context=Context(user_id="user-123", plan="gold"),
        stream_mode=["custom", "values"],
        version="v2",
    ):
        if mode == "custom":
            print("CUSTOM:", data)
        elif mode == "values":
            final_state = data

    assert final_state is not None

    # The tool result is appended as a ToolMessage by ToolNode
    tool_msg = final_state["messages"][-1]
    assert isinstance(tool_msg, ToolMessage)

    print("TOOL RESULT:")
    print(json.dumps(json.loads(tool_msg.content), indent=2))


if __name__ == "__main__":
    run_once(ticket_id="T-100", note="first run")
    run_once(ticket_id="T-200", note="second run")