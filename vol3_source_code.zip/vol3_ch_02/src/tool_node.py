from langchain_core.messages import AIMessage, ToolMessage
from langchain_core.tools import BaseTool, tool

ORDERS = {
    "ORD-100": {
        "status": "delivered",
        "days_since_delivery": 12,
        "amount": 129.0,
    }
}

@tool
def lookup_order(order_id: str) -> str:
    """Return a short description of an order."""
    order = ORDERS.get(order_id)
    if not order:
        return f"Order {order_id} was not found."

    return (
        f"Order {order_id}: status={order['status']}, "
        f"days_since_delivery={order['days_since_delivery']}, "
        f"amount={order['amount']}"
    )

def invoke_tools_direct(state: dict, tools: list[BaseTool]) -> dict:
    messages = state.get("messages", [])
    if not messages:
        raise ValueError("State must contain at least one message.")

    last = messages[-1]
    if not isinstance(last, AIMessage):
        raise TypeError("The last message must be an AIMessage.")

    tool_calls = last.tool_calls or []
    tool_map = {tool.name: tool for tool in tools}

    tool_messages = []
    for call in tool_calls:
        name = call["name"]
        args = call.get("args", {})
        tool_call_id = call["id"]

        if name not in tool_map:
            raise ValueError(f"Unknown tool: {name}")

        result = tool_map[name].invoke(args)

        tool_messages.append(
            ToolMessage(
                content=str(result),
                name=name,
                tool_call_id=tool_call_id,
            )
        )

    return {"messages": tool_messages}

state = {
    "messages": [
        AIMessage(
            content="",
            tool_calls=[
                {
                    "name": "lookup_order",
                    "args": {"order_id": "ORD-100"},
                    "id": "call_lookup_1",
                    "type": "tool_call",
                }
            ],
        )
    ]
}

update = invoke_tools_direct(state, [lookup_order])

for message in update["messages"]:
    print(type(message).__name__)
    print("tool_call_id:", message.tool_call_id)
    print("content:", message.content)