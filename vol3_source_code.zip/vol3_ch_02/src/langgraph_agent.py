from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END

class InputState(TypedDict):
    question: str

class OutputState(TypedDict):
    answer: str

class OverallState(InputState, OutputState):
    pass

def answer_node(state: InputState) -> dict:
    question = state["question"]
    return {
        "answer": f"You asked: {question}. This response came from a LangGraph app exposed through MCP."
    }

builder = StateGraph(
    OverallState,
    input_schema=InputState,
    output_schema=OutputState,
)

builder.add_node("answer_node", answer_node)
builder.add_edge(START, "answer_node")
builder.add_edge("answer_node", END)

graph = builder.compile()