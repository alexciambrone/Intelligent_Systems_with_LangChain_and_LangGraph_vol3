from pydantic import BaseModel, Field
from typing import Literal
from langchain_openai import ChatOpenAI
from .config import OPENAI_API_KEY

class ScreenEquities(BaseModel):
    """Screen equities that match a simple strategy filter."""

    sector: str = Field(description="Sector to filter on")
    min_market_cap_usd_billion: int = Field(
        description="Minimum market cap in billions"
    )
    style: Literal["value", "growth", "quality"] = Field(
        description="Investment style"
    )


class SubmitOrder(BaseModel):
    """Submit a proposed equity order for later validation and execution."""

    symbol: str = Field(description="Ticker symbol")
    side: Literal["buy", "sell"] = Field(description="Order side")
    quantity: int = Field(description="Number of shares")
    order_type: Literal["market", "limit"] = Field(description="Order type")
    limit_price_usd: float | None = Field(
        description="Limit price in USD. Use null for market orders."
    )


llm = ChatOpenAI(model="gpt-4.1")

tools = [ScreenEquities, SubmitOrder]


def show(label: str, message) -> None:
    print(f"\n--- {label} ---")
    print("content:", repr(message.content))
    print("tool_calls:", message.tool_calls)


auto_llm = llm.bind_tools(
    tools,
    strict=True,
    tool_choice="auto",
    parallel_tool_calls=False,
)

show(
    "auto: tool call when useful",
    auto_llm.invoke(
        "Find quality technology stocks above 20 billion market cap."
    ),
)

show(
    "auto: direct answer when no tool is needed",
    auto_llm.invoke(
        "Explain market capitalization in one sentence."
    ),
)


no_tool_llm = llm.bind_tools(
    tools,
    strict=True,
    tool_choice="none",
)

show(
    "none: tools disabled for this call",
    no_tool_llm.invoke(
        "Find quality technology stocks above 20 billion market cap."
    ),
)


required_llm = llm.bind_tools(
    tools,
    strict=True,
    tool_choice="required",
    parallel_tool_calls=False,
)

show(
    "required: at least one tool call",
    required_llm.invoke(
        "Find quality technology stocks above 20 billion market cap."
    ),
)


forced_screen_llm = llm.bind_tools(
    tools,
    strict=True,
    tool_choice="ScreenEquities",
    parallel_tool_calls=False,
)

show(
    "forced: specific tool",
    forced_screen_llm.invoke(
        "Find quality technology stocks above 20 billion market cap."
    ),
)


