import asyncio
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from langchain.agents import create_agent
from langchain_mcp_adapters.client import MultiServerMCPClient
from .config import OPENAI_API_KEY


def extract_text_messages(result: dict) -> None:
    """Print final message contents in a readable way."""
    print("\n=== AGENT MESSAGES ===\n")
    for i, message in enumerate(result["messages"], start=1):
        message_type = getattr(message, "type", message.__class__.__name__)
        print(f"[{i}] {message_type}")

        content = getattr(message, "content", None)
        if isinstance(content, str):
            print(content)
        else:
            print(content)

        tool_calls = getattr(message, "tool_calls", None)
        if tool_calls:
            print("tool_calls =", tool_calls)

        print()


async def main() -> None:
    load_dotenv()

    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError(
            "OPENAI_API_KEY is not set. Put it in .env or export it in your shell."
        )

    base_dir = Path(__file__).resolve().parent
    orders_server = str((base_dir / "mcp_orders_server.py").resolve())

    client = MultiServerMCPClient(
        {
            "orders": {
                "transport": "stdio",
                "command": sys.executable,
                "args": [orders_server],
            },
            "shipping": {
                "transport": "http",
                "url": "http://127.0.0.1:8000/mcp",
                # Optional:
                # "headers": {"Authorization": "Bearer YOUR_TOKEN"},
            },
        }
    )

    tools = await client.get_tools()
    print(tools)

    agent = create_agent("openai:gpt-4.1", tools)

    result = await agent.ainvoke(
        {
            "messages": [
                {
                    "role": "user",
                    "content": (
                        "Customer ORD-100 says the parcel has not arrived. "
                        "Check the order and shipping status, then tell me "
                        "whether support should escalate."
                    ),
                }
            ]
        }
    )

    extract_text_messages(result)


if __name__ == "__main__":
    asyncio.run(main())