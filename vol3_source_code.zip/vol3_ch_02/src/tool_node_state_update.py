from typing import Annotated
from typing_extensions import TypedDict

from langchain.messages import AIMessage, HumanMessage, ToolMessage
from langchain.tools import tool, ToolRuntime
from langgraph.graph import StateGraph, START
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition
from langgraph.types import Command
from .config import OPENAI_API_KEY

CUSTOMERS = {
    "alex@example.com": {"tier": "gold", "refund_window_days": 30},
}

class SupportState(TypedDict):
    messages: Annotated[list, add_messages]
    customer_email: str
    customer_profile: dict | None

@tool
def load_customer_profile(runtime: ToolRuntime) -> Command:
    """Load the current customer's profile into graph state."""
    email = runtime.state["customer_email"]
    profile = CUSTOMERS.get(email, {"tier": "standard", "refund_window_days": 14})

    return Command(
        update={
            "customer_profile": profile,
            "messages": [
                ToolMessage(
                    content=(
                        f"Loaded customer profile: "
                        f"tier={profile['tier']}, "
                        f"refund_window_days={profile['refund_window_days']}"
                    ),
                    tool_call_id=runtime.tool_call_id,
                )
            ],
        }
    )

def assistant(state: SupportState):
    if state.get("customer_profile") is None:
        return {
            "messages": [
                AIMessage(
                    content="",
                    tool_calls=[
                        {
                            "name": "load_customer_profile",
                            "args": {},
                            "id": "call_profile_1",
                            "type": "tool_call",
                        }
                    ],
                )
            ]
        }

    profile = state["customer_profile"]
    return {
        "messages": [
            AIMessage(
                content=(
                    f"The customer profile is now in state. "
                    f"Tier={profile['tier']}; "
                    f"refund window={profile['refund_window_days']} days."
                )
            )
        ]
    }

builder = StateGraph(SupportState)
builder.add_node("assistant", assistant)
builder.add_node("tools", ToolNode([load_customer_profile]))

builder.add_edge(START, "assistant")
builder.add_conditional_edges("assistant", tools_condition)
builder.add_edge("tools", "assistant")

graph = builder.compile()

result = graph.invoke(
    {
        "messages": [HumanMessage(content="Can I still ask for a refund?")],
        "customer_email": "alex@example.com",
        "customer_profile": None,
    }
)

print("\nRUN TRACE\n")

for i, message in enumerate(result["messages"], start=1):
    label = type(message).__name__

    if label == "HumanMessage":
        print(f"[{i}] User")
        print(f"    {message.content}")

    elif label == "AIMessage":
        print(f"[{i}] Assistant")
        if getattr(message, "tool_calls", None):
            print("    Requested tool call(s):")
            for tc in message.tool_calls:
                print(
                    f"    - {tc['name']}(args={tc['args']}, id={tc['id']})"
                )
        if message.content:
            print(f"    {message.content}")

    elif label == "ToolMessage":
        print(f"[{i}] Tool result")
        print(f"    {message.content}")

    else:
        print(f"[{i}] {label}")
        print(f"    {message.content}")

    print()

print("FINAL STATE")
print(f"  customer_email   : {result['customer_email']}")
print(f"  customer_profile : {result['customer_profile']}")