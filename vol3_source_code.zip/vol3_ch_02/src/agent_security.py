from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

from langchain.agents import create_agent
from langchain.agents.middleware import HumanInTheLoopMiddleware
from langchain.tools import tool, ToolRuntime
from langgraph.checkpoint.memory import InMemorySaver
from .config import OPENAI_API_KEY

ORDERS: Dict[str, dict] = {
    "ORD-100": {"owner_id": "user-123", "status": "delivered", "amount": 129.0},
    "ORD-200": {"owner_id": "user-999", "status": "processing", "amount": 49.0},
}

AUTHORIZED_REFUND_ROLES = {"support_supervisor", "finance_ops"}


@dataclass
class SupportContext:
    user_id: str
    role: str


@tool
def lookup_order(order_id: str, runtime: ToolRuntime[SupportContext]) -> str:
    """Return the current user's order details."""
    order = ORDERS.get(order_id)
    if not order:
        return f"Order {order_id} was not found."

    # Permission check uses runtime context, not model-supplied arguments.
    if order["owner_id"] != runtime.context.user_id:
        return "Access denied: you can only inspect orders for the current user."

    return (
        f"order_id={order_id}, status={order['status']}, amount={order['amount']}"
    )


@tool
def submit_refund_request(
    order_id: str,
    reason: str,
    runtime: ToolRuntime[SupportContext],
) -> str:
    """Create a refund request for an eligible order."""
    order = ORDERS.get(order_id)
    if not order:
        return f"Order {order_id} was not found."

    if runtime.context.role not in AUTHORIZED_REFUND_ROLES:
        return "Refund submission denied: current role is not allowed to submit refunds."

    if order["owner_id"] != runtime.context.user_id:
        return "Refund submission denied: order does not belong to the current user."

    if order["status"] != "delivered":
        return "Refund submission denied: only delivered orders can enter refund review."

    # In a real system, call the refund service here.
    return f"Refund request created for {order_id} with reason='{reason}'."


agent = create_agent(
    model="gpt-4.1",
    tools=[lookup_order, submit_refund_request],
    context_schema=SupportContext,
    checkpointer=InMemorySaver(),
    middleware=[
        HumanInTheLoopMiddleware(
            interrupt_on={
                "lookup_order": False,
                "submit_refund_request": {
                    "allowed_decisions": ["approve", "edit", "reject"]
                },
            }
        )
    ],
    system_prompt=(
        "You are a customer support assistant. "
        "Use tools when needed, but do not invent permissions or policy outcomes."
    ),
)

result = agent.invoke(
    {
        "messages": [
            {
                "role": "user",
                "content": "Please refund order ORD-100 because the customer changed their mind.",
            }
        ]
    },
    context=SupportContext(user_id="user-123", role="support_supervisor"),
    config={"configurable": {"thread_id": "support-case-001"}},
)

print("\nMESSAGES:")
for m in result["messages"]:
    print(f"\n- {type(m).__name__}")
    if getattr(m, "content", None):
        print("  content:", m.content)
    if getattr(m, "tool_calls", None):
        print("  tool_calls:", m.tool_calls)
    if getattr(m, "name", None):
        print("  name:", m.name)

interrupts = result.get("__interrupt__", [])
if interrupts:
    print("\nINTERRUPT:")
    for intr in interrupts:
        print("  pending action:", intr.value["action_requests"][0]["name"])
        print("  args:", intr.value["action_requests"][0]["args"])
        print("  allowed decisions:", intr.value["review_configs"][0]["allowed_decisions"])