import asyncio
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from langchain.agents import create_agent
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.tools import load_mcp_tools


async def main() -> None:
    load_dotenv()

    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError("OPENAI_API_KEY is not set.")

    base_dir = Path(__file__).resolve().parent
    orders_server = str((base_dir / "mcp_orders_server.py").resolve())

    client = MultiServerMCPClient(
        {
            "orders": {
                "transport": "stdio",
                "command": sys.executable,
                "args": [orders_server],
            }
        }
    )

    async with client.session("orders") as session:
        tools = await load_mcp_tools(session)
        agent = create_agent("openai:gpt-4.1", tools)

        result = await agent.ainvoke(
            {
                "messages": [
                    {
                        "role": "user",
                        "content": (
                            "Continue the return flow we already started for "
                            "order ORD-100 and add the note: box slightly damaged."
                        ),
                    }
                ]
            }
        )

        for message in result["messages"]:
            print(message)


if __name__ == "__main__":
    asyncio.run(main())