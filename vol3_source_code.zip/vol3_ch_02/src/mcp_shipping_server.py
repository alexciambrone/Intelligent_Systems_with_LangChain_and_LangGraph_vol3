from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Shipping")

SHIPMENTS = {
    "SHP-9001": {
        "carrier": "DHL",
        "status": "in_transit",
        "last_event": "Departed local sorting facility",
        "eta": "2026-03-19",
        "delivery_attempted": False,
        "lost_risk": "low",
    },
    "SHP-9002": {
        "carrier": "UPS",
        "status": "exception",
        "last_event": "No movement for 5 days; parcel location unknown",
        "eta": None,
        "delivery_attempted": False,
        "lost_risk": "high",
    },
}


@mcp.tool()
def get_shipping_status(shipping_id: str) -> dict:
    """Return shipping status for a given shipment ID."""
    shipment = SHIPMENTS.get(shipping_id)
    if not shipment:
        return {
            "found": False,
            "shipping_id": shipping_id,
            "message": f"Shipment {shipping_id} was not found.",
        }

    return {
        "found": True,
        "shipping_id": shipping_id,
        **shipment,
    }


@mcp.tool()
def should_escalate_shipping_case(
    status: str,
    delivery_attempted: bool,
    lost_risk: str,
) -> dict:
    """Return a simple support escalation recommendation."""
    escalate = False
    reason = "No escalation needed."

    if status == "exception":
        escalate = True
        reason = "Shipment is in exception state."
    elif lost_risk == "high":
        escalate = True
        reason = "Shipment has high lost-risk."
    elif delivery_attempted and status != "delivered":
        escalate = True
        reason = "Delivery was attempted but shipment is not delivered."

    return {
        "escalate": escalate,
        "reason": reason,
    }


if __name__ == "__main__":
    mcp.run(transport="streamable-http")