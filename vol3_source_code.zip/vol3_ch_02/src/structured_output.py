from pydantic import BaseModel, Field
from langchain_openai import ChatOpenAI
from .config import OPENAI_API_KEY

class CatalogIntent(BaseModel):
    category: str = Field(description="Primary catalog category")
    max_price_eur: int = Field(description="Maximum acceptable price in euros")
    colors: list[str] = Field(description="Preferred colors")
    must_be_waterproof: bool = Field(description="Whether waterproofing is required")
    exclude_use_case: str = Field(description="Conditions the product should not target")

llm = ChatOpenAI(model="gpt-4.1")

intent_llm = llm.with_structured_output(
    CatalogIntent,
    method="json_schema",
)

intent = intent_llm.invoke(
    "Show me waterproof hiking jackets under 180 euros, dark colors only, "
    "and not for winter extremes."
)

print(intent.model_dump())