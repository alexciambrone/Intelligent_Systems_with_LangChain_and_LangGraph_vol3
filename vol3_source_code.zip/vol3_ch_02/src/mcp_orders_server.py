from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Orders")

ORDERS = {
    "ORD-100": {
        "customer": "Alice Carter",
        "status": "paid",
        "shipping_id": "SHP-9001",
        "items": [
            {"sku": "SKU-CHAIR-01", "name": "Office Chair", "qty": 1}
        ],
        "priority": "normal",
    },
    "ORD-200": {
        "customer": "Bob Smith",
        "status": "paid",
        "shipping_id": "SHP-9002",
        "items": [
            {"sku": "SKU-DESK-01", "name": "Standing Desk", "qty": 1}
        ],
        "priority": "high",
    },
}


@mcp.tool()
def get_order(order_id: str) -> dict:
    """Return order details for a given order ID."""
    order = ORDERS.get(order_id)
    if not order:
        return {
            "found": False,
            "order_id": order_id,
            "message": f"Order {order_id} was not found.",
        }

    return {
        "found": True,
        "order_id": order_id,
        **order,
    }


if __name__ == "__main__":
    # stdio transport for local subprocess communication
    mcp.run(transport="stdio")