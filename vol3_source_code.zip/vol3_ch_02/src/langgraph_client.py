import asyncio

from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client


SERVER_URL = "http://localhost:2024/mcp"


async def main() -> None:
    async with streamablehttp_client(url=SERVER_URL) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()

            tools_result = await session.list_tools()
            print("\n=== TOOLS ===")
            for tool in tools_result.tools:
                print(f"name={tool.name}")
                print(f"description={tool.description}")
                print(f"inputSchema={tool.inputSchema}")
                print()

            result = await session.call_tool(
                "faq_agent",
                {"question": "What are you?"}
            )

            print("\n=== TOOL RESULT ===")
            for item in result.content:
                print(item)


if __name__ == "__main__":
    asyncio.run(main())

