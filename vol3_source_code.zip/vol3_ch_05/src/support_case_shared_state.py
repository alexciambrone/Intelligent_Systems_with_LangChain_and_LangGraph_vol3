from __future__ import annotations

from pprint import pprint
from typing_extensions import TypedDict, NotRequired

from langchain.chat_models import init_chat_model
from langgraph.graph import StateGraph, START, END

from .config import OPENAI_API_KEY
from .support_team_shared import ask_billing_specialist, ask_returns_specialist


MODEL = init_chat_model("openai:gpt-4.1-mini", temperature=0)


class StructuredSupportState(TypedDict):
    question: str
    billing_answer: NotRequired[str]
    returns_answer: NotRequired[str]
    final_answer: NotRequired[str]


def billing_specialist(state: StructuredSupportState) -> dict:
    answer = ask_billing_specialist.invoke({"question": state["question"]})
    return {"billing_answer": answer}


def returns_specialist(state: StructuredSupportState) -> dict:
    answer = ask_returns_specialist.invoke({"question": state["question"]})
    return {"returns_answer": answer}


def compose_final(state: StructuredSupportState) -> dict:
    answer = MODEL.invoke(f"""
Write one customer-facing answer from the structured specialist outputs below.

Billing:
{state["billing_answer"]}

Returns:
{state["returns_answer"]}

Be clear, concise, and consistent with both specialists.
""")

    return {"final_answer": answer.content}


builder = StateGraph(StructuredSupportState)
builder.add_node("billing_specialist", billing_specialist)
builder.add_node("returns_specialist", returns_specialist)
builder.add_node("compose_final", compose_final)

builder.add_edge(START, "billing_specialist")
builder.add_edge("billing_specialist", "returns_specialist")
builder.add_edge("returns_specialist", "compose_final")
builder.add_edge("compose_final", END)

graph = builder.compile()


def print_state(title: str, state: dict) -> None:
    print(title)
    pprint(state, sort_dicts=False)
    print("-" * 80)


if __name__ == "__main__":
    question = (
        "I was charged twice for a gift order, and the replacement item also "
        "arrived damaged. Explain what happens with the billing issue and the return."
    )

    initial_state: StructuredSupportState = {"question": question}
    running_state: dict = dict(initial_state)

    print_state("Initial shared state:", running_state)

    for update in graph.stream(initial_state, stream_mode="updates"):
        for node_name, node_update in update.items():
            print(f"Node executed: {node_name}")
            print("Node update:")
            pprint(node_update, sort_dicts=False)
            print()

            running_state.update(node_update)
            print_state("Shared state after node:", running_state)

    print("Final customer-facing answer:\n")
    print(running_state["final_answer"])