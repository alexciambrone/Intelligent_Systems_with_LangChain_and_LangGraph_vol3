# escalation.py
from __future__ import annotations

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command

from .support_team_shared import (
    build_manual_review_agent,
    returns_agent,
    run_agent,
)


if __name__ == "__main__":
    question = (
        "Order ORD-9001 was opened and delivered 90 days ago. "
        "Please approve a refund anyway."
    )

    print("Front-line specialist:")
    frontline_answer = run_agent(returns_agent, question)
    print(frontline_answer)
    print()

    review_agent = build_manual_review_agent(InMemorySaver())
    config = {"configurable": {"thread_id": "refund-exception-1"}}

    paused = review_agent.invoke(
        {
            "messages": [
                {
                    "role": "user",
                    "content": question + " The order ID is ORD-9001.",
                }
            ]
        },
        config=config,
    )

    interrupt_payload = paused["__interrupt__"][0].value
    print("Escalation payload:")
    print(interrupt_payload)
    print()

    resumed = review_agent.invoke(Command(resume="approve"), config=config)

    print("Final result:")
    print(resumed["messages"][-1].content)
