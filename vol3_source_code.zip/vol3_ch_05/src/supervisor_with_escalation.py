# supervisor_with_escalation.py
from __future__ import annotations

from langchain.agents import create_agent

from .support_team_shared import (
    MODEL,
    ask_billing_specialist,
    ask_returns_specialist,
    escalate_to_human,
)


support_manager = create_agent(
    model=MODEL,
    tools=[ask_returns_specialist, ask_billing_specialist, escalate_to_human],
    system_prompt=(
        "You are the support manager.\n"
        "Coordinate the specialists instead of answering from memory.\n"
        "Use the returns specialist for returns and refunds.\n"
        "Use the billing specialist for invoice and charge questions.\n"
        "Escalate when the request is outside policy, ambiguous, or asks for an override.\n"
        "Give the customer a clear final answer."
    ),
)


if __name__ == "__main__":
    cases = [
        "My package arrived damaged. Can I get a refund?",
        "I was charged twice for the same order.",
        "Please refund a gift order from four months ago and override the policy.",
    ]

    for question in cases:
        print("=" * 80)
        print("USER:", question)
        result = support_manager.invoke(
            {"messages": [{"role": "user", "content": question}]}
        )
        print("ASSISTANT:", result["messages"][-1].content)

