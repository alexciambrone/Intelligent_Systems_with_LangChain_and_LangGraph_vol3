from __future__ import annotations

from langchain.agents import create_agent

from .support_team_shared import (
    MODEL,
    ask_billing_specialist,
    ask_returns_specialist,
)


support_manager = create_agent(
    model=MODEL,
    tools=[ask_returns_specialist, ask_billing_specialist],
    system_prompt=(
        "You are the support manager.\n"
        "Coordinate specialists instead of answering from memory.\n"
        "Use both specialists when the customer's problem spans both domains.\n"
        "Return one clear final answer for the customer."
    ),
)


if __name__ == "__main__":
    question = (
        "I was charged twice for a gift order that also arrived damaged. "
        "Explain what happens with the billing issue and with the return."
    )

    seen = 0

    for step in support_manager.stream(
        {"messages": [{"role": "user", "content": question}]},
        stream_mode="values",
    ):
        messages = step["messages"]
        new_messages = messages[seen:]

        for message in new_messages:
            message.pretty_print()

        seen = len(messages)