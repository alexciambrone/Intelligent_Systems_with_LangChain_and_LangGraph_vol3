from __future__ import annotations
from typing import Any, Dict, List, TypedDict
from langchain.chat_models import init_chat_model
from langgraph.graph import StateGraph, START
from config import OPENAI_API_KEY

MODEL = init_chat_model("openai:gpt-4.1-mini", temperature=0)


class A2AState(TypedDict):
    messages: List[Dict[str, Any]]


SYSTEM_PROMPT = """You are the returns specialist for an online store.
Answer only the returns side of the request.

Returns policy:
- Unopened items can be returned within 30 days of delivery.
- Damaged items can be refunded or replaced, even if the box was opened.
- Gift returns are eligible for store credit unless the item arrived damaged.
- Requests outside these rules require manual review.

Keep the answer short, concrete, and customer-facing.
"""


def latest_user_text(messages: List[Dict[str, Any]]) -> str:
    for message in reversed(messages):
        if message.get("role") == "user":
            return str(message.get("content", ""))
    return ""


def answer(state: A2AState) -> Dict[str, Any]:
    user_text = latest_user_text(state["messages"])

    reply = MODEL.invoke(
        [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_text},
        ]
    )

    return {
        "messages": state["messages"] + [
            {"role": "assistant", "content": reply.content}
        ]
    }


builder = StateGraph(A2AState)
builder.add_node("answer", answer)
builder.add_edge(START, "answer")
graph = builder.compile()
