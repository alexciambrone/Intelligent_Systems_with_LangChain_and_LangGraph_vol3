from __future__ import annotations

from operator import add
from typing import Annotated, Literal

from typing_extensions import NotRequired
from pydantic import BaseModel, Field

from langchain.chat_models import init_chat_model
from langchain.messages import AIMessage
from langgraph.graph import MessagesState, START, END, StateGraph
from langgraph.types import Command

from .config import OPENAI_API_KEY
from .support_team_shared import ask_billing_specialist, ask_returns_specialist


MODEL = init_chat_model("openai:gpt-4.1-mini", temperature=0)


class HandoffDecision(BaseModel):
    active_agent: Literal["billing", "returns"] = Field(
        description="Which specialist should take over this case."
    )
    standalone_question: str = Field(
        description="Rewrite the customer request as a clean standalone question."
    )


class SupportState(MessagesState):
    active_agent: NotRequired[str]
    standalone_question: NotRequired[str]
    trace: Annotated[list[str], add]


router = MODEL.with_structured_output(HandoffDecision)


def triage(state: SupportState) -> Command[Literal["billing_agent", "returns_agent"]]:
    latest_user_message = state["messages"][-1].content

    decision = router.invoke(
        f"""
Route this support request to exactly one specialist.

Use "billing" for charges, invoices, payments, and duplicate-charge disputes.
Use "returns" for refunds, damaged items, replacements, gift returns, and return windows.

Customer request:
{latest_user_message}
"""
    )

    target = "billing_agent" if decision.active_agent == "billing" else "returns_agent"

    return Command(
        update={
            "active_agent": decision.active_agent,
            "standalone_question": decision.standalone_question,
            "trace": [
                f"triage: handoff to {decision.active_agent}",
                f"triage: standalone_question={decision.standalone_question!r}",
            ],
        },
        goto=target,
    )


def billing_agent_node(state: SupportState) -> dict:
    answer = ask_billing_specialist.invoke(
        {"question": state["standalone_question"]}
    )
    return {
        "messages": [AIMessage(content=answer)],
        "active_agent": "billing",
        "trace": ["billing_agent: answered billing question"],
    }


def returns_agent_node(state: SupportState) -> dict:
    answer = ask_returns_specialist.invoke(
        {"question": state["standalone_question"]}
    )
    return {
        "messages": [AIMessage(content=answer)],
        "active_agent": "returns",
        "trace": ["returns_agent: answered returns question"],
    }


builder = StateGraph(SupportState)
builder.add_node("triage", triage)
builder.add_node("billing_agent", billing_agent_node)
builder.add_node("returns_agent", returns_agent_node)

builder.add_edge(START, "triage")
builder.add_edge("billing_agent", END)
builder.add_edge("returns_agent", END)

graph = builder.compile()


if __name__ == "__main__":
    inputs = {
        "messages": [
            {
                "role": "user",
                "content": "I was charged twice for the same order. What happens next?",
            }
        ],
        "trace": [],
    }

    print("QUESTION:")
    print(inputs["messages"][0]["content"])
    print()

    last_trace_len = 0
    last_message_len = 1  # initial user message already known

    for step in graph.stream(inputs, stream_mode="values"):
        trace = step.get("trace", [])
        new_trace = trace[last_trace_len:]
        for line in new_trace:
            print(line)
        last_trace_len = len(trace)

        messages = step["messages"]
        new_messages = messages[last_message_len:]
        for msg in new_messages:
            print()
            print("SPECIALIST OUTPUT:")
            print(msg.content)
        last_message_len = len(messages)

    result = graph.invoke(inputs)

    print()
    print("FINAL ANSWER:")
    print(result["messages"][-1].content)