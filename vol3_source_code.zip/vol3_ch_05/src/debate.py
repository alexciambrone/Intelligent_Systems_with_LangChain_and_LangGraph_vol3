# debate.py
from __future__ import annotations

from .support_team_shared import (
    MODEL,
    DebateVerdict,
    customer_advocate,
    policy_guard,
    run_agent,
)


judge = MODEL.with_structured_output(DebateVerdict)


if __name__ == "__main__":
    question = (
        "A customer received a damaged gift order. "
        "Should support offer a refund or store credit?"
    )

    advocate_opening = run_agent(customer_advocate, question)
    guard_opening = run_agent(policy_guard, question)

    advocate_rebuttal = run_agent(
        customer_advocate,
        f"""
Question:
{question}

Other side's position:
{guard_opening}

Reply with the strongest short objection to that position.
""",
    )

    guard_rebuttal = run_agent(
        policy_guard,
        f"""
Question:
{question}

Other side's position:
{advocate_opening}

Reply with the strongest short objection to that position.
""",
    )

    verdict = judge.invoke(
        f"""
You are the debate judge.

Question:
{question}

Customer advocate opening:
{advocate_opening}

Policy guard opening:
{guard_opening}

Customer advocate rebuttal:
{advocate_rebuttal}

Policy guard rebuttal:
{guard_rebuttal}

Return the final decision.
"""
    )

    print("Customer advocate:")
    print(advocate_opening)
    print()
    print("Policy guard:")
    print(guard_opening)
    print()
    print("Customer advocate rebuttal:")
    print(advocate_rebuttal)
    print()
    print("Policy guard rebuttal:")
    print(guard_rebuttal)
    print()
    print("Final decision:", verdict.decision)
    print("Rationale:", verdict.rationale)
