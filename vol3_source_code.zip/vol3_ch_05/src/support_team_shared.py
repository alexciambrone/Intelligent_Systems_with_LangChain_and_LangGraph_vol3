# support_team_shared.py
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field
from langchain.agents import create_agent
from langchain.chat_models import init_chat_model
from langchain.tools import tool
from langgraph.types import interrupt
from .config import OPENAI_API_KEY

MODEL = init_chat_model("openai:gpt-4.1-mini", temperature=0)

RETURNS_POLICY = """
Returns policy:
- Unopened items can be returned within 30 days of delivery.
- Damaged items can be refunded or replaced, even if the box was opened.
- Gift returns are eligible for store credit unless the item arrived damaged.
- Requests outside these rules must be escalated for manual review.
"""

BILLING_POLICY = """
Billing policy:
- Invoices are available in the customer account.
- Duplicate charges must be investigated before any refund is issued.
- Charge disputes and manual billing overrides must be escalated.
"""


class SpecialistRoute(BaseModel):
    specialist: Literal["returns", "billing"] = Field(
        description="The specialist that should answer the request."
    )
    rewritten_question: str = Field(
        description="A short standalone question written for the chosen specialist."
    )


class DebateVerdict(BaseModel):
    decision: Literal["refund", "store_credit", "escalate"] = Field(
        description="Final decision after hearing both sides."
    )
    rationale: str = Field(
        description="Short justification for the final decision."
    )


def run_agent(agent, user_text: str, *, config: dict | None = None) -> str:
    result = agent.invoke(
        {"messages": [{"role": "user", "content": user_text}]},
        config=config,
    )
    last = result["messages"][-1]
    return getattr(last, "text", last.content)


returns_agent = create_agent(
    model=MODEL,
    tools=[],
    system_prompt=(
        "You are the returns specialist.\n"
        "Answer only questions about refunds, replacements, damaged items, "
        "gift returns, and return windows.\n"
        "Use only the policy below.\n\n"
        f"{RETURNS_POLICY}\n\n"
        "If the request falls outside policy, say clearly that escalation is required."
    ),
)

billing_agent = create_agent(
    model=MODEL,
    tools=[],
    system_prompt=(
        "You are the billing specialist.\n"
        "Answer only questions about invoices, charges, payments, and billing disputes.\n"
        "Use only the policy below.\n\n"
        f"{BILLING_POLICY}\n\n"
        "If the request cannot be resolved safely from policy, say clearly that escalation is required."
    ),
)

customer_advocate = create_agent(
    model=MODEL,
    tools=[],
    system_prompt=(
        "You are the customer advocate in a support debate.\n"
        "Use the returns policy below, but look for the most customer-friendly interpretation "
        "that is still defensible.\n\n"
        f"{RETURNS_POLICY}\n\n"
        "Be concise and concrete."
    ),
)

policy_guard = create_agent(
    model=MODEL,
    tools=[],
    system_prompt=(
        "You are the policy guard in a support debate.\n"
        "Use the returns policy below and prefer the narrowest safe interpretation.\n\n"
        f"{RETURNS_POLICY}\n\n"
        "Be concise and concrete."
    ),
)


@tool("ask_returns_specialist")
def ask_returns_specialist(question: str) -> str:
    """Use for refunds, replacements, damaged items, gift returns, and return windows."""
    return run_agent(returns_agent, question)


@tool("ask_billing_specialist")
def ask_billing_specialist(question: str) -> str:
    """Use for invoices, duplicate charges, payments, and billing disputes."""
    return run_agent(billing_agent, question)


@tool("escalate_to_human")
def escalate_to_human(reason: str) -> str:
    """Use when the case is ambiguous, outside policy, high-risk, or needs human judgment."""
    return f"Escalated to human support queue. Reason: {reason}"


@tool
def request_manual_refund_approval(order_id: str, reason: str) -> str:
    """Request human approval for a refund outside normal policy."""
    decision = interrupt(
        {
            "kind": "manual_refund_review",
            "order_id": order_id,
            "reason": reason,
            "allowed_responses": ["approve", "reject"],
        }
    )

    if decision == "approve":
        return f"Manual refund approved for {order_id}."
    return f"Manual refund rejected for {order_id}."


def build_manual_review_agent(checkpointer):
    return create_agent(
        model=MODEL,
        tools=[request_manual_refund_approval],
        system_prompt=(
            "You are the escalation agent.\n"
            "Use request_manual_refund_approval only when the customer is asking "
            "for an exception outside normal return policy."
        ),
        checkpointer=checkpointer,
    )
