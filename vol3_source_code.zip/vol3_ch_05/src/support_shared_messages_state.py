from __future__ import annotations

from typing_extensions import NotRequired
from langchain.chat_models import init_chat_model
from langchain.messages import AIMessage, SystemMessage, HumanMessage
from langgraph.graph import MessagesState, START, END, StateGraph

from .config import OPENAI_API_KEY
from .support_team_shared import ask_billing_specialist, ask_returns_specialist


MODEL = init_chat_model("openai:gpt-4.1-mini", temperature=0)


class SupportCollaborationState(MessagesState):
    question: str
    billing_result: NotRequired[str]
    returns_result: NotRequired[str]
    resolution: NotRequired[str]


def billing_specialist(state: SupportCollaborationState) -> dict:
    result = ask_billing_specialist.invoke({"question": state["question"]})
    return {
        "billing_result": result,
        "messages": [AIMessage(content=f"Billing specialist: {result}")],
    }


def returns_specialist(state: SupportCollaborationState) -> dict:
    result = ask_returns_specialist.invoke({"question": state["question"]})
    return {
        "returns_result": result,
        "messages": [AIMessage(content=f"Returns specialist: {result}")],
    }


def synthesize(state: SupportCollaborationState) -> dict:
    messages = [
        SystemMessage(
            content=(
                "You are the support coordinator.\n"
                "Use the specialist messages in the conversation to write one clear "
                "customer-facing answer. Do not invent policy beyond what the "
                "specialists already stated."
            )
        ),
        *state["messages"],
    ]

    final_answer = MODEL.invoke(messages)

    return {
        "resolution": final_answer.content,
        "messages": [final_answer],
    }


builder = StateGraph(SupportCollaborationState)
builder.add_node("billing_specialist", billing_specialist)
builder.add_node("returns_specialist", returns_specialist)
builder.add_node("synthesize", synthesize)

builder.add_edge(START, "billing_specialist")
builder.add_edge("billing_specialist", "returns_specialist")
builder.add_edge("returns_specialist", "synthesize")
builder.add_edge("synthesize", END)

graph = builder.compile()


def print_message_list(messages) -> None:
    print("Shared message state:")
    for i, message in enumerate(messages, start=1):
        msg_type = message.__class__.__name__
        content = getattr(message, "content", "")
        print(f"{i}. {msg_type}: {content}")
    print()


if __name__ == "__main__":
    question = (
        "I was charged twice for a gift order, and the replacement item also arrived "
        "damaged. Explain what happens with the billing issue and with the return."
    )

    initial_state = {
        "question": question,
        "messages": [HumanMessage(content=question)],
    }

    print("=== STATE UPDATES AS THE GRAPH RUNS ===\n")

    for chunk in graph.stream(initial_state, stream_mode="values"):
        print_message_list(chunk["messages"])

        if "billing_result" in chunk:
            print(f"billing_result: {chunk['billing_result']}")
        if "returns_result" in chunk:
            print(f"returns_result: {chunk['returns_result']}")
        if "resolution" in chunk:
            print(f"resolution: {chunk['resolution']}")

        print("-" * 80)

    print("\n=== FINAL STATE ===\n")
    result = graph.invoke(initial_state)

    print_message_list(result["messages"])
    print("Final resolution:")
    print(result["resolution"])