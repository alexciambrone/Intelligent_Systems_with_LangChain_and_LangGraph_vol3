from __future__ import annotations

import asyncio
import json
import os
import uuid
from pathlib import Path
from typing import Any, Dict, Tuple

import aiohttp
from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langchain.messages import HumanMessage, SystemMessage

dotenv_path = Path(__file__).resolve().parents[3] / ".env"
print(f"Loading .env from: {dotenv_path}")
print(f".env exists: {dotenv_path.exists()}")

load_dotenv(dotenv_path)

print(f"OPENAI_API_KEY present: {bool(os.getenv('OPENAI_API_KEY'))}")

BILLING_BASE_URL = "http://127.0.0.1:2024"
RETURNS_BASE_URL = "http://127.0.0.1:2025"

BILLING_GRAPH_ID = "billing_agent"
RETURNS_GRAPH_ID = "returns_agent"

SYNTHESIZER = init_chat_model("openai:gpt-4.1-mini", temperature=0)


async def resolve_assistant_id(
    session: aiohttp.ClientSession,
    base_url: str,
    graph_id: str,
) -> str:
    async with session.post(
        f"{base_url}/assistants/search",
        json={"graph_id": graph_id, "limit": 1},
    ) as response:
        response.raise_for_status()
        data = await response.json()

    if not data:
        raise RuntimeError(f"No assistant found for graph_id={graph_id!r} at {base_url}")

    return data[0]["assistant_id"]


async def fetch_agent_card(
    session: aiohttp.ClientSession,
    base_url: str,
    assistant_id: str,
) -> Dict[str, Any]:
    async with session.get(
        f"{base_url}/.well-known/agent-card.json",
        params={"assistant_id": assistant_id},
    ) as response:
        response.raise_for_status()
        return await response.json()


def print_json(title: str, data: Dict[str, Any]) -> None:
    print(title)
    print(json.dumps(data, indent=2, ensure_ascii=False))
    print()


def try_extract_text_from_parts(parts: list[dict]) -> str | None:
    for part in parts or []:
        if part.get("kind") == "text" and part.get("text"):
            return str(part["text"])
        if part.get("type") == "text" and part.get("text"):
            return str(part["text"])
        if part.get("text"):
            return str(part["text"])
    return None


def extract_text(result: Dict[str, Any]) -> str:
    result_obj = result.get("result", {}) or {}

    for artifact in result_obj.get("artifacts", []) or []:
        text = try_extract_text_from_parts(artifact.get("parts", []) or [])
        if text:
            return text

    status = result_obj.get("status", {}) or {}
    message = status.get("message", {}) or {}
    text = try_extract_text_from_parts(message.get("parts", []) or [])
    if text:
        return text

    message = result_obj.get("message", {}) or {}
    text = try_extract_text_from_parts(message.get("parts", []) or [])
    if text:
        return text

    messages = result_obj.get("messages", []) or []
    for msg in messages:
        text = try_extract_text_from_parts(msg.get("parts", []) or [])
        if text:
            return text

    return "(no text found)"


async def send_a2a_message(
    session: aiohttp.ClientSession,
    base_url: str,
    assistant_id: str,
    text: str,
    *,
    context_id: str | None = None,
    task_id: str | None = None,
) -> Tuple[str, str | None, str | None, Dict[str, Any]]:
    message = {
        "role": "user",
        "parts": [{"kind": "text", "text": text}],
        "messageId": str(uuid.uuid4()),
    }

    if context_id:
        message["contextId"] = context_id
    if task_id:
        message["taskId"] = task_id

    payload = {
        "jsonrpc": "2.0",
        "id": str(uuid.uuid4()),
        "method": "message/send",
        "params": {"message": message},
    }

    print_json("=== OUTBOUND A2A PAYLOAD ===", payload)

    async with session.post(
        f"{base_url}/a2a/{assistant_id}",
        json=payload,
        headers={"Accept": "application/json"},
    ) as response:
        response.raise_for_status()
        result = await response.json()

    print_json("=== RAW A2A RESPONSE ===", result)

    returned_context_id = result.get("result", {}).get("contextId") or context_id
    returned_task_id = result.get("result", {}).get("id") or task_id

    extracted = extract_text(result)
    print(f"=== EXTRACTED TEXT ===\n{extracted}\n")

    return extracted, returned_context_id, returned_task_id, result


async def main() -> None:
    customer_question = (
        "I was charged twice for a gift order, and the replacement item also arrived "
        "damaged. Explain what happens with the billing issue and with the return."
    )

    async with aiohttp.ClientSession() as session:
        billing_assistant_id = await resolve_assistant_id(
            session, BILLING_BASE_URL, BILLING_GRAPH_ID
        )
        returns_assistant_id = await resolve_assistant_id(
            session, RETURNS_BASE_URL, RETURNS_GRAPH_ID
        )

        billing_card = await fetch_agent_card(session, BILLING_BASE_URL, billing_assistant_id)
        returns_card = await fetch_agent_card(session, RETURNS_BASE_URL, returns_assistant_id)

        print("=== DISCOVERED AGENTS ===")
        print(f"Billing agent: {billing_card.get('name')} -> {billing_card.get('url')}")
        print(f"Returns agent: {returns_card.get('name')} -> {returns_card.get('url')}")
        print()

        print("=== MESSAGE SENT TO BILLING AGENT ===")
        print(customer_question)
        print()

        billing_reply, context_id, task_id, billing_raw = await send_a2a_message(
            session,
            BILLING_BASE_URL,
            billing_assistant_id,
            customer_question,
        )
        print("=== BILLING AGENT REPLY ===")
        print(billing_reply)
        print(f"contextId={context_id}")
        print(f"taskId={task_id}")
        print()

        returns_prompt = (
            f"Original customer question:\n{customer_question}\n\n"
            f"Billing specialist finding:\n{billing_reply}\n\n"
            "Now answer only the return and replacement side."
        )

        print("=== MESSAGE SENT TO RETURNS AGENT ===")
        print(returns_prompt)
        print()

        returns_reply, context_id, task_id, returns_raw = await send_a2a_message(
            session,
            RETURNS_BASE_URL,
            returns_assistant_id,
            returns_prompt,
            context_id=context_id,
            task_id=task_id,
        )
        print("=== RETURNS AGENT REPLY ===")
        print(returns_reply)
        print(f"contextId={context_id}")
        print(f"taskId={task_id}")
        print()

    final_answer = SYNTHESIZER.invoke(
        [
            SystemMessage(
                content=(
                    "You are the support coordinator. Combine the two specialist findings "
                    "into one short customer-facing answer. Do not invent policy beyond "
                    "what the specialists already stated."
                )
            ),
            HumanMessage(
                content=(
                    f"Customer question:\n{customer_question}\n\n"
                    f"Billing specialist:\n{billing_reply}\n\n"
                    f"Returns specialist:\n{returns_reply}"
                )
            ),
        ]
    )

    print("=== FINAL CUSTOMER ANSWER ===")
    print(final_answer.content)


if __name__ == "__main__":
    asyncio.run(main())