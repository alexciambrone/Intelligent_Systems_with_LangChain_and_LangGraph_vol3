from __future__ import annotations

from operator import add
from typing import Annotated, Literal
from typing_extensions import NotRequired, TypedDict

from langchain.chat_models import init_chat_model
from langchain.messages import HumanMessage, SystemMessage
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import START, END, StateGraph
from langgraph.managed import RemainingSteps
from langgraph.types import Command, interrupt

from .config import OPENAI_API_KEY
from .support_team_shared import ask_billing_specialist, ask_returns_specialist


MODEL = init_chat_model("openai:gpt-4.1-mini", temperature=0)


class SupportState(TypedDict):
    question: str
    needs_billing: bool
    needs_returns: bool
    needs_review: NotRequired[bool]
    billing_answer: NotRequired[str]
    returns_answer: NotRequired[str]
    draft_answer: NotRequired[str]
    final_answer: NotRequired[str]
    review_outcome: NotRequired[Literal["approve", "reject"]]
    trace: Annotated[list[str], add]
    remaining_steps: RemainingSteps


def triage(state: SupportState) -> dict:
    text = state["question"].lower()

    needs_billing = any(
        word in text for word in ["charged", "charge", "invoice", "payment", "billing"]
    )
    needs_returns = any(
        word in text for word in ["return", "refund", "damaged", "replacement"]
    )

    return {
        "needs_billing": needs_billing,
        "needs_returns": needs_returns,
        "trace": [
            f"triage: needs_billing={needs_billing}",
            f"triage: needs_returns={needs_returns}",
        ],
    }


def route_from_triage(state: SupportState):
    destinations: list[str] = []

    if state["needs_billing"]:
        destinations.append("billing_specialist")
    if state["needs_returns"]:
        destinations.append("returns_specialist")

    if not destinations:
        destinations.append("compose")

    return destinations


def billing_specialist(state: SupportState) -> dict:
    answer = ask_billing_specialist.invoke({"question": state["question"]})
    return {
        "billing_answer": answer,
        "trace": ["billing_specialist: completed"],
    }


def returns_specialist(state: SupportState) -> dict:
    answer = ask_returns_specialist.invoke({"question": state["question"]})
    return {
        "returns_answer": answer,
        "trace": ["returns_specialist: completed"],
    }


def compose(state: SupportState) -> dict:
    specialist_notes: list[str] = []

    if "billing_answer" in state:
        specialist_notes.append(f"Billing specialist:\n{state['billing_answer']}")
    if "returns_answer" in state:
        specialist_notes.append(f"Returns specialist:\n{state['returns_answer']}")

    messages = [
        SystemMessage(
            content=(
                "You are the support coordinator.\n"
                "Write one clear customer-facing answer from the specialist notes.\n"
                "Do not invent policy beyond what the specialists already stated.\n"
                "If the notes imply escalation or manual review, say that clearly."
            )
        ),
        HumanMessage(
            content=(
                f"Customer question:\n{state['question']}\n\n"
                f"Specialist notes:\n\n" + "\n\n".join(specialist_notes)
            )
        ),
    ]

    draft = MODEL.invoke(messages).content

    combined_notes = " ".join(
        [
            state.get("billing_answer", ""),
            state.get("returns_answer", ""),
        ]
    ).lower()

    low_budget = state["remaining_steps"] <= 2
    needs_review = (
        not low_budget
        and any(
            phrase in combined_notes
            for phrase in ["escalate", "manual review", "further review"]
        )
    )

    update = {
        "draft_answer": draft,
        "needs_review": needs_review,
        "trace": [
            f"compose: low_budget={low_budget}",
            f"compose: needs_review={needs_review}",
        ],
    }

    if low_budget:
        update["final_answer"] = (
            draft
            + "\n\n"
            + "This is a best-effort answer because the workflow is close to its "
            + "execution limit."
        )
    elif not needs_review:
        update["final_answer"] = draft

    return update


def route_after_compose(state: SupportState):
    if state.get("needs_review", False):
        return "manual_review"
    return END


def manual_review(state: SupportState) -> dict:
    decision = interrupt(
        {
            "type": "manual_review",
            "question": state["question"],
            "draft_answer": state["draft_answer"],
            "allowed_decisions": ["approve", "reject"],
        }
    )
    return {
        "review_outcome": decision,
        "trace": [f"manual_review: decision={decision}"],
    }


def finalize_review(state: SupportState) -> dict:
    if state["review_outcome"] == "approve":
        final_answer = state["draft_answer"]
    else:
        final_answer = (
            "This case needs human follow-up before we can confirm the next step. "
            "The automated workflow stopped at the review boundary."
        )

    return {
        "final_answer": final_answer,
        "trace": ["finalize_review: completed"],
    }


builder = StateGraph(SupportState)

builder.add_node("triage", triage)
builder.add_node("billing_specialist", billing_specialist)
builder.add_node("returns_specialist", returns_specialist)
builder.add_node("compose", compose)
builder.add_node("manual_review", manual_review)
builder.add_node("finalize_review", finalize_review)

builder.add_edge(START, "triage")
builder.add_conditional_edges("triage", route_from_triage)
builder.add_edge("billing_specialist", "compose")
builder.add_edge("returns_specialist", "compose")
builder.add_conditional_edges("compose", route_after_compose)
builder.add_edge("manual_review", "finalize_review")
builder.add_edge("finalize_review", END)

graph = builder.compile(checkpointer=InMemorySaver())


def print_divider(title: str) -> None:
    print("\n" + "=" * 80)
    print(title)
    print("=" * 80)


def print_text_block(title: str, value: str | None) -> None:
    if value:
        print(f"{title}:\n")
        print(value)
        print()


def print_state_snapshot(values: dict) -> None:
    print("ROUTING DECISIONS:")
    print(f"- needs_billing={values.get('needs_billing')}")
    print(f"- needs_returns={values.get('needs_returns')}")
    print(f"- needs_review={values.get('needs_review')}")
    print()

    print_text_block("BILLING SPECIALIST OUTPUT", values.get("billing_answer"))
    print_text_block("RETURNS SPECIALIST OUTPUT", values.get("returns_answer"))
    print_text_block("COMPOSED DRAFT", values.get("draft_answer"))

    if values.get("needs_review", False) and "review_outcome" not in values:
        print("COMPOSE ROUTING:")
        print("- Routed to manual_review")
        print()
    elif not values.get("needs_review", False) and "final_answer" in values:
        print("COMPOSE ROUTING:")
        print("- Ended directly without manual review")
        print()


def print_resume_delta(before: dict, after: dict) -> None:
    print("STATE CHANGES AFTER RESUME:\n")

    if "review_outcome" in after and after.get("review_outcome") != before.get(
        "review_outcome"
    ):
        print("REVIEW OUTCOME:")
        print(f"- {after['review_outcome']}")
        print()

    if after.get("final_answer") != before.get("final_answer"):
        print_text_block("FINAL ANSWER PRODUCED", after.get("final_answer"))


def print_trace(values: dict) -> None:
    print("TRACE:")
    for item in values.get("trace", []):
        print(f"- {item}")
    print()


def run_demo_case(
    *,
    title: str,
    question: str,
    review_decision: Literal["approve", "reject"] | None = None,
    recursion_limit: int = 10,
) -> None:
    thread_id = title.lower().replace(" ", "-").replace("/", "-")

    config = {
        "configurable": {"thread_id": thread_id},
        "recursion_limit": recursion_limit,
    }

    print_divider(title)
    print("QUESTION:\n")
    print(question)
    print()

    first_result = graph.invoke(
        {
            "question": question,
            "trace": [],
        },
        config=config,
    )

    first_snapshot = graph.get_state(config)
    first_values = dict(first_snapshot.values)

    interrupted = "__interrupt__" in first_result

    if interrupted:
        print("STATE AT REVIEW BOUNDARY:\n")
        print_state_snapshot(first_values)

        interrupt_payload = first_result["__interrupt__"][0].value
        print("INTERRUPT PAYLOAD:\n")
        print(interrupt_payload)
        print()

        if review_decision is None:
            print("No review decision supplied. Stopping at the review boundary.")
            return

        print(f"RESUMING WITH DECISION: {review_decision}\n")
        graph.invoke(Command(resume=review_decision), config=config)

        final_snapshot = graph.get_state(config)
        final_values = dict(final_snapshot.values)

        print_resume_delta(first_values, final_values)
        print_trace(final_values)

        print("FINAL ANSWER:\n")
        print(final_values["final_answer"])
        print()
        return

    print("FINAL STATE:\n")
    print_state_snapshot(first_values)
    print_trace(first_values)

    print("FINAL ANSWER:\n")
    print(first_values["final_answer"])
    print()


if __name__ == "__main__":
    run_demo_case(
        title="CASE 1 - BILLING ONLY / NO REVIEW",
        question="Where can I find my invoice for order ORD-100?",
    )

    run_demo_case(
        title="CASE 2 - MIXED CASE / REVIEW APPROVED",
        question=(
            "I was charged twice for a gift order, and the replacement item "
            "also arrived damaged. What happens next?"
        ),
        review_decision="approve",
    )

    run_demo_case(
        title="CASE 3 - MIXED CASE / REVIEW REJECTED",
        question=(
            "I was charged twice for a gift order, and the replacement item "
            "also arrived damaged. What happens next?"
        ),
        review_decision="reject",
    )

    # Optional extra demo to make the low-budget branch easier to observe:
    #
    # run_demo_case(
    #     title="CASE 4 - LOW BUDGET PATH",
    #     question=(
    #         "I was charged twice for a gift order, and the replacement item "
    #         "also arrived damaged. What happens next?"
    #     ),
    #     recursion_limit=4,
    # )