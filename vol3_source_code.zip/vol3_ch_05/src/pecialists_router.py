# specialists_router.py
from __future__ import annotations

from .support_team_shared import (
    MODEL,
    SpecialistRoute,
    billing_agent,
    returns_agent,
    run_agent,
)


router = MODEL.with_structured_output(SpecialistRoute)


def choose_specialist(question: str) -> SpecialistRoute:
    return router.invoke(
        f"""
Choose exactly one specialist for the support request.

returns:
- refunds
- replacements
- damaged items
- gift returns
- return windows

billing:
- invoices
- duplicate charges
- payments
- billing disputes

Rewrite the request into a short standalone question for that specialist.

User request:
{question}
"""
    )


if __name__ == "__main__":
    question = "I need a copy of my invoice and I want to know where to find it."

    decision = choose_specialist(question)

    specialist_map = {
        "returns": returns_agent,
        "billing": billing_agent,
    }

    answer = run_agent(
        specialist_map[decision.specialist],
        decision.rewritten_question,
    )

    print("Chosen specialist:", decision.specialist)
    print("Rewritten question:", decision.rewritten_question)
    print()
    print("Answer:")
    print(answer)


