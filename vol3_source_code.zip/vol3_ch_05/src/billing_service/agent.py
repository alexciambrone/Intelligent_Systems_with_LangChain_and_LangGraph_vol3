from __future__ import annotations
from typing import Any, Dict, List, TypedDict
from langchain.chat_models import init_chat_model
from langgraph.graph import StateGraph, START
from config import OPENAI_API_KEY

MODEL = init_chat_model("openai:gpt-4.1-mini", temperature=0)

class A2AState(TypedDict):
    messages: List[Dict[str, Any]]


SYSTEM_PROMPT = """You are the billing specialist for an online store.
Answer only the billing side of the request.

Billing policy:
- Duplicate charges must be investigated before any refund is issued.
- Invoices are available in the customer account.
- Billing disputes and manual billing overrides require escalation.

Keep the answer short, concrete, and customer-facing.
"""


def latest_user_text(messages: List[Dict[str, Any]]) -> str:
    for message in reversed(messages):
        if message.get("role") == "user":
            return str(message.get("content", ""))
    return ""


def answer(state: A2AState) -> Dict[str, Any]:
    user_text = latest_user_text(state["messages"])

    reply = MODEL.invoke(
        [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_text},
        ]
    )

    return {
        "messages": state["messages"] + [
            {"role": "assistant", "content": reply.content}
        ]
    }


builder = StateGraph(A2AState)
builder.add_node("answer", answer)
builder.add_edge(START, "answer")
graph = builder.compile()