from __future__ import annotations

import json
from enum import Enum

from pydantic import BaseModel, Field
from langchain.tools import tool

ORDERS = {
    "ORD-100": {
        "status": "delivered",
        "amount": 129.00,
        "currency": "EUR",
        "refundable": True,
    }
}

class Channel(str, Enum):
    WEB = "web"
    MOBILE = "mobile"
    STORE = "store"

class OrderLookupInput(BaseModel):
    order_id: str = Field(
        ...,
        description="Customer order identifier such as ORD-100",
        pattern=r"^ORD-\d{3,}$",
        examples=["ORD-100"],
    )
    include_history: bool = Field(
        default=False,
        description="Whether to include recent order events",
    )
    max_events: int = Field(
        default=5,
        ge=1,
        le=20,
        description="Maximum number of order events to return",
    )
    channel: Channel = Field(
        ...,
        description="Sales channel where the order was placed",
    )

@tool(args_schema=OrderLookupInput)
def lookup_order(
    order_id: str,
    include_history: bool = False,
    max_events: int = 5,
    channel: Channel = Channel.WEB,
) -> dict:
    """Return normalized order status data for a single order."""
    order = ORDERS[order_id]
    return {
        "order_id": order_id,
        "status": order["status"],
        "amount": order["amount"],
        "currency": order["currency"],
        "refundable": order["refundable"],
        "include_history": include_history,
        "max_events": max_events,
        "channel": channel.value,
    }

if __name__ == "__main__":
    schema = lookup_order.args_schema.model_json_schema()
    print("=== EXPLICIT PYDANTIC SCHEMA ===")
    print(json.dumps(schema, indent=2))
    print()
    print("=== TOOL RESULT ===")
    print(lookup_order.invoke({
        "order_id": "ORD-100",
        "include_history": True,
        "max_events": 3,
        "channel": "web",
    }))
