from dataclasses import dataclass
from typing import Any, Callable
from typing_extensions import NotRequired

from langchain.agents import create_agent
from langchain.agents.middleware import (
    AgentMiddleware,
    AgentState,
    ExtendedModelResponse,
    ModelRequest,
    ModelResponse,
    dynamic_prompt,
    hook_config,
)
from langchain.messages import AIMessage, ToolMessage
from langchain.tools import tool
from langchain.tools.tool_node import ToolCallRequest
from langgraph.types import Command
from langchain_openai import ChatOpenAI
from .config import OPENAI_API_KEY

ORDERS = {
    "ORD-100": {
        "days_since_delivery": 12,
        "opened": False,
        "amount": 129.00,
        "status": "delivered",
    },
    "ORD-101": {
        "days_since_delivery": 41,
        "opened": True,
        "amount": 79.00,
        "status": "delivered",
    },
}

REFUND_POLICY = {
    "max_days": 30,
    "opened_items_allowed": False,
}


@tool
def lookup_order(order_id: str) -> dict[str, Any]:
    """Return order facts needed for a refund decision."""
    order = ORDERS.get(order_id)
    if order is None:
        return {"found": False, "order_id": order_id}
    return {"found": True, "order_id": order_id, **order}


@tool
def get_refund_policy() -> dict[str, Any]:
    """Return the current standard refund policy."""
    return REFUND_POLICY


@tool
def evaluate_refund(
    days_since_delivery: int,
    opened: bool,
    max_days: int,
    opened_items_allowed: bool,
) -> dict[str, Any]:
    """Evaluate refund eligibility from order facts and policy facts."""
    eligible = (
        days_since_delivery <= max_days
        and (opened_items_allowed or not opened)
    )

    if eligible:
        reason = "The order is within the refund window and meets the item-condition rule."
    elif days_since_delivery > max_days:
        reason = "The order is outside the refund window."
    else:
        reason = "Opened items are not eligible under the standard policy."

    return {
        "eligible": eligible,
        "reason": reason,
    }


@tool
def create_return_label(order_id: str) -> str:
    """Create a return label for an order that is eligible for return processing."""
    return f"Return label created for {order_id}"


basic_model = ChatOpenAI(
    model="gpt-4.1-mini",
    api_key=OPENAI_API_KEY,
    temperature=0,
)

advanced_model = ChatOpenAI(
    model="gpt-4.1",
    api_key=OPENAI_API_KEY,
    temperature=0,
)


@dataclass
class SupportContext:
    user_tier: str   # "standard" or "premium"
    audience: str    # "end_user" or "expert"


class SupportState(AgentState):
    model_call_count: NotRequired[int]
    selected_model: NotRequired[str]
    started: NotRequired[bool]
    finished: NotRequired[bool]


@dynamic_prompt
def support_prompt(request: ModelRequest) -> str:
    audience = request.runtime.context.audience

    if audience == "expert":
        style = "Be concise, technical, and explicit about the rule that was applied."
    else:
        style = "Explain the result in plain language and avoid jargon."

    return (
        "You are a customer support assistant. "
        "For refund questions, first gather order facts, then gather policy facts, "
        "then evaluate eligibility, then explain the result clearly. "
        "Before each tool call, write one short visible sentence describing the next step. "
        "Do not expose hidden reasoning. Use concise action summaries only. "
        f"{style}"
    )


class SupportOperationsMiddleware(AgentMiddleware[SupportState]):
    state_schema = SupportState

    def before_agent(self, state: SupportState, runtime) -> dict[str, Any] | None:
        return {
            "started": True,
            "model_call_count": 0,
            "finished": False,
        }

    @hook_config(can_jump_to=["end"])
    def before_model(self, state: SupportState, runtime) -> dict[str, Any] | None:
        # A normal successful path may need:
        # 1) lookup_order
        # 2) get_refund_policy
        # 3) evaluate_refund
        # 4) create_return_label
        # 5) final answer
        # Give it one extra turn of headroom.
        if state.get("model_call_count", 0) >= 6:
            return {
                "messages": [
                    AIMessage(
                        content=(
                            "I could not complete this request within the allowed "
                            "reasoning budget. Please hand it to a human support agent."
                        )
                    )
                ],
                "jump_to": "end",
            }
        return None

    def after_model(self, state: SupportState, runtime) -> dict[str, Any] | None:
        return {"model_call_count": state.get("model_call_count", 0) + 1}

    def after_agent(self, state: SupportState, runtime) -> dict[str, Any] | None:
        return {"finished": True}

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ExtendedModelResponse:
        if len(request.messages) > 8:
            selected_model = advanced_model
            selected_label = "gpt-4.1"
        else:
            selected_model = basic_model
            selected_label = "gpt-4.1-mini"

        if request.runtime.context.user_tier == "premium":
            visible_tools = list(request.tools)
        else:
            visible_tools = [
                tool for tool in request.tools
                if tool.name != "create_return_label"
            ]

        response = handler(
            request.override(
                model=selected_model,
                tools=visible_tools,
            )
        )

        return ExtendedModelResponse(
            model_response=response,
            command=Command(update={"selected_model": selected_label}),
        )

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage | Command],
    ) -> ToolMessage | Command:
        try:
            return handler(request)
        except Exception as exc:
            return ToolMessage(
                content=f"Tool {request.tool_call['name']} failed: {exc}",
                tool_call_id=request.tool_call["id"],
                name=request.tool_call["name"],
            )


agent = create_agent(
    model=basic_model,
    tools=[lookup_order, get_refund_policy, evaluate_refund, create_return_label],
    middleware=[
        SupportOperationsMiddleware(),
        support_prompt,
    ],
    context_schema=SupportContext,
    name="support_refund_agent",
)


def print_trace(result: dict[str, Any]) -> None:
    messages = result["messages"]

    print("\nTRACE\n")
    visible_step = 1

    for message in messages:
        if isinstance(message, AIMessage):
            printed_anything = False

            if message.content:
                print(f"--- step {visible_step}: assistant ---")
                print(f"[assistant] {message.content}")
                printed_anything = True

            tool_calls = getattr(message, "tool_calls", None) or []
            for tool_call in tool_calls:
                if not printed_anything:
                    print(f"--- step {visible_step}: assistant ---")
                    printed_anything = True
                print(
                    f"[assistant -> tool] "
                    f"{tool_call['name']}({tool_call['args']})"
                )

            if printed_anything:
                visible_step += 1

        elif isinstance(message, ToolMessage):
            print(f"--- step {visible_step}: tool ---")
            print(f"[tool:{message.name}] {message.content}")
            visible_step += 1

    print("\nFINAL\n")
    print(messages[-1].content)
    print("selected_model =", result.get("selected_model"))
    print("model_call_count =", result.get("model_call_count"))
    print("started =", result.get("started"), "finished =", result.get("finished"))
def main() -> None:
    inputs = {
        "messages": [
            {
                "role": "user",
                "content": (
                    "Can order ORD-100 be refunded? "
                    "If it is eligible, create a return label."
                ),
            }
        ]
    }

    context = SupportContext(
        user_tier="premium",
        audience="end_user",
    )

    result = agent.invoke(inputs, context=context)
    print_trace(result)


if __name__ == "__main__":
    main()