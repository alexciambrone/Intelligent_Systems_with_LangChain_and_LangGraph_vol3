from __future__ import annotations

import json
import os
from typing import Annotated, Any, TypedDict

from langchain.chat_models import init_chat_model
from langchain.messages import AIMessage, ToolMessage
from langchain.tools import tool
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode

from .config import OPENAI_API_KEY


ORDERS = {
    "ORD-100": {
        "status": "delivered",
        "days_since_delivery": 12,
        "item_opened": False,
        "amount": 129.00,
    },
    "ORD-101": {
        "status": "delivered",
        "days_since_delivery": 41,
        "item_opened": True,
        "amount": 59.00,
    },
}


@tool
def lookup_order(order_id: str) -> str:
    """Return normalized facts for a single order."""
    order = ORDERS[order_id]
    return json.dumps(
        {
            "order_id": order_id,
            "status": order["status"],
            "days_since_delivery": order["days_since_delivery"],
            "item_opened": order["item_opened"],
            "amount": order["amount"],
        }
    )


@tool
def evaluate_refund_policy(days_since_delivery: int, item_opened: bool) -> str:
    """Evaluate whether a delivered item is still eligible for the standard refund policy."""
    eligible = days_since_delivery <= 30 and not item_opened
    return json.dumps(
        {
            "eligible": eligible,
            "reason": (
                "within 30 days and unopened"
                if eligible
                else "outside the standard refund window"
            ),
        }
    )


class SupportState(TypedDict):
    messages: Annotated[list, add_messages]


SYSTEM_PROMPT = """You are a customer support assistant.

Rules:
1. When you decide to use a tool, include one short visible sentence explaining the next step.
2. Keep that sentence concise and factual.
3. After tool results arrive, explain the conclusion clearly.
4. Do not expose private reasoning. Only provide brief action summaries.
"""


def _json_dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, default=str)


def _content_to_text(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                if item.get("type") == "text" and "text" in item:
                    parts.append(str(item["text"]))
                elif "text" in item:
                    parts.append(str(item["text"]))
                else:
                    parts.append(_json_dumps(item))
            else:
                parts.append(str(item))
        return " ".join(p for p in parts if p)
    if isinstance(content, dict):
        return _json_dumps(content)
    return str(content)


def _short(text: str, limit: int = 240) -> str:
    text = " ".join(text.split()).strip()
    if len(text) <= limit:
        return text
    return text[: limit - 3] + "..."


def _print_ai_message(msg: AIMessage) -> str | None:
    final_answer = None

    text = _short(_content_to_text(msg.content))
    if text:
        print(f"[assistant] {text}")

    tool_calls = getattr(msg, "tool_calls", None) or []
    for call in tool_calls:
        name = call.get("name", "<unknown>")
        args = call.get("args", {})
        print(f"[assistant -> tool] {name}({_json_dumps(args)})")

    if text and not tool_calls:
        final_answer = text

    return final_answer


def _print_tool_message(msg: ToolMessage) -> None:
    name = getattr(msg, "name", None) or "tool"
    text = _short(_content_to_text(msg.content))
    print(f"[{name}] {text}")


def main() -> None:
    if not os.environ.get("OPENAI_API_KEY") and not OPENAI_API_KEY:
        raise RuntimeError("Set OPENAI_API_KEY before running this example.")

    if OPENAI_API_KEY and not os.environ.get("OPENAI_API_KEY"):
        os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

    tools = [lookup_order, evaluate_refund_policy]

    model = init_chat_model(
        "gpt-4.1-mini",
        model_provider="openai",
        temperature=0,
    )

    model_with_tools = model.bind_tools(tools)
    tool_node = ToolNode(tools)

    def call_model(state: SupportState) -> SupportState:
        response = model_with_tools.invoke(
            [
                ("system", SYSTEM_PROMPT),
                *state["messages"],
            ]
        )
        return {"messages": [response]}

    def route_after_model(state: SupportState) -> str:
        last_message = state["messages"][-1]
        return "tools" if getattr(last_message, "tool_calls", None) else "end"

    graph_builder = StateGraph(SupportState)
    graph_builder.add_node("call_model", call_model)
    graph_builder.add_node("tools", tool_node)

    graph_builder.add_edge(START, "call_model")
    graph_builder.add_conditional_edges(
        "call_model",
        route_after_model,
        {
            "tools": "tools",
            "end": END,
        },
    )
    graph_builder.add_edge("tools", "call_model")

    graph = graph_builder.compile()

    input_state = {
        "messages": [
            (
                "user",
                "A customer asks whether order ORD-100 is still refundable. "
                "Check the order first, then answer.",
            )
        ]
    }

    print("\nTRACE\n")

    step = 0
    final_answer: str | None = None

    for chunk in graph.stream(input_state, stream_mode="updates"):
        for node_name, update in chunk.items():
            step += 1
            print(f"--- step {step}: {node_name} ---")

            messages = update.get("messages", [])
            for msg in messages:
                if isinstance(msg, AIMessage):
                    maybe_final = _print_ai_message(msg)
                    if maybe_final:
                        final_answer = maybe_final
                elif isinstance(msg, ToolMessage):
                    _print_tool_message(msg)
                else:
                    text = _short(_content_to_text(getattr(msg, "content", msg)))
                    print(f"[{node_name}] {text}")

            print()

    print("FINAL ANSWER\n")
    print(final_answer or "<no final answer captured>")


if __name__ == "__main__":
    main()