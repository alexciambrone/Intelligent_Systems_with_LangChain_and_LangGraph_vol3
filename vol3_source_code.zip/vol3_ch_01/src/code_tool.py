from __future__ import annotations

import ast
import subprocess
import sys
import tempfile
import textwrap
from pathlib import Path

from langchain.tools import tool
from pydantic import BaseModel, Field


ALLOWED_IMPORTS = {
    "csv",
    "decimal",
    "json",
    "math",
    "statistics",
}

BLOCKED_CALLS = {
    "__import__",
    "compile",
    "eval",
    "exec",
    "globals",
    "input",
    "locals",
    "open",
    "vars",
}


class PythonAnalysisInput(BaseModel):
    code: str = Field(
        ...,
        description=(
            "Small Python script to execute. "
            "The script must print the final result."
        ),
    )
    timeout_seconds: int = Field(
        default=3,
        ge=1,
        le=10,
        description="Maximum execution time in seconds.",
    )


def validate_code(code: str) -> str | None:
    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        return f"Rejected: invalid Python syntax ({exc.msg})."

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                root_module = alias.name.split(".")[0]
                if root_module not in ALLOWED_IMPORTS:
                    return f"Rejected: import '{root_module}' is not allowed."

        if isinstance(node, ast.ImportFrom):
            root_module = (node.module or "").split(".")[0]
            if root_module not in ALLOWED_IMPORTS:
                return f"Rejected: import '{root_module}' is not allowed."

        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in BLOCKED_CALLS:
                return f"Rejected: call to '{node.func.id}' is not allowed."

        if isinstance(node, ast.Attribute):
            if node.attr.startswith("__"):
                return "Rejected: access to private Python attributes is not allowed."

    return None


@tool(args_schema=PythonAnalysisInput)
def run_python_analysis(code: str, timeout_seconds: int = 3) -> str:
    """Run a small Python analysis script and return what it prints."""

    validation_error = validate_code(code)
    if validation_error:
        return validation_error

    with tempfile.TemporaryDirectory() as temp_dir:
        script_path = Path(temp_dir) / "analysis.py"
        script_path.write_text(code, encoding="utf-8")

        try:
            completed = subprocess.run(
                [sys.executable, str(script_path)],
                cwd=temp_dir,
                capture_output=True,
                text=True,
                timeout=timeout_seconds,
                check=False,
            )
        except subprocess.TimeoutExpired:
            return "ERROR: code execution timed out."

        if completed.returncode != 0:
            return f"ERROR:\n{completed.stderr.strip()}"

        output = completed.stdout.strip()
        return output if output else "(no output printed)"


if __name__ == "__main__":
    analysis_code = """
from statistics import mean
import json

orders = [
    {"order_id": "ORD-100", "amount": 129.00, "status": "delivered"},
    {"order_id": "ORD-101", "amount": 42.50, "status": "processing"},
    {"order_id": "ORD-102", "amount": 310.00, "status": "delivered"},
]

delivered_amounts = [
    order["amount"]
    for order in orders
    if order["status"] == "delivered"
]

report = {
    "delivered_orders": len(delivered_amounts),
    "average_delivered_value": round(mean(delivered_amounts), 2),
    "total_delivered_value": round(sum(delivered_amounts), 2),
}

print(json.dumps(report, indent=2))
"""

    result = run_python_analysis.invoke(
        {
            "code": textwrap.dedent(analysis_code),
            "timeout_seconds": 3,
        }
    )

    print(result)
