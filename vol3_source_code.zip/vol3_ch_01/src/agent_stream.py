from langchain.agents import create_agent
from langchain.tools import tool
from .config import OPENAI_API_KEY

ORDERS = {
    "ORD-100": {
        "status": "delivered",
        "days_since_delivery": 12,
        "item_opened": False,
        "amount": 129.00,
    }
}


@tool
def lookup_order(order_id: str) -> str:
    """Return the order details needed to assess refund eligibility."""
    order = ORDERS.get(order_id)
    if not order:
        return f"Order {order_id} was not found."
    return (
        f"Order {order_id}: status={order['status']}, "
        f"days_since_delivery={order['days_since_delivery']}, "
        f"item_opened={order['item_opened']}, "
        f"amount={order['amount']}"
    )


agent = create_agent(
    model="openai:gpt-5-mini",
    tools=[lookup_order],
    system_prompt=(
        "You are a customer support assistant. "
        "Use the tool when order data is needed. "
        "Answer clearly and briefly."
    ),
)

for mode, data in agent.stream(
    {
        "messages": [
            {"role": "user", "content": "Can order ORD-100 be refunded?"}
        ]
    },
    stream_mode=["updates", "messages"],
    version="v2",
):
    if mode == "updates":
        print("\nSTATE UPDATE:")
        print(data)

    elif mode == "messages":
        message_chunk, metadata = data
        if getattr(message_chunk, "content", None):
            print(message_chunk.content, end="", flush=True)