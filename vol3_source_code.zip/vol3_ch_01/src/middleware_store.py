from dataclasses import dataclass
from langchain.agents import create_agent
from langchain.tools import tool, ToolRuntime
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.store.memory import InMemoryStore
from .config import OPENAI_API_KEY

store = InMemoryStore()
store.put(("users",), "user_123", {"preferred_channel": "sms"})

@dataclass
class Context:
    user_id: str

@tool
def get_customer_profile(runtime: ToolRuntime[Context]) -> str:
    """Look up durable customer preferences."""
    user_info = runtime.store.get(("users",), runtime.context.user_id)
    return str(user_info.value) if user_info else "Unknown user"

agent = create_agent(
    model="openai:gpt-5-mini",
    tools=[get_customer_profile],
    store=store,
    context_schema=Context,
    checkpointer=InMemorySaver(),
)

config = {"configurable": {"thread_id": "support-thread-1"}}

result = agent.invoke(
    {
        "messages": [
            {
                "role": "user",
                "content": "What contact channel does this customer prefer?"
            }
        ]
    },
    config=config,
    context=Context(user_id="user_123"),
)

print(result["messages"][-1].content)
