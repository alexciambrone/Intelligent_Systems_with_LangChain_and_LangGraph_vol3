from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from enum import Enum
from time import monotonic
from typing import Any

from pydantic import BaseModel, Field
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
from langchain_core.runnables import RunnableConfig
from langgraph.store.memory import InMemoryStore
from langchain.agents import create_agent
from langchain.agents.middleware import ToolRetryMiddleware
from .config import OPENAI_API_KEY

ORDERS = {
    "ORD-100": {
        "user_id": "user-123",
        "status": "delivered",
        "tracking_number": "TRK-100",
        "refundable_amount": 59.00,
    },
    "ORD-101": {
        "user_id": "user-123",
        "status": "processing",
        "tracking_number": "TRK-101",
        "refundable_amount": 0.00,
    },
}


class OrderLookupInput(BaseModel):
    order_id: str = Field(
        ...,
        description="Order identifier such as ORD-100",
        pattern=r"^ORD-\d{3,}$",
    )


class RefundReason(str, Enum):
    DAMAGED = "damaged"
    WRONG_ITEM = "wrong_item"
    LATE_DELIVERY = "late_delivery"


class RefundInput(BaseModel):
    order_id: str = Field(
        ...,
        description="Order identifier such as ORD-100",
        pattern=r"^ORD-\d{3,}$",
    )
    reason: RefundReason = Field(
        ...,
        description="Reason for the refund request",
    )
    amount: float = Field(
        ...,
        gt=0,
        description="Refund amount in euros",
    )


class CarrierLookupInput(BaseModel):
    tracking_number: str = Field(
        ...,
        description="Tracking identifier such as TRK-100",
        pattern=r"^TRK-[A-Z0-9-]+$",
    )


class CircuitOpenError(RuntimeError):
    pass


class FakeCarrierClient:
    async def lookup(self, tracking_number: str) -> dict:
        if tracking_number == "TRK-TIMEOUT":
            await asyncio.sleep(5)
            return {"carrier_status": "unknown"}

        if tracking_number == "TRK-FAIL":
            raise ConnectionError("carrier gateway unavailable")

        await asyncio.sleep(0.2)
        return {
            "carrier_status": "in_transit",
            "carrier": "AcmeExpress",
        }


class AsyncCircuitBreaker:
    def __init__(self, failure_threshold: int = 3, reset_after_seconds: float = 30.0):
        self.failure_threshold = failure_threshold
        self.reset_after_seconds = reset_after_seconds
        self.failure_count = 0
        self.opened_at: float | None = None

    def _is_open(self) -> bool:
        if self.opened_at is None:
            return False
        if monotonic() - self.opened_at >= self.reset_after_seconds:
            self.failure_count = 0
            self.opened_at = None
            return False
        return True

    async def call(self, func, *args, **kwargs):
        if self._is_open():
            raise CircuitOpenError("carrier service temporarily unavailable")
        try:
            result = await func(*args, **kwargs)
        except (ConnectionError, TimeoutError):
            self.failure_count += 1
            if self.failure_count >= self.failure_threshold:
                self.opened_at = monotonic()
            raise
        else:
            self.failure_count = 0
            self.opened_at = None
            return result


@dataclass
class SupportContext:
    user_id: str
    carrier_client: FakeCarrierClient
    carrier_breaker: AsyncCircuitBreaker
    # Teaching-only switch: records refund actions for which the example has
    # already simulated a lost response after the side effect was committed.
    refund_timeout_after_commit_once: set[str] = field(default_factory=set)


async def query_carrier_with_timeout(
    client: FakeCarrierClient,
    tracking_number: str,
    timeout_seconds: float,
) -> dict:
    async with asyncio.timeout(timeout_seconds):
        return await client.lookup(tracking_number)

@tool(args_schema=OrderLookupInput)
def lookup_order(order_id: str, config: RunnableConfig) -> dict:
    """Look up one order for the authenticated user."""
    ctx: SupportContext = config["configurable"]["support_context"]
    order = ORDERS.get(order_id)

    if order is None:
        return {"ok": False, "error": "order_not_found"}

    if order["user_id"] != ctx.user_id:
        return {"ok": False, "error": "forbidden"}

    return {
        "ok": True,
        "order_id": order_id,
        "status": order["status"],
        "tracking_number": order["tracking_number"],
        "refundable_amount": order["refundable_amount"],
    }


@tool(args_schema=RefundInput)
def request_refund(
    order_id: str,
    reason: RefundReason,
    amount: float,
    config: RunnableConfig,
) -> dict:
    """Create a refund request, or return the existing result for the same business action."""
    ctx: SupportContext = config["configurable"]["support_context"]
    store: InMemoryStore = config["configurable"]["store"]

    order = ORDERS.get(order_id)

    if order is None:
        return {"ok": False, "error": "order_not_found"}

    if order["user_id"] != ctx.user_id:
        return {"ok": False, "error": "forbidden"}

    if amount > order["refundable_amount"]:
        return {"ok": False, "error": "amount_exceeds_refundable_amount"}

    if store is None:
        raise RuntimeError("A store is required for idempotent refund handling")

    # Stable business key for retry safety.
    idempotency_key = f"refund:{order_id}:{reason.value}:{amount:.2f}"
    namespace = ("refunds", ctx.user_id)

    existing = store.get(namespace, idempotency_key)
    if existing is not None:
        return {"ok": True, "replayed": True, **existing.value}

    refund = {
        "refund_id": f"rf_{order_id.lower()}_{reason.value}",
        "order_id": order_id,
        "reason": reason.value,
        "amount": amount,
        "status": "accepted",
    }

    store.put(namespace, idempotency_key, refund)

    # Teaching-only failure injection. This simulates a common distributed-system
    # ambiguity: the refund was accepted and stored, but the caller receives a
    # timeout before it sees the response. ToolRetryMiddleware retries the tool
    # call. Because the idempotency key is stable, the second call finds the
    # existing refund above and returns it as a replay instead of creating a
    # duplicate refund.
    if idempotency_key not in ctx.refund_timeout_after_commit_once:
        ctx.refund_timeout_after_commit_once.add(idempotency_key)
        raise TimeoutError("refund gateway timed out after accepting the request")

    return {"ok": True, "replayed": False, **refund}


@tool(args_schema=CarrierLookupInput)
async def fetch_carrier_status(
    tracking_number: str,
    config: RunnableConfig,
) -> dict:
    """Get carrier status with an execution timeout and a circuit breaker.

    Generic retry behavior is intentionally not implemented in this tool.
    Transient ConnectionError and TimeoutError exceptions are allowed to
    propagate so ToolRetryMiddleware can retry the failed tool call.
    """
    ctx: SupportContext = config["configurable"]["support_context"]
    client = ctx.carrier_client
    breaker = ctx.carrier_breaker

    try:
        result = await breaker.call(
            query_carrier_with_timeout,
            client,
            tracking_number,
            2.0,
        )
    except CircuitOpenError as exc:
        # The circuit breaker is already open, so this is not a transient
        # carrier call worth retrying immediately. Return a controlled
        # domain-level failure to the agent.
        return {"ok": False, "error": str(exc)}

    return {
        "ok": True,
        "tracking_number": tracking_number,
        **result,
    }


def retry_failure_message(error: Exception) -> str:
    """Return the final tool message after ToolRetryMiddleware exhausts retries."""
    return f"tool failed after retry attempts: {error}"


async def main() -> None:
    store = InMemoryStore()

    context = SupportContext(
        user_id="user-123",
        carrier_client=FakeCarrierClient(),
        carrier_breaker=AsyncCircuitBreaker(failure_threshold=3, reset_after_seconds=30.0),
    )

    # create_agent builds the LangGraph-backed agent runtime.
    # ToolRetryMiddleware retries two tools in this teaching example:
    # - fetch_carrier_status, which calls a network-like dependency.
    # - request_refund, which is side-effecting but protected by a stable
    #   idempotency key, so retry can safely replay the same business action.
    agent = create_agent(
        model=ChatOpenAI(model="gpt-4o-mini", temperature=0),
        tools=[lookup_order, request_refund, fetch_carrier_status],
        middleware=[
            ToolRetryMiddleware(
                max_retries=2,
                initial_delay=0.5,
                backoff_factor=2.0,
                max_delay=5.0,
                jitter=False,
                tools=["fetch_carrier_status", "request_refund"],
                retry_on=(ConnectionError, TimeoutError),
                on_failure=retry_failure_message,
            )
        ],
        store=store,
    )

    result = await agent.ainvoke(
        {
            "messages": [
                {
                    "role": "user",
                    "content": (
                        "Check order ORD-100, tell me the order status and carrier status, "
                        "then tell me whether it can be refunded. If it can, request a "
                        "refund for 59 euros because it arrived damaged."
                    ),
                }
            ]
        },
        config={
            "configurable": {
                "support_context": context,
                "store": store,   # passed explicitly so request_refund can use it
            }
        },
    )

    print(result["messages"][-1].content)


if __name__ == "__main__":
    asyncio.run(main())