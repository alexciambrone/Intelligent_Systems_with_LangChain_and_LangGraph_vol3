from __future__ import annotations

import json
import os

from langchain.chat_models import init_chat_model
from langchain.messages import HumanMessage, ToolMessage
from langchain.tools import tool
from .config import OPENAI_API_KEY

ORDERS = {
    "ORD-100": {
        "status": "delivered",
        "days_since_delivery": 12,
        "item_opened": False,
        "amount": 129.00,
    },
    "ORD-101": {
        "status": "delivered",
        "days_since_delivery": 41,
        "item_opened": True,
        "amount": 59.00,
    },
}


@tool
def lookup_order(order_id: str) -> str:
    """Return normalized facts for a single order."""
    order = ORDERS[order_id]
    return json.dumps(
        {
            "order_id": order_id,
            "status": order["status"],
            "days_since_delivery": order["days_since_delivery"],
            "item_opened": order["item_opened"],
            "amount": order["amount"],
        }
    )


@tool
def evaluate_refund_policy(days_since_delivery: int, item_opened: bool) -> str:
    """Evaluate whether a delivered item is still eligible for the standard refund policy."""
    eligible = days_since_delivery <= 30 and not item_opened
    return json.dumps(
        {
            "eligible": eligible,
            "reason": (
                "within 30 days and unopened"
                if eligible
                else "outside the standard refund window"
            ),
        }
    )


def main() -> None:
    model = init_chat_model(
        "gpt-4.1-mini",
        model_provider="openai",
        temperature=0,
    )

    tools = [lookup_order, evaluate_refund_policy]
    tools_by_name = {tool.name: tool for tool in tools}

    # Bind the tool contracts to the model.
    model_with_tools = model.bind_tools(tools)

    messages = [
        HumanMessage(
            content=(
                "A customer asks whether order ORD-100 is still refundable. "
                "Check the order first, then answer."
            )
        )
    ]

    while True:
        ai_msg = model_with_tools.invoke(messages)
        messages.append(ai_msg)

        if not ai_msg.tool_calls:
            print("\nFINAL ANSWER\n")
            print(ai_msg.content)
            break

        for tool_call in ai_msg.tool_calls:
            print(f"\nTOOL CALL -> {tool_call['name']}({tool_call['args']})")

            tool = tools_by_name[tool_call["name"]]
            result = tool.invoke(tool_call["args"])

            print(f"TOOL RESULT -> {result}")

            messages.append(
                ToolMessage(
                    content=result,
                    tool_call_id=tool_call["id"],
                )
            )


if __name__ == "__main__":
    main()


