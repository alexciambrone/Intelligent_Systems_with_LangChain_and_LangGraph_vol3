from __future__ import annotations
from enum import Enum
from pydantic import BaseModel, Field
from langchain.tools import tool

ORDERS = {
    "ORD-100": {
        "status": "delivered",
        "refundable_amount": 129.00,
    }
}

REFUNDS: dict[str, dict] = {}

class RefundReason(str, Enum):
    DAMAGED = "damaged"
    WRONG_ITEM = "wrong_item"
    LATE_DELIVERY = "late_delivery"

class RefundInput(BaseModel):
    order_id: str = Field(..., description="Order identifier such as ORD-100")
    reason: RefundReason = Field(..., description="Why the customer is asking for a refund")
    amount: float = Field(..., gt=0, description="Refund amount in euros")

@tool(
    args_schema=RefundInput,
    description="Create a refund request or return the existing one for the same business action."
)
def request_refund(order_id: str, reason: RefundReason, amount: float) -> dict:    # Create a refund request or return the existing one for the same business action.
    order = ORDERS[order_id]

    if amount > order["refundable_amount"]:
        return {
            "ok": False,
            "error": "amount_exceeds_refundable_amount",
        }

    # Domain-level idempotency key.
    # In a real system, store this record in durable storage.
    idempotency_key = f"refund:{order_id}:{reason.value}:{amount:.2f}"

    if idempotency_key in REFUNDS:
        return {
            "ok": True,
            "replayed": True,
            **REFUNDS[idempotency_key],
        }

    refund = {
        "refund_id": f"rf_{len(REFUNDS) + 1:04d}",
        "order_id": order_id,
        "reason": reason.value,
        "amount": amount,
        "status": "accepted",
    }
    REFUNDS[idempotency_key] = refund

    return {
        "ok": True,
        "replayed": False,
        **refund,
    }

if __name__ == "__main__":
    first = request_refund.invoke(
        {"order_id": "ORD-100", "reason": "damaged", "amount": 129.0}
    )
    second = request_refund.invoke(
        {"order_id": "ORD-100", "reason": "damaged", "amount": 129.0}
    )

    print(first)
    print(second)