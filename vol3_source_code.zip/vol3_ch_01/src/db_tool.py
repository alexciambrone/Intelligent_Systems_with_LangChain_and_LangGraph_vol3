from pathlib import Path
import sqlite3

from langchain_openai import ChatOpenAI
from langchain_community.utilities import SQLDatabase
from langchain_community.agent_toolkits import SQLDatabaseToolkit

db_path = Path("shop.db")

# Build the demo database
conn = sqlite3.connect(db_path)
conn.executescript("""
DROP TABLE IF EXISTS orders;

CREATE TABLE orders (
    order_id TEXT PRIMARY KEY,
    customer_name TEXT NOT NULL,
    total_amount REAL NOT NULL,
    status TEXT NOT NULL
);

INSERT INTO orders VALUES
    ('ORD-100', 'Alice', 129.00, 'delivered'),
    ('ORD-101', 'Bob', 42.50, 'processing'),
    ('ORD-102', 'Carla', 310.00, 'delivered');

-- Expose only a safe, read-only projection for the agent.
DROP VIEW IF EXISTS agent_orders;
CREATE VIEW agent_orders AS
SELECT
    order_id,
    total_amount,
    status
FROM orders;
""")
conn.commit()
conn.close()

# Open SQLite in read-only mode.
# SQLAlchemy documents SQLite URI mode=ro with uri=true.
readonly_uri = f"sqlite:///file:{db_path}?mode=ro&uri=true"

# Only expose the view, not the base table.
db = SQLDatabase.from_uri(
    readonly_uri,
    include_tables=["agent_orders"],
    view_support=True,
)

model = ChatOpenAI(model="gpt-4.1-mini", temperature=0)
toolkit = SQLDatabaseToolkit(db=db, llm=model)
tools = {tool.name: tool for tool in toolkit.get_tools()}

print("Tables:", tools["sql_db_list_tables"].invoke(""))
print("Schema:", tools["sql_db_schema"].invoke("agent_orders"))

print(
    "Top order:",
    tools["sql_db_query"].invoke(
        "SELECT order_id, total_amount, status "
        "FROM agent_orders "
        "ORDER BY total_amount DESC "
        "LIMIT 1;"
    ),
)

# This should fail because the connection is read-only.
try:
    print(
        tools["sql_db_query"].invoke(
            "UPDATE orders SET status = 'refunded' WHERE order_id = 'ORD-100';"
        )
    )
except Exception as e:
    print("Write blocked:", e)


