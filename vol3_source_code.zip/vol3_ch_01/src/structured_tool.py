from __future__ import annotations
from typing import Literal
from pydantic import BaseModel, Field
from langchain_core.tools import StructuredTool

CATALOG = [
    {"sku": "LAP-100", "category": "laptop", "price": 999.0, "in_stock": True},
    {"sku": "LAP-200", "category": "laptop", "price": 1499.0, "in_stock": False},
    {"sku": "MON-100", "category": "monitor", "price": 299.0, "in_stock": True},
]

class ProductSearchInput(BaseModel):
    category: Literal["laptop", "monitor"] = Field(description="Product category")
    max_price: float | None = Field(default=None, description="Maximum price limit")
    in_stock_only: bool = Field(default=True, description="Return only in-stock items")
    limit: int = Field(default=5, ge=1, le=20, description="Maximum number of results")

def search_catalog(
    category: str,
    max_price: float | None = None,
    in_stock_only: bool = True,
    limit: int = 5,
) -> list[dict]:
    results = []
    for item in CATALOG:
        if item["category"] != category:
            continue
        if max_price is not None and item["price"] > max_price:
            continue
        if in_stock_only and not item["in_stock"]:
            continue
        results.append(item)
    return results[:limit]

catalog_search_tool = StructuredTool.from_function(
    func=search_catalog,
    name="catalog_search",
    description="Search the e-commerce catalog using structured filters.",
    args_schema=ProductSearchInput,
)

if __name__ == "__main__":
    print(
        catalog_search_tool.invoke(
            {
                "category": "laptop",
                "max_price": 1200,
                "in_stock_only": True,
                "limit": 3,
            }
        )
    )



