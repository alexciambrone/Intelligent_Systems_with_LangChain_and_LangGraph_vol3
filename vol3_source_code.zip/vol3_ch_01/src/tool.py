from __future__ import annotations
import json
from langchain.tools import tool

ORDERS = {
    "ORD-100": {"status": "delivered", "days_since_delivery": 12, "amount": 129.00},
    "ORD-101": {"status": "processing", "days_since_delivery": 0, "amount": 59.00},
}

@tool
def lookup_order(order_id: str) -> dict:
    """Return basic order facts for a single order."""
    order = ORDERS[order_id]
    return {
        "order_id": order_id,
        "status": order["status"],
        "days_since_delivery": order["days_since_delivery"],
        "amount": order["amount"],
    }

if __name__ == "__main__":
    print("=== TOOL SCHEMA ===")
    print(json.dumps(lookup_order.args_schema.model_json_schema(), indent=2))
    print()
    print("=== TOOL RESULT ===")
    print(lookup_order.invoke({"order_id": "ORD-101"}))