from __future__ import annotations

import os
import uuid
from typing import Any

from langchain.agents import create_agent
from langchain.agents.middleware import (
    HumanInTheLoopMiddleware,
    ModelCallLimitMiddleware,
    ModelFallbackMiddleware,
    PIIMiddleware,
    SummarizationMiddleware,
    ToolCallLimitMiddleware,
)
from langchain.messages import AIMessage, ToolMessage
from langchain.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command
from .config import OPENAI_API_KEY

ORDERS = {
    "ORD-100": {
        "amount": 129.00,
        "status": "delivered",
    }
}


@tool
def lookup_order(order_id: str) -> dict[str, Any]:
    """Return order information needed for support actions."""
    order = ORDERS.get(order_id)
    if order is None:
        return {"found": False, "order_id": order_id}
    return {"found": True, "order_id": order_id, **order}


@tool
def issue_store_credit(order_id: str, amount: float, reason: str) -> str:
    """Issue store credit for a customer order."""
    return f"Store credit of {amount:.2f} issued for {order_id}. Reason: {reason}"


primary_model = ChatOpenAI(
    model="gpt-4.1",
    api_key=OPENAI_API_KEY,
    temperature=0,
)

fallback_model = ChatOpenAI(
    model="gpt-4.1-mini",
    api_key=OPENAI_API_KEY,
    temperature=0,
)

agent = create_agent(
    model=primary_model,
    tools=[lookup_order, issue_store_credit],
    system_prompt=(
        "You are a customer support assistant. "
        "Always look up the order before taking any action. "
        "If the user explicitly asks for store credit and the order exists, "
        "use the issue_store_credit tool instead of only describing the action. "
        "After the action is completed, explain clearly what happened."
    ),
    middleware=[
        PIIMiddleware("email", strategy="redact", apply_to_input=True),
        PIIMiddleware("credit_card", strategy="mask", apply_to_input=True),
        SummarizationMiddleware(
            model=fallback_model,
            trigger=("messages", 6),
            keep=("messages", 4),
        ),
        ModelFallbackMiddleware(fallback_model),
        ModelCallLimitMiddleware(
            thread_limit=20,
            run_limit=6,
            exit_behavior="end",
        ),
        ToolCallLimitMiddleware(
            thread_limit=10,
            run_limit=4,
        ),
        ToolCallLimitMiddleware(
            tool_name="issue_store_credit",
            thread_limit=1,
            run_limit=1,
        ),
        HumanInTheLoopMiddleware(
            interrupt_on={
                "issue_store_credit": {
                    "allowed_decisions": ["approve", "edit", "reject"],
                },
                "lookup_order": False,
            },
        ),
    ],
    checkpointer=InMemorySaver(),
    name="support_store_credit_agent",
)


def print_trace(result: dict[str, Any]) -> None:
    messages = result["messages"]

    print("\nTRACE\n")
    visible_step = 1

    for message in messages:
        if isinstance(message, AIMessage):
            printed_anything = False

            if message.content:
                print(f"--- step {visible_step}: assistant ---")
                print(f"[assistant] {message.content}")
                printed_anything = True

            tool_calls = getattr(message, "tool_calls", None) or []
            for tool_call in tool_calls:
                if not printed_anything:
                    print(f"--- step {visible_step}: assistant ---")
                    printed_anything = True
                print(
                    f"[assistant -> tool] "
                    f"{tool_call['name']}({tool_call['args']})"
                )

            if printed_anything:
                visible_step += 1

        elif isinstance(message, ToolMessage):
            print(f"--- step {visible_step}: tool ---")
            print(f"[tool:{message.name}] {message.content}")
            visible_step += 1

    print("\nFINAL\n")
    if messages:
        print(messages[-1].content)
    print("message_count =", len(messages))


def _get_interrupts(state: Any) -> list[Any]:
    if state is None:
        return []

    if isinstance(state, dict):
        return state.get("interrupts", []) or []

    interrupts = getattr(state, "interrupts", None)
    if interrupts is not None:
        return interrupts

    values = getattr(state, "values", None)
    if isinstance(values, dict):
        return values.get("interrupts", []) or []

    return []


def _get_result_values(result: Any) -> dict[str, Any]:
    if result is None:
        return {}

    if isinstance(result, dict):
        if "values" in result and isinstance(result["values"], dict):
            return result["values"]
        return result

    value = getattr(result, "value", None)
    if isinstance(value, dict):
        return value

    values = getattr(result, "values", None)
    if isinstance(values, dict):
        return values

    return {}


def main() -> None:
    config = {
        "configurable": {
            "thread_id": f"refund-thread-{uuid.uuid4()}",
        }
    }

    # Warm-up turns so the thread has enough history for summarization.
    for user_message in [
        "My order arrived last week.",
        "The item is still sealed.",
        "I would prefer store credit instead of a replacement.",
    ]:
        agent.invoke(
            {
                "messages": [
                    {
                        "role": "user",
                        "content": user_message,
                    }
                ]
            },
            config=config,
            version="v2",
        )

    inputs = {
        "messages": [
            {
                "role": "user",
                "content": (
                    "My email is alex@example.com and my card is 4111 1111 1111 1111. "
                    "Please issue store credit for order ORD-100."
                ),
            }
        ]
    }

    # Start the run. If HITL pauses correctly, the pending interrupt will be
    # stored in the thread state.
    agent.invoke(
        inputs,
        config=config,
        version="v2",
    )

    state = agent.get_state(config)
    interrupts = _get_interrupts(state)

    print("INTERRUPTS\n")
    if not interrupts:
        print("No pending interrupts.")
        return

    for idx, interrupt in enumerate(interrupts, start=1):
        print(f"--- interrupt {idx} ---")
        print(interrupt)
        print()

    # Approve the paused action and resume the same thread.
    approved = agent.invoke(
        Command(resume={"decisions": [{"type": "approve"}]}),
        config=config,
        version="v2",
    )

    print_trace(_get_result_values(approved))


if __name__ == "__main__":
    main()