from langchain.tools import tool

@tool
def add(a: int, b: int) -> int:
    """Add two integers."""
    return a + b

@tool
def multiply(a: int, b: int) -> int:
    """Multiply two integers."""
    return a * b

@tool
def divide(a: int, b: int) -> float:
    """Divide a by b."""
    return a / b

print(add.invoke({"a": 3, "b": 4}))
print(multiply.invoke({"a": 6, "b": 7}))
print(divide.invoke({"a": 22, "b": 7}))


