from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field
from langchain.agents import create_agent
from langchain.tools import tool

from .config import OPENAI_API_KEY


ORDERS = {
    "ORD-100": {
        "days_since_delivery": 12,
        "opened": False,
        "amount": 129.00,
        "status": "delivered",
    },
    "ORD-101": {
        "days_since_delivery": 41,
        "opened": True,
        "amount": 79.00,
        "status": "delivered",
    },
}

REFUND_POLICY = {
    "max_days": 30,
    "opened_items_allowed": False,
}


class RefundDecision(BaseModel):
    order_id: str = Field(description="Order identifier")
    eligible: bool = Field(description="Whether the order is refundable")
    reason: str = Field(description="Short business explanation")


@tool
def lookup_order(order_id: str) -> dict[str, Any]:
    """Return order facts needed for a refund decision."""
    order = ORDERS.get(order_id)
    if order is None:
        return {"found": False, "order_id": order_id}
    return {"found": True, "order_id": order_id, **order}


@tool
def evaluate_refund(
    days_since_delivery: int,
    opened: bool,
    max_days: int,
    opened_items_allowed: bool,
    order_id: str,
) -> dict[str, Any]:
    """Evaluate refund eligibility from order facts and policy facts."""
    eligible = (
        days_since_delivery <= max_days
        and (opened_items_allowed or not opened)
    )

    if eligible:
        reason = "The order is within the refund window and meets the item-condition rule."
    elif days_since_delivery > max_days:
        reason = "The order is outside the refund window."
    else:
        reason = "Opened items are not eligible under the standard policy."

    return {
        "order_id": order_id,
        "eligible": eligible,
        "reason": reason,
    }


agent = create_agent(
    model="openai:gpt-5",
    tools=[lookup_order, evaluate_refund],
    response_format=RefundDecision,
    system_prompt=(
        "You are a refund decision assistant. "
        "Always look up the order first. "
        "Then evaluate refund eligibility using this policy: "
        f"max_days={REFUND_POLICY['max_days']}, "
        f"opened_items_allowed={REFUND_POLICY['opened_items_allowed']}. "
        "Return the final answer only as structured output."
    ),
)


def main() -> None:
    result = agent.invoke(
        {
            "messages": [
                {
                    "role": "user",
                    "content": "Decide whether ORD-100 is refundable.",
                }
            ]
        }
    )

    structured = result["structured_response"]

    print("STRUCTURED RESPONSE")
    print(structured)
    print()

    print("AS DICT")
    print(structured.model_dump())


if __name__ == "__main__":
    main()