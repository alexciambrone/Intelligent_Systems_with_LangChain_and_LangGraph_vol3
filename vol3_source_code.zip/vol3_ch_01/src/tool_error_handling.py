from __future__ import annotations

import json
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator

from langchain.agents import create_agent
from langchain.agents.middleware import (
    HumanInTheLoopMiddleware,
    ToolRetryMiddleware,
    wrap_tool_call,
)
from langchain.messages import AIMessage, ToolMessage
from langchain.tools import tool
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command
from .config import OPENAI_API_KEY


# ---------------------------------------------------------------------
# Fake broker and market state used by the tools
# ---------------------------------------------------------------------

PRICE_FEED = {
    "AAPL": 192.35,
    "MSFT": 412.20,
    "NVDA": 118.80,
}

ACCOUNT = {
    "account_id": "acct-001",
    "buying_power": 2500.00,
    "trading_enabled": True,
}

MARKET_STATE = {
    "is_open": False,  # Set to True to allow successful placement
}

QUOTE_ATTEMPTS: dict[str, int] = {}


# ---------------------------------------------------------------------
# Business exceptions used for classification
# ---------------------------------------------------------------------

class CorrectableTradeInputError(Exception):
    """The request is understandable, but the user can correct it."""


class TradeBlockedError(Exception):
    """The request is valid, but current business conditions block execution."""


# ---------------------------------------------------------------------
# Tool schemas
# ---------------------------------------------------------------------

class Side(str, Enum):
    BUY = "buy"
    SELL = "sell"


class OrderType(str, Enum):
    MARKET = "market"
    LIMIT = "limit"


class QuoteInput(BaseModel):
    symbol: str = Field(
        ...,
        description="Ticker symbol in uppercase, for example AAPL or MSFT.",
    )

    @field_validator("symbol")
    @classmethod
    def normalize_symbol(cls, value: str) -> str:
        value = value.strip().upper()
        if not value.isalpha():
            raise ValueError("symbol must contain only letters")
        return value


class PlaceOrderInput(BaseModel):
    symbol: str = Field(
        ...,
        description="Ticker symbol in uppercase, for example AAPL or MSFT.",
    )
    side: Side = Field(
        ...,
        description="Whether to buy or sell.",
    )
    quantity: int = Field(
        ...,
        gt=0,
        description="Number of shares to trade. Must be greater than zero.",
    )
    order_type: OrderType = Field(
        default=OrderType.MARKET,
        description="Use market for immediate execution or limit with a limit price.",
    )
    limit_price: float | None = Field(
        default=None,
        gt=0,
        description="Required only for limit orders.",
    )

    @field_validator("symbol")
    @classmethod
    def normalize_symbol(cls, value: str) -> str:
        value = value.strip().upper()
        if not value.isalpha():
            raise ValueError("symbol must contain only letters")
        return value

    @model_validator(mode="after")
    def validate_price_rules(self) -> "PlaceOrderInput":
        if self.order_type == OrderType.LIMIT and self.limit_price is None:
            raise ValueError("limit_price is required for limit orders")
        if self.order_type == OrderType.MARKET and self.limit_price is not None:
            raise ValueError("limit_price is only valid for limit orders")
        return self


# ---------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------

@tool(args_schema=QuoteInput)
def get_realtime_quote(symbol: str) -> str:
    """Return the latest market price for a symbol."""

    attempts = QUOTE_ATTEMPTS.get(symbol, 0) + 1
    QUOTE_ATTEMPTS[symbol] = attempts

    # Diagnostic line so retries are visible in the console output.
    print(f"[tool:get_realtime_quote] attempt={attempts} symbol={symbol}")

    # Simulate a transient infrastructure failure that succeeds on retry.
    if symbol == "AAPL" and attempts < 3:
        raise TimeoutError("quote service timed out")

    # This is not a transient fault. The user or model must correct the request.
    if symbol not in PRICE_FEED:
        raise CorrectableTradeInputError(f"Unknown symbol '{symbol}'")

    return json.dumps(
        {
            "symbol": symbol,
            "price": PRICE_FEED[symbol],
            "currency": "USD",
            "source": "simulated-feed",
        }
    )


@tool(args_schema=PlaceOrderInput)
def place_order(
    symbol: str,
    side: Side,
    quantity: int,
    order_type: OrderType = OrderType.MARKET,
    limit_price: float | None = None,
) -> str:
    """Place a stock order through the broker."""

    print(
        "[tool:place_order] "
        f"symbol={symbol} side={side.value} quantity={quantity} "
        f"order_type={order_type.value} limit_price={limit_price}"
    )

    if symbol not in PRICE_FEED:
        raise CorrectableTradeInputError(f"Unknown symbol '{symbol}'")

    if not ACCOUNT["trading_enabled"]:
        raise TradeBlockedError("Trading is not enabled for this account.")

    if not MARKET_STATE["is_open"]:
        raise TradeBlockedError("Market is currently closed.")

    reference_price = (
        PRICE_FEED[symbol] if limit_price is None else float(limit_price)
    )
    estimated_notional = reference_price * quantity

    if side == Side.BUY and estimated_notional > ACCOUNT["buying_power"]:
        raise TradeBlockedError("Insufficient buying power for this order.")

    order_id = f"ord-{symbol.lower()}-{quantity}-{side.value}"

    return json.dumps(
        {
            "status": "accepted",
            "order_id": order_id,
            "symbol": symbol,
            "side": side.value,
            "quantity": quantity,
            "order_type": order_type.value,
            "limit_price": limit_price,
        }
    )


# ---------------------------------------------------------------------
# Middleware that classifies non-transient tool failures
# ---------------------------------------------------------------------

@wrap_tool_call
def classify_tool_errors(request, handler):
    try:
        return handler(request)

    except CorrectableTradeInputError as e:
        return ToolMessage(
            content=(
                f"Correctable trading input problem: {e}. "
                "Ask for corrected order details or choose a different symbol."
            ),
            tool_call_id=request.tool_call["id"],
        )

    except TradeBlockedError as e:
        return ToolMessage(
            content=(
                f"Trading request blocked: {e}. "
                "Do not retry automatically. Explain the condition to the user."
            ),
            tool_call_id=request.tool_call["id"],
        )

    # Any other exception is treated as an unexpected system problem
    # and is allowed to bubble up.


# ---------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------

agent = create_agent(
    model="openai:gpt-4.1-mini",
    tools=[get_realtime_quote, place_order],
    system_prompt=(
        "You are a trading assistant. "
        "Use get_realtime_quote for price lookup. "
        "Use place_order only when the user explicitly asks to trade. "
        "Never retry place_order automatically. "
        "If a tool returns a correctable input problem, ask for a correction. "
        "If a tool returns a blocked-trade message, explain the reason and stop."
    ),
    middleware=[
        classify_tool_errors,
        ToolRetryMiddleware(
            tools=["get_realtime_quote"],
            retry_on=(TimeoutError, ConnectionError),
            max_retries=3,
            initial_delay=0.5,
            backoff_factor=2.0,
        ),
        HumanInTheLoopMiddleware(
            interrupt_on={
                "place_order": {
                    "allowed_decisions": ["approve", "edit", "reject"],
                },
                "get_realtime_quote": False,
            }
        ),
    ],
    checkpointer=InMemorySaver(),
)


# ---------------------------------------------------------------------
# Pretty trace helpers
# ---------------------------------------------------------------------

def _json_default(value: Any) -> str:
    return str(value)


def _compact_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, default=_json_default)


def _short(text: str, limit: int = 240) -> str:
    text = " ".join(text.split())
    return text if len(text) <= limit else text[: limit - 3] + "..."


def _content_to_text(content: Any) -> str:
    if content is None:
        return ""

    if isinstance(content, str):
        return content

    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                if "text" in item:
                    parts.append(str(item["text"]))
                else:
                    parts.append(_compact_json(item))
            else:
                parts.append(str(item))
        return " ".join(part for part in parts if part)

    if isinstance(content, dict):
        return _compact_json(content)

    return str(content)


def _extract_tool_calls(msg: AIMessage) -> list[dict[str, Any]]:
    calls = getattr(msg, "tool_calls", None)
    if calls:
        return calls
    return []


def _print_ai_message(msg: AIMessage) -> None:
    tool_calls = _extract_tool_calls(msg)

    if tool_calls:
        for call in tool_calls:
            name = call.get("name", "<unknown>")
            args = call.get("args", {})
            print(f"[model] tool call -> {name}({ _compact_json(args) })")
        return

    text = _short(_content_to_text(msg.content))
    if text:
        print(f"[model] final answer -> {text}")
    else:
        print("[model] final answer -> <empty>")


def _print_tool_message(msg: ToolMessage) -> None:
    text = _short(_content_to_text(msg.content))
    tool_name = getattr(msg, "name", None)
    if tool_name:
        print(f"[tools:{tool_name}] result -> {text}")
    else:
        print(f"[tools] result -> {text}")


def _print_interrupts(interrupts: Any) -> None:
    if not isinstance(interrupts, (list, tuple)):
        interrupts = [interrupts]

    print("[interrupt] approval required")

    for interrupt in interrupts:
        value = getattr(interrupt, "value", interrupt)

        if isinstance(value, dict):
            action_requests = value.get("action_requests", [])
            review_configs = value.get("review_configs", [])

            for i, req in enumerate(action_requests, start=1):
                tool_name = req.get("action", req.get("tool", "<unknown>"))
                args = req.get("args", {})
                description = req.get("description")
                print(f"  request {i}: {tool_name}({ _compact_json(args) })")
                if description:
                    print(f"    description: {description}")

            for i, cfg in enumerate(review_configs, start=1):
                allowed = cfg.get("allowed_decisions")
                if allowed:
                    print(f"  review {i}: allowed_decisions={allowed}")
        else:
            print(f"  {_short(str(value))}")


def _print_update(source: str, update: Any) -> None:
    if source == "__interrupt__":
        _print_interrupts(update)
        return

    if not isinstance(update, dict):
        print(f"[{source}] {_short(str(update))}")
        return

    messages = update.get("messages")
    if messages:
        for msg in messages:
            if isinstance(msg, AIMessage):
                _print_ai_message(msg)
            elif isinstance(msg, ToolMessage):
                _print_tool_message(msg)
            else:
                content = _short(_content_to_text(getattr(msg, "content", msg)))
                print(f"[{source}] {content}")
        return

    print(f"[{source}] {_short(_compact_json(update))}")


def trace_run(title: str, payload: Any, config: dict[str, Any]) -> None:
    print()
    print("=" * 78)
    print(title)
    print("=" * 78)

    step = 0
    for chunk in agent.stream(payload, config=config, stream_mode="updates"):
        step += 1
        print(f"\n--- step {step} ---")
        for source, update in chunk.items():
            _print_update(source, update)


# ---------------------------------------------------------------------
# Demo
# ---------------------------------------------------------------------

if __name__ == "__main__":
    quote_config = {"configurable": {"thread_id": "quote-thread"}}
    trade_config = {"configurable": {"thread_id": "trade-thread"}}

    # Reset quote attempts so the retry behavior is easy to observe every run.
    QUOTE_ATTEMPTS.clear()

    # 1) Read-oriented tool with transient failure: retried automatically
    trace_run(
        "1) Quote lookup with retry",
        {
            "messages": [
                {
                    "role": "user",
                    "content": "What is the latest price for AAPL?",
                }
            ]
        },
        quote_config,
    )

    # 2) High-stakes mutating tool: paused for approval before execution
    trace_run(
        "2) Trade request before approval",
        {
            "messages": [
                {
                    "role": "user",
                    "content": "Place a market order to buy 20 shares of AAPL.",
                }
            ]
        },
        trade_config,
    )

    # 3) Resume after approval. With MARKET_STATE['is_open'] = False,
    # the tool executes and returns a blocked-trade message.
    trace_run(
        "3) Resume after approval",
        Command(resume={"decisions": [{"type": "approve"}]}),
        trade_config,
    )