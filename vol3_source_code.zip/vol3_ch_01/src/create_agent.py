from typing import Any
from langchain.agents import create_agent
from langchain.tools import tool
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from .config import OPENAI_API_KEY

ORDERS = {
    "ORD-100": {
        "days_since_delivery": 12,
        "opened": False,
        "amount": 129.00,
        "status": "delivered",
    },
    "ORD-101": {
        "days_since_delivery": 41,
        "opened": True,
        "amount": 79.00,
        "status": "delivered",
    },
}

REFUND_POLICY = {
    "max_days": 30,
    "opened_items_allowed": False,
    "return_shipping_paid_by_customer": True,
}


@tool
def lookup_order(order_id: str) -> dict[str, Any]:
    """Return the order facts needed for a refund decision."""
    order = ORDERS.get(order_id)
    if order is None:
        return {"found": False, "order_id": order_id}
    return {"found": True, "order_id": order_id, **order}


@tool
def get_refund_policy() -> dict[str, Any]:
    """Return the store's standard refund policy."""
    return REFUND_POLICY


@tool
def evaluate_refund(
    days_since_delivery: int,
    opened: bool,
    max_days: int,
    opened_items_allowed: bool,
) -> dict[str, Any]:
    """Evaluate refund eligibility from order facts and policy facts."""
    eligible = (
        days_since_delivery <= max_days
        and (opened_items_allowed or not opened)
    )

    if eligible:
        reason = "The order is within the refund window and meets the item-condition rule."
    elif days_since_delivery > max_days:
        reason = "The order is outside the refund window."
    else:
        reason = "Opened items are not eligible under the standard policy."

    return {
        "eligible": eligible,
        "reason": reason,
    }


agent = create_agent(
    model="openai:gpt-5",
    tools=[lookup_order, get_refund_policy, evaluate_refund],
    system_prompt=(
        "You are a customer support assistant for an online store. "
        "When a user asks about refund eligibility, first gather the order facts, "
        "then retrieve the refund policy, then evaluate eligibility, and finally "
        "answer in plain language. If the order is not eligible, explain why clearly. "
        "If the order is eligible, explain the next step."
    ),
    name="support_refund_agent",
)

result = agent.invoke(
    {
        "messages": [
            {
                "role": "user",
                "content": "Can order ORD-100 be refunded? Please explain the reason.",
            }
        ]
    }
)

print("FINAL ANSWER")
print(result["messages"][-1].content)
print()

print("MESSAGE TRACE")
for message in result["messages"]:
    if isinstance(message, HumanMessage):
        print(f"USER: {message.content}")
    elif isinstance(message, AIMessage) and message.tool_calls:
        print("ASSISTANT REQUESTED TOOLS:")
        for call in message.tool_calls:
            print(f"  - {call['name']}({call['args']})")
    elif isinstance(message, ToolMessage):
        print(f"TOOL RESULT [{message.name}]: {message.content}")
    elif isinstance(message, AIMessage):
        print(f"ASSISTANT: {message.content}")


