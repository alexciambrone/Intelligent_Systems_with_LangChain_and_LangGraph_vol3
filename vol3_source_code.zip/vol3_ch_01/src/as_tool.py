from typing_extensions import TypedDict
from langchain_core.runnables import RunnableLambda

class ReturnCheckInput(TypedDict):
    days_since_delivery: int
    item_opened: bool
    damaged: bool

def normalize(data: ReturnCheckInput) -> ReturnCheckInput:
    return {
        "days_since_delivery": int(data["days_since_delivery"]),
        "item_opened": bool(data["item_opened"]),
        "damaged": bool(data["damaged"]),
    }

def evaluate(data: ReturnCheckInput) -> dict:
    eligible = (
        data["damaged"]
        or (data["days_since_delivery"] <= 30 and not data["item_opened"])
    )
    return {
        "eligible": eligible,
        "reason": (
            "damaged item"
            if data["damaged"]
            else "within 30 days and unopened"
            if eligible
            else "outside standard policy"
        ),
    }

return_policy_pipeline = RunnableLambda(normalize) | RunnableLambda(evaluate)

return_policy_tool = return_policy_pipeline.as_tool(
    name="evaluate_return_policy",
    description="Evaluate whether a return appears eligible under the standard policy.",
    arg_types={
        "days_since_delivery": int,
        "item_opened": bool,
        "damaged": bool,
    },
)

if __name__ == "__main__":
    result = return_policy_tool.invoke(
        {"days_since_delivery": 12, "item_opened": False, "damaged": False}
    )
    print(result)