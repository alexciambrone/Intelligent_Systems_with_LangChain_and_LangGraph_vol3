from langchain_community.agent_toolkits.openapi.toolkit import RequestsToolkit
from langchain_community.utilities.requests import TextRequestsWrapper

toolkit = RequestsToolkit(
    requests_wrapper=TextRequestsWrapper(headers={}),
    allow_dangerous_requests=True,
)

tools = {tool.name: tool for tool in toolkit.get_tools()}

response = tools["requests_get"].invoke(
    {"url": "https://jsonplaceholder.typicode.com/posts?_limit=2"}
)

print(response)


