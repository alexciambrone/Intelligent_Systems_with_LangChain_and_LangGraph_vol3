from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Callable

from langchain.agents import create_agent
from langchain.agents.middleware import (
    ModelRequest,
    ModelResponse,
    dynamic_prompt,
    wrap_model_call,
)
from langchain_openai import ChatOpenAI

from .config import OPENAI_API_KEY
from .react_langgraph import lookup_order, evaluate_refund_policy

basic_model = ChatOpenAI(model="gpt-4.1-mini", temperature=0)
advanced_model = ChatOpenAI(model="gpt-4.1", temperature=0)


@dataclass
class Context:
    user_role: str


@wrap_model_call
def select_model(request: ModelRequest, handler):
    message_count = len(request.state["messages"])
    chosen = advanced_model if message_count >= 4 else basic_model
    print(f"[middleware:model] message_count={message_count} -> {chosen.model_name}")
    return handler(request.override(model=chosen))

@dynamic_prompt
def role_prompt(request: ModelRequest) -> str:
    base = (
        "You are a customer support assistant. "
        "Before any tool call, write one short visible sentence explaining the next step. "
        "Do not expose hidden reasoning. Use concise action summaries only. "
    )

    message_count = len(request.state["messages"])

    if message_count >= 4:
        prompt = base + "Now synthesize the final answer using the tool results only."
    else:
        prompt = base + "First decide which tool to call next."

    print("\n[middleware:prompt] effective prompt:")
    print(prompt)
    print()
    return prompt

agent = create_agent(
    model=basic_model,
    tools=[lookup_order, evaluate_refund_policy],
    middleware=[select_model, role_prompt],
    context_schema=Context,
)


def print_trace(user_text: str, role: str = "expert") -> None:
    print("\nTRACE\n")

    step = 0
    final_answer = None

    for chunk in agent.stream(
        {
            "messages": [
                {
                    "role": "user",
                    "content": user_text,
                }
            ]
        },
        context=Context(user_role=role),
        stream_mode="updates",
    ):
        for node_name, update in chunk.items():
            step += 1
            print(f"--- step {step}: {node_name} ---")

            messages = update.get("messages", [])
            if not messages:
                print(update)
                print()
                continue

            for msg in messages:
                tool_calls = getattr(msg, "tool_calls", None)

                if tool_calls:
                    text = getattr(msg, "content", "")
                    if text:
                        print(f"[assistant] {text}")

                    for tc in tool_calls:
                        print(f"[assistant -> tool] {tc['name']}({tc['args']})")

                else:
                    content = getattr(msg, "content", "")
                    name = msg.__class__.__name__

                    if name == "ToolMessage":
                        print(f"[tool] {content}")
                    else:
                        print(f"[assistant] {content}")
                        final_answer = content

            print()

    print("FINAL ANSWER\n")
    print(final_answer or "<no final answer captured>")


if __name__ == "__main__":
    print_trace(
        "Explain the refund decision for ORD-100. First check the order, then evaluate refund eligibility.",
        role="expert",
    )