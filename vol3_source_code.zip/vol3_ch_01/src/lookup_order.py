from __future__ import annotations
import json
from langchain.tools import tool

ORDERS = {
    "ORD-100": {
        "status": "delivered",
        "amount": 129.00,
        "currency": "EUR",
        "refundable": True,
    }
}

@tool
def lookup_order_simple(order_id: str, include_history: bool = False) -> dict:
    """Return normalized order status data for a single order."""
    order = ORDERS[order_id]
    return {
        "order_id": order_id,
        "status": order["status"],
        "amount": order["amount"],
        "currency": order["currency"],
        "refundable": order["refundable"],
        "include_history": include_history,
    }

if __name__ == "__main__":
    schema = lookup_order_simple.args_schema.model_json_schema()
    print("=== INFERRED SCHEMA ===")
    print(json.dumps(schema, indent=2))
    print()
    print("=== TOOL RESULT ===")
    print(lookup_order_simple.invoke({
        "order_id": "ORD-100",
        "include_history": True,
    }))
