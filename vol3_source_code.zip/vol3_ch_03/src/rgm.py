import os
from urllib.parse import quote_plus

from sqlalchemy import create_engine, text

from langchain.chat_models import init_chat_model
from langchain_community.agent_toolkits.sql.base import create_sql_agent
from langchain_community.agent_toolkits.sql.toolkit import SQLDatabaseToolkit
from langchain_community.utilities import SQLDatabase
from .config import OPENAI_API_KEY


# -----------------------------------------------------------------------------
# SQL Server connection
# -----------------------------------------------------------------------------
SQL_SERVER_HOST = r"192.168.11.4\PRODUZIONE"
SQL_SERVER_DATABASE = "PISW30_1"
SQL_SERVER_USERNAME = "sa"
SQL_SERVER_PASSWORD = "saadm-01"
SQL_SERVER_DRIVER = "ODBC Driver 18 for SQL Server"

odbc_str = (
    f"DRIVER={{{SQL_SERVER_DRIVER}}};"
    f"SERVER={SQL_SERVER_HOST};"
    f"DATABASE={SQL_SERVER_DATABASE};"
    f"UID={SQL_SERVER_USERNAME};"
    f"PWD={SQL_SERVER_PASSWORD};"
    "Encrypt=yes;"
    "TrustServerCertificate=yes;"
)

connection_url = f"mssql+pyodbc:///?odbc_connect={quote_plus(odbc_str)}"

engine = create_engine(
    connection_url,
    pool_pre_ping=True,
)

with engine.connect() as conn:
    row = conn.execute(text("SELECT DB_NAME() AS db_name")).mappings().first()
    print(f"Connected to database: {row['db_name']}")


# -----------------------------------------------------------------------------
# LangChain SQLDatabase
# -----------------------------------------------------------------------------
INCLUDE_TABLES = [
    "BA_TABREC_ITEM_",
    "WORK_ORDER",
    "WORK_ORDER_DETAIL_COMPONENT",
    "WORK_ORDER_DETAIL_OPERATION",
    "WORK_ORDER_DETAIL_OPERATION_WARNING",
    "_TABPOFU_DETAIL_WORK_ORDER",
]

db = SQLDatabase(
    engine=engine,
    include_tables=INCLUDE_TABLES,
    sample_rows_in_table_info=2,
    view_support=False,
    lazy_table_reflection=True,
)


# -----------------------------------------------------------------------------
# Model
# -----------------------------------------------------------------------------
model = init_chat_model("openai:gpt-4.1-mini", temperature=0)


# -----------------------------------------------------------------------------
# SQL agent
# -----------------------------------------------------------------------------
toolkit = SQLDatabaseToolkit(db=db, llm=model)

system_prompt = f"""
You are an agent designed to interact with a Microsoft SQL Server database.

Your task is to answer the user's question by querying the database.

Rules:
1. Always inspect the available tables first.
2. Then inspect the schema of the relevant tables.
3. Write a syntactically correct {db.dialect} query.
4. Always double-check the SQL before executing it.
5. Never make up table names or column names.
6. Unless the user explicitly asks for many rows, limit results to at most 20.
7. Never execute INSERT, UPDATE, DELETE, DROP, ALTER, TRUNCATE, MERGE, CREATE, or GRANT.
8. Return only the dataset produced by the query.
9. Do not show the SQL query.
10. Do not include reasoning or explanations.
11. If no rows are returned, output exactly: No data found.

Important SQL Server rules:
- Use TOP (n), not LIMIT.
- Be careful with NULL values.
- Be careful with joins.

Domain hints:
- The user may ask questions in Italian.
- "spedibili" means shippable / eligible for shipment.
- "RIR" is a business term used by the user. Infer its meaning from table names and columns if possible.
- Prefer WORK_ORDER, WORK_ORDER_DETAIL_COMPONENT, WORK_ORDER_DETAIL_OPERATION,
  WORK_ORDER_DETAIL_OPERATION_WARNING, _TABPOFU_DETAIL_WORK_ORDER, and BA_TABREC_ITEM_.
- Start from the most relevant tables and avoid unnecessary loops.
- If the meaning of a business term cannot be grounded in schema/columns, say:
  "Non riesco a determinare il significato esatto del termine dal database."
"""

agent = create_sql_agent(
    llm=model,
    toolkit=toolkit,
    verbose=True,
    top_k=20,
    max_iterations=8,
    max_execution_time=60,
    agent_executor_kwargs={
        "handle_parsing_errors": True,
        "return_intermediate_steps": False,
    },
    prefix=system_prompt,
)


# -----------------------------------------------------------------------------
# Interactive chat
# -----------------------------------------------------------------------------
def chat() -> None:
    print("\nInteractive SQL chat started.")
    print("Ask a question about the database.")
    print("Type 'exit', 'quit', or 'q' to stop.\n")

    while True:
        user_input = input("You> ").strip()

        if not user_input:
            continue

        if user_input.lower() in {"exit", "quit", "q"}:
            print("Goodbye.")
            break

        try:
            result = agent.invoke({"input": user_input})
            print(f"\nData>\n{result['output']}\n")
        except KeyboardInterrupt:
            print("\nInterrupted.")
            break
        except Exception as exc:
            print(f"\nError>\n{exc}\n")


if __name__ == "__main__":
    chat()