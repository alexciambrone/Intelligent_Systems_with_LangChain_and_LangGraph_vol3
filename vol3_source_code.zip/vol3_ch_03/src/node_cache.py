from __future__ import annotations

import re
import time
from typing_extensions import TypedDict

from langgraph.graph import START, StateGraph
from langgraph.cache.memory import InMemoryCache
from langgraph.types import CachePolicy

class SearchState(TypedDict, total=False):
    question: str
    normalized_query: str
    filters: dict

def normalize_query(state: SearchState) -> dict:
    # Simulate expensive work.
    time.sleep(2)
    text = re.sub(r"\s+", " ", state["question"]).strip().lower()
    return {"normalized_query": text}

def build_filters(state: SearchState) -> dict:
    text = state["normalized_query"]
    price_match = re.search(r"under (\d+)", text)
    price_cap = int(price_match.group(1)) if price_match else None

    category = "hiking boots" if "boots" in text else "general"
    waterproof = "waterproof" in text

    return {
        "filters": {
            "category": category,
            "price_cap": price_cap,
            "waterproof": waterproof,
        }
    }

builder = StateGraph(SearchState)

builder.add_node(
    "normalize_query",
    normalize_query,
    cache_policy=CachePolicy(ttl=300),
)
builder.add_node(
    "build_filters",
    build_filters,
    cache_policy=CachePolicy(ttl=300),
)

builder.add_edge(START, "normalize_query")
builder.add_edge("normalize_query", "build_filters")

graph = builder.compile(cache=InMemoryCache())

query = {"question": "Waterproof hiking boots under 150"}
print(graph.invoke(query, stream_mode="updates"))
print(graph.invoke(query, stream_mode="updates"))

