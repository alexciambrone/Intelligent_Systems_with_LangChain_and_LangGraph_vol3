from dataclasses import dataclass
from math import sqrt
from typing_extensions import TypedDict, Literal

from pydantic import BaseModel, Field
from langchain.chat_models import init_chat_model
from langchain.embeddings import init_embeddings
from langgraph.graph import StateGraph, START, END
from langgraph.types import Command
from .config import OPENAI_API_KEY

@dataclass(frozen=True)
class RouteProfile:
    name: str
    description: str


ROUTES = [
    RouteProfile(
        "returns_policy",
        "Questions about returns, refunds, exchanges, or warranty rules.",
    ),
    RouteProfile(
        "order_help",
        "Questions about delivery, tracking, cancellations, or order status.",
    ),
    RouteProfile(
        "product_qa",
        "Questions about product details, compatibility, features, or specifications.",
    ),
    RouteProfile(
        "recommendations",
        "Requests for shopping advice, suggestions, or product recommendations.",
    ),
]

embeddings = init_embeddings("openai:text-embedding-3-small")
route_vectors = embeddings.embed_documents([route.description for route in ROUTES])

arbiter = init_chat_model("openai:gpt-4.1-mini", temperature=0)


class FinalDecision(BaseModel):
    route: Literal[
        "returns_policy",
        "order_help",
        "product_qa",
        "recommendations",
        "clarify",
    ] = Field(description="Final route selected from the shortlist.")


arbiter_llm = arbiter.with_structured_output(FinalDecision)


class HybridRoutingState(TypedDict):
    user_message: str
    user_role: str
    has_order_id: bool
    route: str
    route_reason: str
    shortlist: list[tuple[str, float]]
    response: str


def cosine_similarity(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = sqrt(sum(x * x for x in a))
    norm_b = sqrt(sum(x * x for x in b))
    return dot / (norm_a * norm_b)


def semantic_top_k(query: str, k: int = 2) -> list[tuple[str, float]]:
    query_vector = embeddings.embed_query(query)
    scored = sorted(
        [
            (route.name, cosine_similarity(query_vector, vector))
            for route, vector in zip(ROUTES, route_vectors)
        ],
        key=lambda item: item[1],
        reverse=True,
    )
    return scored[:k]


def hybrid_router(
    state: HybridRoutingState,
) -> Command[
    Literal[
        "returns_policy",
        "order_help",
        "product_qa",
        "recommendations",
        "clarify",
    ]
]:
    text = state["user_message"].lower()
    user_role = state["user_role"]
    has_order_id = state["has_order_id"]

    # 1) Deterministic gates first.
    if user_role == "admin":
        return Command(
            update={
                "route": "clarify",
                "route_reason": "Deterministic gate: admin requests require manual clarification.",
                "shortlist": [],
            },
            goto="clarify",
        )

    if has_order_id and any(token in text for token in ["where is my order", "track", "delivery"]):
        return Command(
            update={
                "route": "order_help",
                "route_reason": "Deterministic gate: order-id present and message is about tracking/delivery.",
                "shortlist": [],
            },
            goto="order_help",
        )

    # 2) Semantic narrowing.
    shortlist = semantic_top_k(state["user_message"], k=2)

    # Strong winner: stop early.
    if len(shortlist) == 1 or (shortlist[0][1] - shortlist[1][1]) >= 0.12:
        chosen = shortlist[0][0]
        return Command(
            update={
                "route": chosen,
                "route_reason": (
                    f"Semantic winner: {chosen} won decisively with margin "
                    f"{shortlist[0][1] - shortlist[1][1]:.4f}."
                    if len(shortlist) > 1
                    else f"Semantic winner: only one shortlist result, chose {chosen}."
                ),
                "shortlist": shortlist,
            },
            goto=chosen,
        )

    # 3) LLM arbitration only for ambiguous cases.
    options = ", ".join(name for name, _ in shortlist)
    decision = arbiter_llm.invoke(
        [
            {
                "role": "system",
                "content": (
                    f"Choose exactly one route from: {options}. "
                    "Prefer the route that best matches the user's main intent. "
                    "Return only the route label."
                ),
            },
            {"role": "user", "content": state["user_message"]},
        ]
    )

    return Command(
        update={
            "route": decision.route,
            "route_reason": f"LLM arbitration: semantic shortlist was ambiguous, final choice from [{options}] was {decision.route}.",
            "shortlist": shortlist,
        },
        goto=decision.route,
    )


def returns_policy(state: HybridRoutingState):
    return {
        "response": (
            f"Routed to '{state['route']}'. "
            f"Reason: {state['route_reason']} "
            "This request belongs in the returns/refunds/exchanges flow."
        )
    }


def order_help(state: HybridRoutingState):
    return {
        "response": (
            f"Routed to '{state['route']}'. "
            f"Reason: {state['route_reason']} "
            "This request belongs in the order tracking, delivery, or cancellation flow."
        )
    }


def product_qa(state: HybridRoutingState):
    return {
        "response": (
            f"Routed to '{state['route']}'. "
            f"Reason: {state['route_reason']} "
            "This request is primarily about product details or compatibility."
        )
    }


def recommendations(state: HybridRoutingState):
    return {
        "response": (
            f"Routed to '{state['route']}'. "
            f"Reason: {state['route_reason']} "
            "This request is best handled as a recommendation or shopping-advice flow."
        )
    }


def clarify(state: HybridRoutingState):
    return {
        "response": (
            f"Routed to '{state['route']}'. "
            f"Reason: {state['route_reason']} "
            "The request should be clarified before proceeding."
        )
    }


builder = StateGraph(HybridRoutingState)

builder.add_node("hybrid_router", hybrid_router)
builder.add_node("returns_policy", returns_policy)
builder.add_node("order_help", order_help)
builder.add_node("product_qa", product_qa)
builder.add_node("recommendations", recommendations)
builder.add_node("clarify", clarify)

builder.add_edge(START, "hybrid_router")
builder.add_edge("returns_policy", END)
builder.add_edge("order_help", END)
builder.add_edge("product_qa", END)
builder.add_edge("recommendations", END)
builder.add_edge("clarify", END)

graph = builder.compile()


if __name__ == "__main__":
    examples = [
        {
            "user_message": "Where is my order ORD-100? The delivery is late.",
            "user_role": "customer",
            "has_order_id": True,
        },
        {
            "user_message": "Can I get a refund for the shoes I bought last week?",
            "user_role": "customer",
            "has_order_id": False,
        },
        {
            "user_message": "Does this monitor work with a MacBook Air?",
            "user_role": "customer",
            "has_order_id": False,
        },
        {
            "user_message": "Can you suggest a good laptop for travel and office work?",
            "user_role": "customer",
            "has_order_id": False,
        },
        {
            "user_message": "Please review this request.",
            "user_role": "admin",
            "has_order_id": False,
        },
    ]

    for example in examples:
        result = graph.invoke(
            {
                "user_message": example["user_message"],
                "user_role": example["user_role"],
                "has_order_id": example["has_order_id"],
                "route": "",
                "route_reason": "",
                "shortlist": [],
                "response": "",
            }
        )

        print("\n=== RUN ===")
        print("User message :", result["user_message"])
        print("User role    :", result["user_role"])
        print("Has order id :", result["has_order_id"])
        print("Chosen route :", result["route"])
        print("Reason       :", result["route_reason"])
        print("Shortlist    :", result["shortlist"])
        print("Response     :", result["response"])