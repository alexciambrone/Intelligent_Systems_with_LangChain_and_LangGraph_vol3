from __future__ import annotations

import os
from langchain.agents import create_agent
from langchain.agents.middleware import (
    wrap_model_call,
    ModelRequest,
    ModelResponse,
)
from langchain.chat_models import init_chat_model
from langchain.tools import tool
from .config import OPENAI_API_KEY
from .config import GOOGLE_API_KEY

CHEAP_MODEL = os.getenv("CHEAP_MODEL", "openai:gpt-5.4-mini")
STRONG_MODEL = os.getenv("STRONG_MODEL", "openai:gpt-5.4")

cheap_model = init_chat_model(CHEAP_MODEL, temperature=0)
strong_model = init_chat_model(STRONG_MODEL, temperature=0)

ORDERS = {
    "ORD-100": {"status": "delivered", "carrier": "DHL"},
    "ORD-101": {"status": "processing", "carrier": "n/a"},
}

POLICY = {
    "refunds": (
        "Refunds are allowed within 30 days for unused items. "
        "Damaged or missing deliveries require manual review."
    )
}

@tool
def lookup_order(order_id: str) -> str:
    """Look up a customer's order by order id."""
    order = ORDERS.get(order_id.upper())
    if not order:
        return "Order not found."
    return f"{order_id.upper()}: status={order['status']}, carrier={order['carrier']}"

@tool
def search_policy(topic: str) -> str:
    """Return a short policy snippet for the requested topic."""
    return POLICY.get(topic.lower(), "No policy found.")

HIGH_RISK_TERMS = {
    "chargeback",
    "fraud",
    "missing delivery",
    "damaged",
    "legal",
    "complaint",
    "refund exception",
}

@wrap_model_call
def choose_model(request: ModelRequest, handler) -> ModelResponse:
    last_user_message = request.state["messages"][-1].content.lower()
    long_conversation = len(request.state["messages"]) > 8
    high_risk = any(term in last_user_message for term in HIGH_RISK_TERMS)

    model = strong_model if (long_conversation or high_risk) else cheap_model
    return handler(request.override(model=model))

agent = create_agent(
    model=cheap_model,
    tools=[lookup_order, search_policy],
    middleware=[choose_model],
    system_prompt=(
        "You are a customer support assistant. "
        "Use tools when needed. Do not invent order facts or policy."
    ),
)

result = agent.invoke(
    {
        "messages": [
            {
                "role": "user",
                "content": "Where is order ORD-100?",
            }
        ]
    }
)

print(result["messages"][-1].content)