from typing_extensions import TypedDict, Literal
from langgraph.graph import StateGraph, START, END
from langgraph.types import Command


class EcommerceState(TypedDict):
    user_message: str
    route: str
    route_history: list[str]
    response: str


def route_request(
    state: EcommerceState,
) -> Command[Literal["product_search", "returns_policy", "order_help", "clarify"]]:
    text = state["user_message"].lower()

    if any(token in text for token in ["recommend", "suggest", "looking for", "best laptop"]):
        chosen = "product_search"
        return Command(
            update={
                "route": chosen,
                "route_history": state["route_history"] + [f"route_request -> {chosen}"],
            },
            goto=chosen,
        )

    if any(token in text for token in ["refund", "return", "exchange"]):
        chosen = "returns_policy"
        return Command(
            update={
                "route": chosen,
                "route_history": state["route_history"] + [f"route_request -> {chosen}"],
            },
            goto=chosen,
        )

    if any(token in text for token in ["where is my order", "track", "delivery", "cancel order"]):
        chosen = "order_help"
        return Command(
            update={
                "route": chosen,
                "route_history": state["route_history"] + [f"route_request -> {chosen}"],
            },
            goto=chosen,
        )

    chosen = "clarify"
    return Command(
        update={
            "route": chosen,
            "route_history": state["route_history"] + [f"route_request -> {chosen}"],
        },
        goto=chosen,
    )


def product_search(state: EcommerceState):
    return {
        "response": (
            f"Routed to '{state['route']}' because the request looks like product discovery. "
            f"Audit trail: {state['route_history']}"
        )
    }


def returns_policy(state: EcommerceState):
    return {
        "response": (
            f"Routed to '{state['route']}' because the request mentions refund/return/exchange. "
            f"Audit trail: {state['route_history']}"
        )
    }


def order_help(state: EcommerceState):
    return {
        "response": (
            f"Routed to '{state['route']}' because the request looks like order tracking or delivery support. "
            f"Audit trail: {state['route_history']}"
        )
    }


def clarify(state: EcommerceState):
    return {
        "response": (
            f"Routed to '{state['route']}' because the intent was ambiguous. "
            f"Audit trail: {state['route_history']}"
        )
    }


builder = StateGraph(EcommerceState)
builder.add_node("route_request", route_request)
builder.add_node("product_search", product_search)
builder.add_node("returns_policy", returns_policy)
builder.add_node("order_help", order_help)
builder.add_node("clarify", clarify)

builder.add_edge(START, "route_request")
builder.add_edge("product_search", END)
builder.add_edge("returns_policy", END)
builder.add_edge("order_help", END)
builder.add_edge("clarify", END)

graph = builder.compile()


if __name__ == "__main__":
    examples = [
        "Can you recommend the best laptop for a student?",
        "I want a refund for the headphones I bought last week.",
        "Where is my order? The delivery is late.",
        "I need help.",
    ]

    for text in examples:
        result = graph.invoke(
            {
                "user_message": text,
                "route": "",
                "route_history": [],
                "response": "",
            }
        )

        print("\n=== RUN ===")
        print("User message :", result["user_message"])
        print("Final route  :", result["route"])
        print("Route history:", result["route_history"])
        print("Response     :", result["response"])