from dataclasses import dataclass
from math import sqrt
from typing_extensions import TypedDict, Literal

from langchain.embeddings import init_embeddings
from langgraph.graph import StateGraph, START, END
from langgraph.types import Command
from .config import OPENAI_API_KEY


@dataclass(frozen=True)
class RouteProfile:
    name: str
    description: str


ROUTES = [
    RouteProfile(
        name="macro_analysis",
        description="Questions about inflation, interest rates, central banks, currencies, or broad market trends.",
    ),
    RouteProfile(
        name="company_research",
        description="Questions about a single company, earnings, fundamentals, guidance, or valuation.",
    ),
    RouteProfile(
        name="screening",
        description="Requests to filter or rank stocks by market cap, sector, factor, dividend yield, or other criteria.",
    ),
    RouteProfile(
        name="portfolio_explanation",
        description="Questions about positions, allocations, diversification, drawdowns, or why a portfolio behaved a certain way.",
    ),
]

# Create the embedding model once.
embeddings = init_embeddings("openai:text-embedding-3-small")

# Precompute route vectors once.
route_vectors = embeddings.embed_documents([route.description for route in ROUTES])


class RoutingState(TypedDict):
    user_message: str
    route: str
    score: float
    ranking: list[tuple[str, float]]
    response: str


def cosine_similarity(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = sqrt(sum(x * x for x in a))
    norm_b = sqrt(sum(x * x for x in b))
    return dot / (norm_a * norm_b)


def semantic_router(
    state: RoutingState,
) -> Command[
    Literal[
        "macro_analysis",
        "company_research",
        "screening",
        "portfolio_explanation",
        "clarify",
    ]
]:
    query = state["user_message"]
    query_vector = embeddings.embed_query(query)

    ranking = sorted(
        [
            (route.name, cosine_similarity(query_vector, vector))
            for route, vector in zip(ROUTES, route_vectors)
        ],
        key=lambda item: item[1],
        reverse=True,
    )

    best_route, best_score = ranking[0]
    min_score = 0.35

    if best_score < min_score:
        chosen = "clarify"
    else:
        chosen = best_route

    return Command(
        update={
            "route": chosen,
            "score": best_score,
            "ranking": ranking,
        },
        goto=chosen,
    )


def macro_analysis(state: RoutingState):
    return {
        "response": (
            f"Routed to '{state['route']}' with score {state['score']:.4f}. "
            "This looks like a macro question about rates, inflation, currencies, or broad markets."
        )
    }


def company_research(state: RoutingState):
    return {
        "response": (
            f"Routed to '{state['route']}' with score {state['score']:.4f}. "
            "This looks like single-company analysis: earnings, valuation, guidance, or fundamentals."
        )
    }


def screening(state: RoutingState):
    return {
        "response": (
            f"Routed to '{state['route']}' with score {state['score']:.4f}. "
            "This looks like a stock filtering or ranking request."
        )
    }


def portfolio_explanation(state: RoutingState):
    return {
        "response": (
            f"Routed to '{state['route']}' with score {state['score']:.4f}. "
            "This looks like a portfolio-behavior or allocation explanation request."
        )
    }


def clarify(state: RoutingState):
    return {
        "response": (
            f"Top score was only {state['score']:.4f}, so the graph routed to 'clarify'. "
            "The request is too ambiguous to classify confidently."
        )
    }


builder = StateGraph(RoutingState)

builder.add_node("semantic_router", semantic_router)
builder.add_node("macro_analysis", macro_analysis)
builder.add_node("company_research", company_research)
builder.add_node("screening", screening)
builder.add_node("portfolio_explanation", portfolio_explanation)
builder.add_node("clarify", clarify)

builder.add_edge(START, "semantic_router")
builder.add_edge("macro_analysis", END)
builder.add_edge("company_research", END)
builder.add_edge("screening", END)
builder.add_edge("portfolio_explanation", END)
builder.add_edge("clarify", END)

graph = builder.compile()


if __name__ == "__main__":
    examples = [
        "How would lower interest rates affect the euro and European equities?",
        "Can you analyze Nvidia's latest earnings and valuation?",
        "Find large-cap healthcare stocks with strong dividend yield.",
        "Why did my portfolio fall more than the market this month?",
        "Hello there",
    ]

    for query in examples:
        result = graph.invoke(
            {
                "user_message": query,
                "route": "",
                "score": 0.0,
                "ranking": [],
                "response": "",
            }
        )

        print("\n=== QUERY ===")
        print(result["user_message"])
        print(f"Chosen route: {result['route']}")
        print(f"Top score   : {result['score']:.4f}")
        print("Top matches :")
        for name, score in result["ranking"]:
            print(f"  - {name:22} {score:.4f}")
        print("Response    :", result["response"])