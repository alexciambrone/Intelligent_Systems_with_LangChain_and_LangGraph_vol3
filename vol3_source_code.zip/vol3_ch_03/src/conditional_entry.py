from typing_extensions import TypedDict, Literal
from langgraph.graph import StateGraph, START, END


class SupportState(TypedDict):
    user_message: str
    is_authenticated: bool
    has_order_id: bool
    response: str


def choose_entry(
    state: SupportState,
) -> Literal["order_help", "policy_help", "clarify"]:
    text = state["user_message"].lower()

    if state["is_authenticated"] and state["has_order_id"]:
        return "order_help"

    if any(token in text for token in ["refund", "return", "exchange", "warranty"]):
        return "policy_help"

    return "clarify"


def order_help(state: SupportState):
    return {"response": "Starting in order_help"}


def policy_help(state: SupportState):
    return {"response": "Starting in policy_help"}


def clarify(state: SupportState):
    return {"response": "Starting in clarify"}


builder = StateGraph(SupportState)
builder.add_node("order_help", order_help)
builder.add_node("policy_help", policy_help)
builder.add_node("clarify", clarify)

# Conditional entry point: the graph starts in different places
# depending on the current state.
builder.add_conditional_edges(START, choose_entry)

builder.add_edge("order_help", END)
builder.add_edge("policy_help", END)
builder.add_edge("clarify", END)

graph = builder.compile()


