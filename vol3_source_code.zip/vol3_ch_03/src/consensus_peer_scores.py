from __future__ import annotations

import operator
from typing import Annotated, Literal

from pydantic import BaseModel, Field
from typing_extensions import TypedDict

from langchain.chat_models import init_chat_model
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import StateGraph, START, END
from langgraph.types import Send

from .config import OPENAI_API_KEY


class DraftResult(BaseModel):
    action: Literal["buy", "hold", "sell"]
    thesis: str
    rationale: str


class ScoreItem(BaseModel):
    target: str
    score: int = Field(ge=1, le=10)
    reason: str


class PeerReviewResult(BaseModel):
    scores: list[ScoreItem]


draft_model = init_chat_model(
    "openai:gpt-4.1-mini",
    temperature=0,
).with_structured_output(DraftResult)

peer_review_model = init_chat_model(
    "openai:gpt-4.1-mini",
    temperature=0,
).with_structured_output(PeerReviewResult)


class DraftRecord(TypedDict):
    analyst: str
    action: str
    thesis: str
    rationale: str


class ScoreRecord(TypedDict):
    reviewer: str
    target: str
    score: int
    reason: str


class TradingState(TypedDict):
    market_brief: str
    drafts: Annotated[list[DraftRecord], operator.add]
    peer_scores: Annotated[list[ScoreRecord], operator.add]
    winning_analyst: str
    final_recommendation: str


class PeerScoringState(TypedDict):
    reviewer: str
    drafts: list[DraftRecord]
    peer_scores: Annotated[list[ScoreRecord], operator.add]


def make_analyst_node(analyst_name: str, lens: str):
    def analyst_node(state: TradingState) -> dict:
        result = draft_model.invoke(
            [
                SystemMessage(
                    content=(
                        "You are a trading analyst. "
                        f"Write one recommendation using this analytical lens: {lens}. "
                        "Return one action: buy, hold, or sell. "
                        "Keep the answer concise and practical."
                    )
                ),
                HumanMessage(content=state["market_brief"]),
            ]
        )

        output = {
            "drafts": [
                {
                    "analyst": analyst_name,
                    "action": result.action,
                    "thesis": result.thesis,
                    "rationale": result.rationale,
                }
            ]
        }

        print(f"[draft] {analyst_name}: {result.action} — {result.thesis}")
        return output

    return analyst_node


def prepare_peer_scoring(state: TradingState) -> dict:
    print("\n--- peer scoring ---")
    return {}


def dispatch_peer_scoring(state: TradingState):
    return [
        Send(
            "peer_score_worker",
            {
                "reviewer": draft["analyst"],
                "drafts": state["drafts"],
            },
        )
        for draft in state["drafts"]
    ]


def peer_score_worker(state: PeerScoringState) -> dict:
    reviewer = state["reviewer"]
    drafts = state["drafts"]

    reviewer_draft = next(d for d in drafts if d["analyst"] == reviewer)
    other_drafts = [d for d in drafts if d["analyst"] != reviewer]
    valid_targets = {d["analyst"] for d in other_drafts}

    other_drafts_text = "\n\n".join(
        [
            (
                f"Analyst: {d['analyst']}\n"
                f"Action: {d['action']}\n"
                f"Thesis: {d['thesis']}\n"
                f"Rationale: {d['rationale']}"
            )
            for d in other_drafts
        ]
    )

    result = peer_review_model.invoke(
        [
            SystemMessage(
                content=(
                    "You are participating in a lightweight consensus workflow. "
                    "Read your own draft and score the other drafts. "
                    "Score each other analyst from 1 to 10. "
                    "Judge them on clarity, evidence, risk awareness, and actionability. "
                    "Do not score yourself."
                )
            ),
            HumanMessage(
                content=(
                    f"Your analyst name: {reviewer}\n\n"
                    f"Your draft:\n"
                    f"Action: {reviewer_draft['action']}\n"
                    f"Thesis: {reviewer_draft['thesis']}\n"
                    f"Rationale: {reviewer_draft['rationale']}\n\n"
                    f"Other drafts to score:\n{other_drafts_text}"
                )
            ),
        ]
    )

    peer_scores: list[ScoreRecord] = []
    for item in result.scores:
        if item.target in valid_targets:
            peer_scores.append(
                {
                    "reviewer": reviewer,
                    "target": item.target,
                    "score": item.score,
                    "reason": item.reason,
                }
            )
            print(f"[score] {reviewer} -> {item.target}: {item.score}/10")

    return {"peer_scores": peer_scores}


def select_final_answer(state: TradingState) -> dict:
    totals = {draft["analyst"]: 0 for draft in state["drafts"]}

    for score in state["peer_scores"]:
        totals[score["target"]] += score["score"]

    print("\n--- totals ---")
    for analyst, total in totals.items():
        print(f"{analyst}: {total}")

    drafts_by_name = {draft["analyst"]: draft for draft in state["drafts"]}
    safety_order = {"sell": 2, "hold": 1, "buy": 0}

    winner = max(
        totals,
        key=lambda analyst: (
            totals[analyst],
            safety_order[drafts_by_name[analyst]["action"]],
        ),
    )

    winning_draft = drafts_by_name[winner]

    print(f"\n[winner] {winner}: {winning_draft['action']} ({totals[winner]})")

    final_text = (
        f"Selected analyst: {winner}\n"
        f"Action: {winning_draft['action']}\n"
        f"Peer score total: {totals[winner]}"
    )

    return {
        "winning_analyst": winner,
        "final_recommendation": final_text,
    }


builder = StateGraph(TradingState)

builder.add_node(
    "macro_analyst",
    make_analyst_node(
        "macro_analyst",
        "macro conditions, rates, inflation, and broad market context",
    ),
)
builder.add_node(
    "fundamentals_analyst",
    make_analyst_node(
        "fundamentals_analyst",
        "revenue, margins, cash flow, balance sheet, and valuation",
    ),
)
builder.add_node(
    "risk_analyst",
    make_analyst_node(
        "risk_analyst",
        "downside scenarios, volatility, uncertainty, and capital preservation",
    ),
)

builder.add_node("prepare_peer_scoring", prepare_peer_scoring)
builder.add_node("peer_score_worker", peer_score_worker)
builder.add_node("select_final_answer", select_final_answer)

builder.add_edge(START, "macro_analyst")
builder.add_edge(START, "fundamentals_analyst")
builder.add_edge(START, "risk_analyst")

builder.add_edge("macro_analyst", "prepare_peer_scoring")
builder.add_edge("fundamentals_analyst", "prepare_peer_scoring")
builder.add_edge("risk_analyst", "prepare_peer_scoring")

builder.add_conditional_edges(
    "prepare_peer_scoring",
    dispatch_peer_scoring,
    ["peer_score_worker"],
)

builder.add_edge("peer_score_worker", "select_final_answer")
builder.add_edge("select_final_answer", END)

graph = builder.compile()

initial_state = {
    "market_brief": (
        "The company posted solid revenue growth, but margin pressure remains. "
        "Interest rates are still elevated, and sector volatility has increased. "
        "Debt is manageable, but guidance was cautious."
    )
}

state = graph.invoke(initial_state)

print("\n=== FINAL RESULT ===")
print(state["final_recommendation"])