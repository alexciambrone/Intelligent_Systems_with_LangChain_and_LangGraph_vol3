from typing_extensions import TypedDict, Literal
from pydantic import BaseModel, Field
from langchain.chat_models import init_chat_model
from langgraph.graph import StateGraph, START, END
from .config import OPENAI_API_KEY


llm = init_chat_model("openai:gpt-4.1-mini", temperature=0)


class RouteDecision(BaseModel):
    route: Literal["product_search", "returns_policy", "order_help", "clarify"] = Field(
        description="Best next step for this e-commerce request."
    )


router_llm = llm.with_structured_output(RouteDecision)


class EcommerceState(TypedDict):
    user_message: str
    route: str
    response: str


def choose_route(state: EcommerceState):
    decision = router_llm.invoke(
        [
            {
                "role": "system",
                "content": (
                    "Route the request to exactly one branch. "
                    "Use product_search for shopping or recommendation requests. "
                    "Use returns_policy for returns, refunds, or exchanges. "
                    "Use order_help for order tracking, cancellation, or delivery issues. "
                    "Use clarify if the request is too ambiguous."
                ),
            },
            {"role": "user", "content": state["user_message"]},
        ]
    )
    return {"route": decision.route}


def next_node(state: EcommerceState) -> str:
    return state["route"]


def product_search(state: EcommerceState):
    return {"response": "Route selected: product_search"}


def returns_policy(state: EcommerceState):
    return {"response": "Route selected: returns_policy"}


def order_help(state: EcommerceState):
    return {"response": "Route selected: order_help"}


def clarify(state: EcommerceState):
    return {"response": "Route selected: clarify"}


builder = StateGraph(EcommerceState)
builder.add_node("choose_route", choose_route)
builder.add_node("product_search", product_search)
builder.add_node("returns_policy", returns_policy)
builder.add_node("order_help", order_help)
builder.add_node("clarify", clarify)

builder.add_edge(START, "choose_route")
builder.add_conditional_edges(
    "choose_route",
    next_node,
    {
        "product_search": "product_search",
        "returns_policy": "returns_policy",
        "order_help": "order_help",
        "clarify": "clarify",
    },
)

builder.add_edge("product_search", END)
builder.add_edge("returns_policy", END)
builder.add_edge("order_help", END)
builder.add_edge("clarify", END)

graph = builder.compile()

if __name__ == "__main__":
    examples = [
        "Can you recommend a good laptop for university?",
        "I want a refund for my headphones.",
        "Where is my order? It should have arrived yesterday.",
        "I need help.",
    ]

    for text in examples:
        result = graph.invoke(
            {
                "user_message": text,
                "route": "",
                "response": "",
            }
        )

        print("\n=== RUN ===")
        print("User message:", result["user_message"])
        print("Chosen route:", result["route"])
        print("Response    :", result["response"])
