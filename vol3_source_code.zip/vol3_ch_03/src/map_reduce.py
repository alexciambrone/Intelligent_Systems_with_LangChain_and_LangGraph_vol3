import operator
from typing import Annotated
from typing_extensions import TypedDict

from langchain.chat_models import init_chat_model
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import StateGraph, START, END
from langgraph.types import Send
from .config import OPENAI_API_KEY

llm = init_chat_model("openai:gpt-4.1-mini", temperature=0)


class ChunkSummary(TypedDict):
    index: int
    summary: str


class SupportThreadState(TypedDict):
    thread_messages: list[str]
    chunk_summaries: Annotated[list[ChunkSummary], operator.add]
    case_summary: str


class WorkerState(TypedDict):
    index: int
    message: str
    chunk_summaries: Annotated[list[ChunkSummary], operator.add]


def prepare(state: SupportThreadState) -> dict:
    print("\n[PREPARE]")
    print("input:", {"thread_messages": state["thread_messages"]})
    output = {}
    print("output:", output)
    return output


def dispatch_messages(state: SupportThreadState):
    sends = [
        Send("summarize_message", {"index": i, "message": message})
        for i, message in enumerate(state["thread_messages"])
    ]

    print("\n[DISPATCH]")
    for i, message in enumerate(state["thread_messages"]):
        print(
            f"branch {i} input:",
            {"index": i, "message": message}
        )

    return sends


def summarize_message(state: WorkerState) -> dict:
    print(f"\n[MAP branch {state['index']}]")
    print("input:", {"index": state["index"], "message": state["message"]})

    result = llm.invoke(
        [
            SystemMessage(
                content=(
                    "Summarize this support-thread message for an internal case file. "
                    "Keep the summary factual, brief, and operational."
                )
            ),
            HumanMessage(content=state["message"]),
        ]
    )

    output = {
        "chunk_summaries": [
            {
                "index": state["index"],
                "summary": result.content,
            }
        ]
    }

    print("output:", output)
    return output


def reduce_case(state: SupportThreadState) -> dict:
    print("\n[REDUCE]")
    print("input:", {"chunk_summaries": state["chunk_summaries"]})

    ordered = sorted(state["chunk_summaries"], key=lambda item: item["index"])
    summaries_text = "\n".join(
        f"{item['index'] + 1}. {item['summary']}" for item in ordered
    )

    print("ordered summaries text:")
    print(summaries_text)

    result = llm.invoke(
        [
            SystemMessage(
                content=(
                    "You are preparing an internal support case summary. "
                    "Combine the message-level summaries into one concise report with "
                    "three sections: customer_problem, key_facts, and recommended_next_step."
                )
            ),
            HumanMessage(content=summaries_text),
        ]
    )

    output = {"case_summary": result.content}
    print("output:", output)
    return output


builder = StateGraph(SupportThreadState)
builder.add_node("prepare", prepare)
builder.add_node("summarize_message", summarize_message)
builder.add_node("reduce_case", reduce_case)

builder.add_edge(START, "prepare")
builder.add_conditional_edges("prepare", dispatch_messages, ["summarize_message"])
builder.add_edge("summarize_message", "reduce_case")
builder.add_edge("reduce_case", END)

graph = builder.compile()

initial_state = {
    "thread_messages": [
        "I changed my shipping address yesterday but the parcel still went to the old address.",
        "I was charged twice after I tried to update the order.",
        "I need to know whether the second charge will be refunded automatically.",
    ]
}

print("\n=== STREAMED EXECUTION ===")
for event in graph.stream(initial_state, stream_mode="updates"):
    print("\nEVENT:", event)

print("\n=== FINAL RESULT ===")
state = graph.invoke(initial_state)
print(state["case_summary"])