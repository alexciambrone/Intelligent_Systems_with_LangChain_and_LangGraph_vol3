import operator
from collections import Counter
from typing import Annotated, Literal

from pydantic import BaseModel, Field
from typing_extensions import TypedDict

from langchain.chat_models import init_chat_model
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import StateGraph, START, END
from .config import OPENAI_API_KEY

reviewer_llm = init_chat_model("openai:gpt-4.1-mini", temperature=0.7)

class PriorityVote(BaseModel):
    label: Literal["normal", "priority", "urgent"] = Field(
        description="Escalation priority for this support request."
    )
    reason: str = Field(description="Brief reason for the priority choice.")

structured_reviewer = reviewer_llm.with_structured_output(PriorityVote)

class VoteRecord(TypedDict):
    reviewer: str
    label: str
    reason: str

class TicketState(TypedDict):
    ticket_text: str
    votes: Annotated[list[VoteRecord], operator.add]
    final_priority: str

def make_reviewer(reviewer_name: str, lens: str):
    def review(state: TicketState) -> dict:
        result = structured_reviewer.invoke(
            [
                SystemMessage(
                    content=(
                        "Classify the escalation priority of the ticket. "
                        "Return one label from: normal, priority, urgent. "
                        f"Use this review lens: {lens}"
                    )
                ),
                HumanMessage(content=state["ticket_text"]),
            ]
        )
        return {
            "votes": [
                {
                    "reviewer": reviewer_name,
                    "label": result.label,
                    "reason": result.reason,
                }
            ]
        }

    return review

def resolve_vote(state: TicketState) -> dict:
    counts = Counter(vote["label"] for vote in state["votes"])
    ranked = counts.most_common()

    if len(ranked) == 1 or ranked[0][1] > ranked[1][1]:
        winner = ranked[0][0]
    else:
        safety_order = {"normal": 0, "priority": 1, "urgent": 2}
        tied_labels = [label for label, count in ranked if count == ranked[0][1]]
        winner = max(tied_labels, key=lambda label: safety_order[label])

    return {"final_priority": winner}

builder = StateGraph(TicketState)
builder.add_node(
    "operations_reviewer",
    make_reviewer(
        "operations_reviewer",
        "Focus on delivery failure, refund urgency, and the risk of unresolved account impact.",
    ),
)
builder.add_node(
    "policy_reviewer",
    make_reviewer(
        "policy_reviewer",
        "Focus on whether the request suggests a policy exception, compliance issue, or manual intervention.",
    ),
)
builder.add_node(
    "customer_impact_reviewer",
    make_reviewer(
        "customer_impact_reviewer",
        "Focus on customer harm, frustration, repeated contact, and whether the issue is getting worse.",
    ),
)
builder.add_node("resolve_vote", resolve_vote)

builder.add_edge(START, "operations_reviewer")
builder.add_edge(START, "policy_reviewer")
builder.add_edge(START, "customer_impact_reviewer")

builder.add_edge("operations_reviewer", "resolve_vote")
builder.add_edge("policy_reviewer", "resolve_vote")
builder.add_edge("customer_impact_reviewer", "resolve_vote")
builder.add_edge("resolve_vote", END)

graph = builder.compile()

state = graph.invoke(
    {
        "ticket_text": (
            "My order was delivered to the wrong address, I have been charged twice, "
            "and I have already contacted support once without a refund."
        )
    }
)

print("\n=== REVIEWER VOTES ===")
for i, vote in enumerate(state["votes"], start=1):
    print(f"\n[{i}] {vote['reviewer']}")
    print(f"  Label : {vote['label']}")
    print(f"  Reason: {vote['reason']}")

print("\n=== FINAL DECISION ===")
print(f"Priority: {state['final_priority']}")

