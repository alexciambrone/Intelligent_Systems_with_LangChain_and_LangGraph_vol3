from __future__ import annotations

import operator
import re
from typing import Annotated, Literal

from pydantic import BaseModel, Field
from typing_extensions import TypedDict

from langchain.chat_models import init_chat_model
from langchain.tools import tool
from langchain_core.documents import Document
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import OpenAIEmbeddings
from langchain_chroma import Chroma
from langgraph.graph import StateGraph, START, END
from langgraph.types import Send

from .config import OPENAI_API_KEY


ORDERS = {
    "ORD-100": {
        "status": "delivered",
        "delivered_days_ago": 6,
        "damaged_reported": True,
        "eligible_for_refund_review": True,
        "currency": "EUR",
        "amount": 129.00,
    },
    "ORD-200": {
        "status": "delivered",
        "delivered_days_ago": 42,
        "damaged_reported": False,
        "eligible_for_refund_review": False,
        "currency": "EUR",
        "amount": 79.00,
    },
}

POLICY_CORPUS = {
    "returns": [
        {
            "source": "returns.md#standard-window",
            "text": (
                "Standard items may be returned within 30 days of delivery if they are "
                "unused or defective."
            ),
        },
        {
            "source": "returns.md#exceptions",
            "text": (
                "Items returned outside the standard window require manual approval and "
                "are not guaranteed to receive a refund."
            ),
        },
    ],
    "damaged_items": [
        {
            "source": "damaged-items.md#reporting",
            "text": (
                "Damaged items should be reported as soon as possible. When damage is "
                "confirmed, the customer may receive a replacement or refund."
            ),
        },
        {
            "source": "damaged-items.md#evidence",
            "text": (
                "Support may request photos or delivery evidence before confirming a "
                "damaged-item refund."
            ),
        },
    ],
    "refund_timing": [
        {
            "source": "refunds.md#timing",
            "text": (
                "Approved refunds are usually issued within 5 business days after review."
            ),
        },
        {
            "source": "refunds.md#payment-rail",
            "text": (
                "The time for funds to appear can vary by payment provider after the refund "
                "has been issued."
            ),
        },
    ],
    "gift_returns": [
        {
            "source": "gift-returns.md#store-credit",
            "text": (
                "Gift returns may be eligible for store credit when the original payment "
                "method cannot be refunded."
            ),
        }
    ],
}


def _extract_order_id(text: str) -> str | None:
    match = re.search(r"\bORD-\d+\b", text.upper())
    return match.group(0) if match else None


@tool
def lookup_order(order_id: str) -> dict:
    """Return normalized order facts for a support workflow."""
    if order_id not in ORDERS:
        raise ValueError(f"Unknown order id: {order_id}")
    return {"order_id": order_id, **ORDERS[order_id]}


def build_policy_vectorstore() -> Chroma:
    docs: list[Document] = []

    for branch, items in POLICY_CORPUS.items():
        for i, item in enumerate(items):
            docs.append(
                Document(
                    page_content=item["text"],
                    metadata={
                        "branch": branch,
                        "source": item["source"],
                        "doc_id": f"{branch}-{i}",
                    },
                )
            )

    embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

    vectorstore = Chroma(
        collection_name="support_policy",
        embedding_function=embeddings,
        persist_directory="./chroma_policy_db",
    )

    existing = vectorstore.get()
    existing_ids = existing.get("ids", []) if existing else []

    if not existing_ids:
        vectorstore.add_documents(
            documents=docs,
            ids=[doc.metadata["doc_id"] for doc in docs],
        )

    return vectorstore


POLICY_VECTORSTORE = build_policy_vectorstore()


@tool
def search_policy(
    branch: Literal["returns", "damaged_items", "refund_timing", "gift_returns"],
    query: str,
    top_k: int = 2,
) -> list[dict]:
    """Semantic search over the policy corpus using a Chroma vector store."""
    hits = POLICY_VECTORSTORE.similarity_search(
        query=query,
        k=top_k,
        filter={"branch": branch},
    )

    if not hits:
        return []

    return [
        {
            "branch": doc.metadata["branch"],
            "source": doc.metadata["source"],
            "text": doc.page_content,
        }
        for doc in hits
    ]


class RouteDecision(BaseModel):
    route: Literal["policy_only", "order_only", "mixed", "escalate"]
    policy_branches: list[
        Literal["returns", "damaged_items", "refund_timing", "gift_returns"]
    ] = Field(default_factory=list)
    needs_order_lookup: bool = Field(default=False)
    reason: str


class PolicyEvidence(TypedDict):
    branch: str
    source: str
    text: str


class SupportState(TypedDict):
    user_query: str
    order_id: str | None
    route: str
    route_reason: str
    policy_branches: list[str]
    policy_evidence: Annotated[list[PolicyEvidence], operator.add]
    order_data: dict | None
    final_answer: str


class PolicyWorkerState(TypedDict):
    user_query: str
    policy_branch: Literal["returns", "damaged_items", "refund_timing", "gift_returns"]
    policy_evidence: Annotated[list[PolicyEvidence], operator.add]


llm = init_chat_model("openai:gpt-4.1-mini", temperature=0)
router = llm.with_structured_output(RouteDecision)


def route_request(state: SupportState) -> dict:
    order_id = _extract_order_id(state["user_query"])

    decision = router.invoke(
        [
            SystemMessage(
                content=(
                    "Route support requests into one of four paths.\n"
                    "policy_only: policy interpretation with no order facts needed.\n"
                    "order_only: order facts only, with no policy reasoning needed.\n"
                    "mixed: both policy interpretation and order facts are required.\n"
                    "escalate: legal, safety, abusive, or clearly human-only cases.\n"
                    "Return only the branches actually needed."
                )
            ),
            HumanMessage(
                content=(
                    f"User request: {state['user_query']}\n"
                    f"Extracted order id: {order_id}"
                )
            ),
        ]
    )

    return {
        "order_id": order_id,
        "route": decision.route,
        "route_reason": decision.reason,
        "policy_branches": list(decision.policy_branches),
    }


def choose_after_route(
    state: SupportState,
) -> Literal["policy_only", "order_only", "mixed", "escalate"]:
    return state["route"]  # type: ignore[return-value]


def mixed_entry(state: SupportState) -> dict:
    return {}


def policy_fanout(state: SupportState) -> dict:
    return {}


def send_policy_workers(state: SupportState) -> list[Send]:
    return [
        Send(
            "policy_worker",
            {
                "user_query": state["user_query"],
                "policy_branch": branch,
            },
        )
        for branch in state["policy_branches"]
    ]


def policy_worker(state: PolicyWorkerState) -> dict:
    hits = search_policy.invoke(
        {
            "branch": state["policy_branch"],
            "query": state["user_query"],
            "top_k": 2,
        }
    )

    evidence: list[PolicyEvidence] = [
        {
            "branch": hit["branch"],
            "source": hit["source"],
            "text": hit["text"],
        }
        for hit in hits
    ]

    return {"policy_evidence": evidence}


def lookup_order_node(state: SupportState) -> dict:
    if not state.get("order_id"):
        return {"order_data": None}
    return {"order_data": lookup_order.invoke({"order_id": state["order_id"]})}


def escalate_node(state: SupportState) -> dict:
    return {
        "final_answer": "This request should be escalated to a human support specialist."
    }


def synthesize_response(state: SupportState) -> dict:
    order_block = state.get("order_data") or {"order_id": None, "status": "unknown"}
    evidence_lines = "\n".join(
        f"- [{item['branch']}] {item['source']}: {item['text']}"
        for item in state.get("policy_evidence", [])
    )

    response = llm.invoke(
        [
            SystemMessage(
                content=(
                    "You are a customer support assistant. "
                    "Answer only from the provided order facts and policy evidence. "
                    "Do not invent policy. If the evidence is incomplete, say what is "
                    "known and what still requires review."
                )
            ),
            HumanMessage(
                content=(
                    f"User request:\n{state['user_query']}\n\n"
                    f"Route reason:\n{state['route_reason']}\n\n"
                    f"Order facts:\n{order_block}\n\n"
                    f"Policy evidence:\n{evidence_lines}\n\n"
                    "Write one grounded answer for the customer."
                )
            ),
        ]
    )

    return {"final_answer": response.content}


builder = StateGraph(SupportState)

builder.add_node("route", route_request)
builder.add_node("mixed_entry", mixed_entry)
builder.add_node("policy_fanout", policy_fanout)
builder.add_node("policy_worker", policy_worker)
builder.add_node("lookup_order", lookup_order_node)
builder.add_node("escalate", escalate_node)
builder.add_node("synthesize", synthesize_response)

builder.add_edge(START, "route")
builder.add_conditional_edges(
    "route",
    choose_after_route,
    {
        "policy_only": "policy_fanout",
        "order_only": "lookup_order",
        "mixed": "mixed_entry",
        "escalate": "escalate",
    },
)

builder.add_edge("mixed_entry", "policy_fanout")
builder.add_edge("mixed_entry", "lookup_order")

builder.add_conditional_edges("policy_fanout", send_policy_workers, ["policy_worker"])

builder.add_edge("policy_worker", "synthesize")
builder.add_edge("lookup_order", "synthesize")
builder.add_edge("synthesize", END)
builder.add_edge("escalate", END)

graph = builder.compile()


if __name__ == "__main__":
    result = graph.invoke(
        {
            "user_query": (
                "My order ORD-100 arrived damaged. Can I get a refund, and how long "
                "will it take?"
            ),
            "policy_evidence": [],
        }
    )

    print("\n=== FINAL ANSWER ===\n")
    print(result["final_answer"])

    print("\n=== ORDER DATA ===\n")
    print(result.get("order_data"))

    print("\n=== POLICY EVIDENCE ===\n")
    for item in result.get("policy_evidence", []):
        print(item)