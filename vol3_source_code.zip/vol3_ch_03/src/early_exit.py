from __future__ import annotations

import re
from typing import Literal
from typing_extensions import TypedDict

from langgraph.graph import START, END, StateGraph
from langgraph.types import Command

ORDERS = {
    "ORD-100": {"status": "delivered"},
    "ORD-101": {"status": "processing"},
}

POLICY_SNIPPETS = {
    "refund": "Refunds are allowed within 30 days for unused items.",
}


class SupportState(TypedDict, total=False):
    question: str
    order_id: str
    order: dict
    policy_snippet: str
    final_answer: str


def cheap_gate(
    state: SupportState,
) -> Command[Literal["lookup_order", "retrieve_policy", END]]:
    q = state["question"].lower()
    print(f"[gate] question={state['question']}")

    if q in {"hi", "hello", "thanks"}:
        print("[gate] early exit -> END")
        return Command(
            update={
                "final_answer": "Hello. I can help with order status or policy questions."
            },
            goto=END,
        )

    match = re.search(r"ord-\d{3,}", q, re.I)
    if "where is my order" in q and match:
        order_id = match.group(0).upper()
        print(f"[gate] route -> lookup_order, order_id={order_id}")
        return Command(update={"order_id": order_id}, goto="lookup_order")

    if "refund" in q or "return policy" in q:
        print("[gate] route -> retrieve_policy")
        return Command(goto="retrieve_policy")

    print("[gate] early exit -> END")
    return Command(
        update={"final_answer": "Please provide an order id or ask a policy question."},
        goto=END,
    )


def lookup_order(state: SupportState) -> dict:
    print(f"[lookup_order] order_id={state['order_id']}")
    order = ORDERS.get(state["order_id"])
    if not order:
        print("[lookup_order] not found")
        return {"final_answer": f"Order {state['order_id']} was not found."}

    print(f"[lookup_order] found status={order['status']}")
    return {"order": order}


def route_after_lookup(state: SupportState) -> Literal["answer_from_order", END]:
    route = "answer_from_order" if "order" in state else END
    print(f"[after_lookup] goto={route}")
    return route


def answer_from_order(state: SupportState) -> dict:
    print("[answer_from_order] building final answer")
    return {
        "final_answer": (
            f"Order {state['order_id']} is currently {state['order']['status']}."
        )
    }


def retrieve_policy(state: SupportState) -> dict:
    print("[retrieve_policy] key=refund")
    snippet = POLICY_SNIPPETS.get("refund", "")
    if not snippet:
        print("[retrieve_policy] not found")
        return {"final_answer": "I could not find a refund policy snippet."}

    print("[retrieve_policy] snippet found")
    return {"policy_snippet": snippet}


def route_after_policy(state: SupportState) -> Literal["answer_from_policy", END]:
    route = "answer_from_policy" if "policy_snippet" in state else END
    print(f"[after_policy] goto={route}")
    return route


def answer_from_policy(state: SupportState) -> dict:
    print("[answer_from_policy] building final answer")
    return {"final_answer": state["policy_snippet"]}


builder = StateGraph(SupportState)
builder.add_node("cheap_gate", cheap_gate)
builder.add_node("lookup_order", lookup_order)
builder.add_node("answer_from_order", answer_from_order)
builder.add_node("retrieve_policy", retrieve_policy)
builder.add_node("answer_from_policy", answer_from_policy)

builder.add_edge(START, "cheap_gate")
builder.add_conditional_edges("lookup_order", route_after_lookup)
builder.add_edge("answer_from_order", END)
builder.add_conditional_edges("retrieve_policy", route_after_policy)
builder.add_edge("answer_from_policy", END)

graph = builder.compile()


def run_case(question: str) -> None:
    print("\n" + "=" * 50)
    print(f"QUESTION: {question}")
    result = graph.invoke({"question": question})
    print(f"FINAL: {result['final_answer']}")


run_case("hello")
run_case("Where is my order ORD-100?")
run_case("What is the refund policy?")