from __future__ import annotations

import operator
import re
from typing import Annotated, Literal

from pydantic import BaseModel, Field
from typing_extensions import TypedDict

from langchain.messages import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import START, END, StateGraph
from .config import OPENAI_API_KEY


# Sample private data for the support assistant.
ORDERS = {
    "ORD-100": {
        "status": "delivered",
        "days_since_delivery": 8,
        "damaged": True,
        "opened": True,
        "amount": 129.0,
    },
    "ORD-200": {
        "status": "delivered",
        "days_since_delivery": 45,
        "damaged": True,
        "opened": True,
        "amount": 89.0,
    },
}


class PlanStep(BaseModel):
    step_type: Literal[
        "ask_for_order_id",
        "extract_order_id",
        "lookup_order",
        "evaluate_policy",
    ]
    description: str


class Plan(BaseModel):
    steps: list[PlanStep] = Field(description="Ordered workflow steps")


class EvidenceItem(BaseModel):
    step_type: str
    data: dict
    note: str


class SupportState(TypedDict):
    user_request: str
    plan: list[dict]
    current_step: int
    order_id: str | None
    policy_decision: str | None
    final_answer: str | None
    evidence: Annotated[list[dict], operator.add]


planner_llm = ChatOpenAI(model="gpt-4.1", temperature=0).with_structured_output(Plan)
solver_llm = ChatOpenAI(model="gpt-4.1", temperature=0)


def planner(state: SupportState) -> dict:
    result = planner_llm.invoke(
        [
            SystemMessage(
                content=(
                    "You are the planner in a customer-support workflow. "
                    "If the request does not contain an order ID like ORD-100, "
                    "return a single step: ask_for_order_id. "
                    "Otherwise return these steps in order: "
                    "extract_order_id, lookup_order, evaluate_policy."
                )
            ),
            HumanMessage(content=state["user_request"]),
        ]
    )
    return {
        "plan": [step.model_dump() for step in result.steps],
        "current_step": 0,
        "evidence": [],
    }


def worker(state: SupportState) -> dict:
    step = state["plan"][state["current_step"]]
    step_type = step["step_type"]
    updates = {"current_step": state["current_step"] + 1}

    if step_type == "ask_for_order_id":
        item = EvidenceItem(
            step_type=step_type,
            data={},
            note="Missing order ID; user clarification required.",
        )
        return {
            **updates,
            "evidence": [item.model_dump()],
            "final_answer": (
                "I can help with that, but I need the order ID first. "
                "Please send it in the form ORD-123."
            ),
        }

    if step_type == "extract_order_id":
        match = re.search(r"ORD-\d{3,}", state["user_request"])
        order_id = match.group(0) if match else None
        item = EvidenceItem(
            step_type=step_type,
            data={"order_id": order_id},
            note="Extracted order identifier from the user request.",
        )
        return {
            **updates,
            "order_id": order_id,
            "evidence": [item.model_dump()],
        }

    if step_type == "lookup_order":
        order = ORDERS.get(state["order_id"])
        item = EvidenceItem(
            step_type=step_type,
            data={"order": order},
            note="Loaded order facts from the order store.",
        )
        return {
            **updates,
            "evidence": [item.model_dump()],
        }

    if step_type == "evaluate_policy":
        order = None
        for ev in state["evidence"]:
            if ev["step_type"] == "lookup_order":
                order = ev["data"]["order"]

        if order is None:
            decision = "Order not found."
        elif order["status"] != "delivered":
            decision = "Refund cannot start until delivery is confirmed."
        elif order["days_since_delivery"] > 30:
            decision = "Outside the 30-day damaged-item refund window."
        elif not order["damaged"]:
            decision = "Use the normal returns path instead of damaged-item handling."
        else:
            decision = "Eligible for damaged-item refund review."

        item = EvidenceItem(
            step_type=step_type,
            data={"policy_decision": decision},
            note="Applied the damaged-item refund policy to the order facts.",
        )
        return {
            **updates,
            "policy_decision": decision,
            "evidence": [item.model_dump()],
        }

    raise ValueError(f"Unknown step type: {step_type}")


def should_continue(state: SupportState) -> str:
    if state.get("final_answer"):
        return "solver"
    if state["current_step"] < len(state["plan"]):
        return "worker"
    return "solver"


def solver(state: SupportState) -> dict:
    if state.get("final_answer"):
        return {}

    msg = solver_llm.invoke(
        [
            SystemMessage(
                content=(
                    "You are the solver in a customer-support workflow. "
                    "Write a concise customer reply using only the structured evidence. "
                    "Do not invent policy details."
                )
            ),
            HumanMessage(
                content=(
                    f"User request: {state['user_request']}\n"
                    f"Plan: {state['plan']}\n"
                    f"Evidence: {state['evidence']}\n"
                    f"Policy decision: {state['policy_decision']}"
                )
            ),
        ]
    )
    return {"final_answer": msg.content}


builder = StateGraph(SupportState)
builder.add_node("planner", planner)
builder.add_node("worker", worker)
builder.add_node("solver", solver)

builder.add_edge(START, "planner")
builder.add_edge("planner", "worker")
builder.add_conditional_edges(
    "worker",
    should_continue,
    {
        "worker": "worker",
        "solver": "solver",
    },
)
builder.add_edge("solver", END)

graph = builder.compile()

if __name__ == "__main__":
    result = graph.invoke(
        {
            "user_request": "My order ORD-100 arrived damaged yesterday. Can I get a refund?",
            "plan": [],
            "current_step": 0,
            "order_id": None,
            "policy_decision": None,
            "final_answer": None,
            "evidence": [],
        }
    )

    print("PLAN:")
    for step in result["plan"]:
        print(step)

    print("\nEVIDENCE:")
    for item in result["evidence"]:
        print(item)

    print("\nFINAL ANSWER:")
    print(result["final_answer"])


